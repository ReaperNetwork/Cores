<?php

/*
 * JuqnGOOD mi dios.
 */

declare(strict_types=1);

namespace cosmicpe\form;

use pocketmine\form\Form as PocketMineForm;

interface Form extends PocketMineForm { }
