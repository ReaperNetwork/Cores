<?php

/*
 * JuqnGOOD mi dios.
 */

declare(strict_types=1);

namespace cosmicpe\form\entries;

use JsonSerializable;

interface FormEntry extends JsonSerializable { }
