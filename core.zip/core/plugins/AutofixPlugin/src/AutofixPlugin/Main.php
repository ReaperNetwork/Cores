<?php

declare(strict_types=1);

namespace AutofixPlugin;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\player\Player;
use pocketmine\item\Armor;
use pocketmine\item\Item;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\nbt\tag\IntTag;
use pocketmine\utils\TextFormat;

class Main extends PluginBase implements Listener {

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    /**
     * @param EntityDamageEvent $event
     */
    public function onEntityDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();

        // Check if the entity is a player
        if ($entity instanceof Player) {
            // Check each armor slot for the "Autofix" enchantment
            $armorInventory = $entity->getArmorInventory();
            foreach ($armorInventory->getContents() as $slot => $item) {
                if ($item instanceof Armor && $this->hasAutofixEnchantment($item)) {
                    // Restore the item's maximum durability to ensure it never breaks
                    $item->setDamage(0);
                    $armorInventory->setItem($slot, $item); // Update the item in the inventory
                }
            }
        }
    }

    /**
     * Check if an item has the "Autofix" enchantment
     *
     * @param Item $item
     * @return bool
     */
    private function hasAutofixEnchantment(Item $item): bool {
        // Check for the custom NBT tag "Autofix"
        $nbt = $item->getNamedTag();
        return $nbt->getTag("Autofix") instanceof IntTag && $nbt->getInt("Autofix") === 1;
    }

    /**
     * Add the Autofix enchantment to the item in hand
     *
     * @param CommandSender $sender
     * @param Command $command
     * @param string $label
     * @param array $args
     * @return bool
     */
    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "autofix" && $sender instanceof Player && $sender->hasPermission("autofixplugin.command.autofix")) {
            $item = $sender->getInventory()->getItemInHand();
            if ($item instanceof Armor) {
                $nbt = $item->getNamedTag();
                $nbt->setInt("Autofix", 1);
                $item->setNamedTag($nbt);

                // Set lore with AutoFix in red
                $lore = $item->getLore();
                $lore[] = TextFormat::RED . "AutoFix";
                $item->setLore($lore);

                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("Se ha aplicado el encantamiento Autofix creado por SoyNexos.");
                return true;
            } else {
                $sender->sendMessage("Debes sostener una pieza de armadura para aplicar el encantamiento Autofix.");
                return false;
            }
        }
        return false;
    }
}
