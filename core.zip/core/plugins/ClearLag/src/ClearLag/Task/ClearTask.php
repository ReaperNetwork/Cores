<?php

namespace ClearLag\Task;

use ClearLag\ClearLag;
use pocketmine\entity\object\ItemEntity;
use pocketmine\item\Item;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\utils\Config;

class ClearTask extends Task
{

    public int $timeToClear = 60 * 2;
    public int $count = 0;

    public function onRun(): void
    {

        $config = new Config(Clearlag::getInstance()->getDataFolder() . "config.yml", Config::YAML);
        --$this->timeToClear;
        if ($this->timeToClear <= 0) {
            foreach (Server::getInstance()->getWorldManager()->getWorlds() as $world) {
                foreach ($world->getEntities() as $entity) {
                    if ($entity instanceof ItemEntity) {
                        $entity->flagForDespawn();
                        $this->count++;
                    }
                }
            }
            /*foreach (Server::getInstance()->getOnlinePlayers() as $player) {
                $sound = new PlaySoundPacket();
                $sound->soundName = "random.levelup";
                $sound->x = $player->getPosition()->x;
                $sound->y = $player->getPosition()->y;
                $sound->z = $player->getPosition()->z;
                $sound->volume = 0.5;
                $sound->pitch = 1;
                ##$player->getNetworkSession()->sendDataPacket($sound);
            }*/
            $message = str_replace("{count}", $this->count, $config->get("chat"));
            //$player->sendMessage($message);
            Server::getInstance()->broadcastMessage($message);
            $this->timeToClear = 60 * 2;
            $this->count = 0;
        } elseif (in_array($this->timeToClear, ([1, 2, 3, 4, 5, 10, 15, 30, 60]))) {
            /*foreach (Server::getInstance()->getOnlinePlayers() as $player) {
                $sound = new PlaySoundPacket();
                $sound->soundName = "random.orb";
                $sound->x = $player->getPosition()->x;
                $sound->y = $player->getPosition()->y;
                $sound->z = $player->getPosition()->z;
                $sound->volume = 0.5;
                $sound->pitch = 1;
                //$player->getNetworkSession()->sendDataPacket($sound);
                $message = str_replace("{time}", $this->timeToClear, $config->get("timerads"));
                //$player->sendPopup($message);
                //$player->sendMessage($message);
                Server::getInstance()->broadcastMessage($message);
            }*/
            $message = str_replace("{time}", $this->timeToClear, $config->get("timerads"));
            Server::getInstance()->broadcastMessage($message);
        }
    }
}
