<?php

namespace Clearlag\Commands;

use ClearLag\ClearLag;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\entity\object\ItemEntity;
use pocketmine\item\Item;
use pocketmine\lang\translatable\TranslationContainer;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\Config;

class ForceClear extends Command
{

    public function __construct()
    {
        parent::__construct('forceclear', '');
        $this->setDescription("Clears all item entities");
        $this->setPermission("forceclear.cmd");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool
    {
        if ($sender instanceof Player) {
            if ($sender->hasPermission("forceclear.cmd")) {
                $entityCount = 0;
                foreach (Server::getInstance()->getWorldManager()->getWorlds() as $world) {
                    foreach ($world->getEntities() as $entity) {
                        if ($entity instanceof ItemEntity) {
                            ++$entityCount;
                            $entity->flagForDespawn();
                        }
                    }
                }
                $config = new Config(ClearLag::getInstance()->getDataFolder() . "config.yml", Config::YAML);
                $message = str_replace("{player}", $sender->getName(), $config->get("forceclear"));
                Server::getInstance()->broadcastMessage($message);
            } else {
                $sender->sendMessage("§cYou don't have permission to execute this command");
            }
        } else {
            $sender->sendMessage("§cYou cannot execute this command from the console");
        }
        return true;
    }
}
