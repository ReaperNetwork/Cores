<?php

namespace ClearLag;

use ClearLag\Task\ClearTask;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use ClearLag\Commands;
use ClearLag\Commands\ForceClear;
use pocketmine\utils\Config;

class ClearLag extends PluginBase implements Listener
{

    /**
     * @var Main|null
     */
    private static $instance;

    public function onLoad(): void
    {
        self::$instance = $this;
    }

    public function onEnable(): void
    {
        $this->getLogger()->info("§aActivo");
        $this->saveResource("config.yml");

        $this->getServer()->getCommandMap()->register("Vanilla", new ForceClear());

        $this->getScheduler()->scheduleRepeatingTask(new ClearTask(), 20);
    }

    public static function getInstance(): ?self
    {
        return self::$instance;
    }

    public function onDisable(): void
    {
        $this->getLogger()->info("§cDisabled");
    }
}
