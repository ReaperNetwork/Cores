<?php

namespace itoozh;

use CortexPE\std\AABBUtils;
use CortexPE\std\Vector3Utils;
use hcf\player\Player;
use itoozh\WallBarriersTrait;
use JetBrains\PhpStorm\Pure;
use pocketmine\block\Block;
use pocketmine\block\BlockFactory;
use pocketmine\block\BlockLegacyIds;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\data\bedrock\DyeColorIdMap;
use pocketmine\entity\Entity;
use pocketmine\entity\projectile\Projectile;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\VanillaItems;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Vector3;
use pocketmine\world\Position;
use pocketmine\plugin\PluginBase;

class CombatWall extends PluginBase implements Listener {
    use WallBarriersTrait;

    /** @var int[][] $tagged */
    private static array $tagged = [];

    /** @var int $tag_time */
    protected static int $tag_time;


    /** @var AxisAlignedBB[][] */
    private array $regions = [];
    private Block $barrierBlock;


    public function onLoad(): void
    {
        $this->barrierRadius = 3;
        $this->barrierBlock = VanillaBlocks::STAINED_GLASS()->setColor(DyeColor::RED());
        $this->regions[$this->getConfig()->get("world")][] = AABBUtils::fromCoordinates(
            Vector3Utils::fromString($this->getConfig()->get("pos1")),
            Vector3Utils::fromString($this->getConfig()->get("pos2"))
        )->expand(0.0001, 0, 0.0001);
    }

    public function onEnable(): void
    {
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    protected function isVisibleTo(Player $player): bool {
        return self::isTagged($player);
    }

    protected function calculateNearestPointOutside(Player $p, Position $pos): Position {
        foreach($this->regions[$pos->world->getFolderName()] ?? [] as $region) {
            if(!$region->isVectorInside($p->getPosition())) continue;
            $vec = AABBUtils::getNearestStraightPathOutside($region, $pos);
            $pos->x = $vec->x;
            $pos->y = $vec->y;
            $pos->z = $vec->z;
        }
        return $pos;
    }

    #[Pure] protected function isInsideProhibitedArea(Player $p, Position $pos): bool {
        if(!isset($this->regions[$fName = $pos->world->getFolderName()])) return false;
        foreach($this->regions[$fName] as $region) {
            if($region->isVectorInside($pos)) return true;
        }
        return false;
    }

    protected function getBarrierBlock(): Block {
        return $this->barrierBlock;
    }


    /**
     * @param Player $victim
     * @param Player $damager
     */
    public static function tag(Player $victim, Player $damager): void{
        foreach([$victim, $damager] as $player){
            self::$tagged[$player->getName()] = ["time" => time()];
        }
    }

    /**
     * @param Player $player
     * @return bool
     */
    public static function isTagged(Player $player): bool{
        if($player->getSession()->getCooldown("spawn.tag") !== null) return true;
        return false;
    }

    /**
     * @param Player $player
     * @return int|null
     */
    public static function getTagTime(Player $player): ?int{
        if(self::isTagged($player)){
            return (self::$tagged[$player->getName()]["time"] + self::$tag_time) - time();
        }
        return null;
    }

    private function determineAttacker(Player $victim, Entity $attackerEntity): ?Player{
        if($attackerEntity instanceof Projectile){
            if($attackerEntity->getOwningEntity() instanceof Entity){
                $source = $attackerEntity->getOwningEntity();
            }else{
                return null;
            }

            if($attackerEntity->getId() == VanillaItems::ENDER_PEARL() && $attackerEntity === $victim) return null;

            return $this->determineAttacker($victim, $source);
        }elseif($attackerEntity instanceof Player){
            return $attackerEntity;
        }
        return null;
    }
}