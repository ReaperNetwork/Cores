<?php

namespace itoozh\crates\effect;

use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\world\particle\FlameParticle;
use pocketmine\world\particle\EnchantmentTableParticle;
use pocketmine\world\particle\HeartParticle;
use pocketmine\world\particle\LavaParticle;
use pocketmine\world\particle\RedstoneParticle;
use pocketmine\world\particle\WaterDripParticle;
use pocketmine\world\Position;

abstract class CrateEffect {

    public const RED_EFFECT = "Red";
    public const ENCHANT_CIRCLE = "Enchant";
    public const HEARTH_EFFECT = "Heart";
    public const WATER_EFFECT = "Water";
    public const LAVA_RINGS = "Lava";
    public const FLAME_EFFECT = "Flame";

    public static function tick(string $effectName, Position $location): void {
        $world = $location->getWorld();
        switch ($effectName) {
            case self::RED_EFFECT:
                $radius = 0.8;

                for ($i = 0; $i < 360; $i += 360 / 8) {
                    $angle = deg2rad($i);
                    $xOffset = $radius * cos($angle);
                    $zOffset = $radius * sin($angle);

                    $particleLocation = $location->add($xOffset, 0, $zOffset);
                    $world->addParticle($particleLocation, new RedstoneParticle());
                }
                break;
            case self::ENCHANT_CIRCLE:
                $radius = 0.8;

                for ($i = 0; $i < 360; $i += 360 / 8) {
                    $angle = deg2rad($i);
                    $xOffset = $radius * cos($angle);
                    $zOffset = $radius * sin($angle);

                    $particleLocation = $location->add($xOffset, 0, $zOffset);
                    $world->addParticle($particleLocation, new EnchantmentTableParticle());
                }
                break;
            case self::HEARTH_EFFECT:
                $radius = 0.8;

                for ($i = 0; $i < 360; $i += 360 / 8) {
                    $angle = deg2rad($i);
                    $xOffset = $radius * cos($angle);
                    $zOffset = $radius * sin($angle);

                    $particleLocation = $location->add($xOffset, 0, $zOffset);
                    $world->addParticle($particleLocation, new HeartParticle());
                }
                break;
            case self::WATER_EFFECT:
                $radius = 0.8;

                for ($i = 0; $i < 360; $i += 360 / 8) {
                    $angle = deg2rad($i);
                    $xOffset = $radius * cos($angle);
                    $zOffset = $radius * sin($angle);

                    $particleLocation = $location->add($xOffset, 0, $zOffset);
                    $world->addParticle($particleLocation, new WaterDripParticle());
                }
                break;
            case self::LAVA_RINGS:
                for ($i = 0; $i < 360; $i += 360 / 4) {
                    $angle = deg2rad($i);
                    $x = 0.4 * cos($angle);
                    $z = 0.4 * sin($angle);

                    $newLocation = $location->add($x, 0, $z);
                    $world->addParticle($newLocation, new LavaParticle());
                    $location->subtract($x, 0, $z);
                }
                break;
            case self::FLAME_EFFECT:

                for ($i = 0; $i < 360; $i += 360 / 10) {
                    $angle = deg2rad($i);
                    $x = 0.4 * cos($angle);
                    $z = 0.4 * sin($angle);
                    $newLocation = $location->add($x, 0, $z);
                    $world->addParticle($newLocation, new FlameParticle());
                    $location->subtract($x, 0, $z);
                }
        }
    }

    public static function isEffect(string $name): bool {
        return $name === self::RED_EFFECT || $name === self::ENCHANT_CIRCLE || $name === self::HEARTH_EFFECT || $name === self::WATER_EFFECT || $name === self::LAVA_RINGS || $name === self::FLAME_EFFECT;
    }

    public static function getEffects(): array {
        return [self::RED_EFFECT, self::ENCHANT_CIRCLE, self::HEARTH_EFFECT, self::WATER_EFFECT, self::LAVA_RINGS, self::FLAME_EFFECT];
    }
}