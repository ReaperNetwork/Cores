<?php


namespace itoozh\crates;


use pocketmine\entity\Entity;
use pocketmine\entity\Skin;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\convert\LegacySkinAdapter;
use pocketmine\network\mcpe\protocol\AddPlayerPacket;
use pocketmine\network\mcpe\protocol\MovePlayerPacket;
use pocketmine\network\mcpe\protocol\PlayerListPacket;
use pocketmine\network\mcpe\protocol\RemoveActorPacket;
use pocketmine\network\mcpe\protocol\SetActorDataPacket;
use pocketmine\network\mcpe\protocol\types\AbilitiesData;
use pocketmine\network\mcpe\protocol\types\entity\ByteMetadataProperty;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataFlags;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;
use pocketmine\network\mcpe\protocol\types\entity\FloatMetadataProperty;
use pocketmine\network\mcpe\protocol\types\entity\LongMetadataProperty;
use pocketmine\network\mcpe\protocol\types\entity\PropertySyncData;
use pocketmine\network\mcpe\protocol\types\entity\StringMetadataProperty;
use pocketmine\network\mcpe\protocol\types\GameMode;
use pocketmine\network\mcpe\protocol\types\inventory\ItemStack;
use pocketmine\network\mcpe\protocol\types\inventory\ItemStackWrapper;
use pocketmine\network\mcpe\protocol\types\PlayerListEntry;
use pocketmine\network\mcpe\protocol\types\skin\SkinData;
use pocketmine\network\mcpe\protocol\UpdateAbilitiesPacket;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Utils;
use pocketmine\world\Position;
use Ramsey\Uuid\Uuid;

class Hologram {
    private int $entityID;

    public function __construct() {
        $this->entityID = Entity::nextRuntimeId();
    }

    /**
     * @return int
     */
    public function getEntityID(): int
    {
        return $this->entityID;
    }

    /**
     * @throws \JsonException
     */
    public function showTo(Player $player, Position $position, $text = "Text"): void {
        $uuid = Uuid::uuid4();
        $name = TextFormat::colorize($text);

        $ns = $player->getNetworkSession();
        $skinAdapter = new LegacySkinAdapter();
        $ns->sendDataPacket(PlayerListPacket::add([
            PlayerListEntry::createAdditionEntry(
                $uuid, $this->entityID, $name,
                $skinAdapter->toSkinData(new Skin("Standard_Custom", str_repeat("\x00", 8192)))
            )
        ]));
        $pk = new AddPlayerPacket();
        $pk->uuid = $uuid;
        $pk->username = $name;
        $pk->actorRuntimeId = $this->entityID;
        $pk->gameMode = GameMode::CREATIVE;
        $pk->syncedProperties = new PropertySyncData([], []);
        $pk->abilitiesPacket = UpdateAbilitiesPacket::create(new AbilitiesData(0, 0, $this->entityID, []));
        $newY = $position->y + 0.28;
        $pk->position = new Position($position->getX() + 0.5, $newY += 0.28, $position->getZ() + 0.5, $position->getWorld());
        $pk->item = ItemStackWrapper::legacy(ItemStack::null());
        $flags = 1 << EntityMetadataFlags::IMMOBILE;
        $pk->metadata = [
            EntityMetadataProperties::FLAGS => new LongMetadataProperty($flags),
            EntityMetadataProperties::SCALE => new FloatMetadataProperty(0.01)
        ];
        $ns->sendDataPacket($pk);
        $ns->sendDataPacket(PlayerListPacket::remove([PlayerListEntry::createRemovalEntry($uuid)]));
    }

    public function removeFrom(Player $player): void {
        $player->getNetworkSession()->sendDataPacket(RemoveActorPacket::create($this->entityID));
    }
}