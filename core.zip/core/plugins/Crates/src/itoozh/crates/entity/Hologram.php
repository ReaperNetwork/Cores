<?php

namespace itoozh\crates\entity;

use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Location;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\utils\TextFormat;

class Hologram extends Entity {

    protected float $gravity = 0.0;
    protected float $scale = 0.001;
    protected float $drag = 0.0;

    public function __construct(
        Location $location,
        ?CompoundTag $nbt = null,
        private string $name = '',
        private string $text = ''
    ) {
        parent::__construct($location, $nbt);
    }


    public static function getNetworkTypeId(): string {
        return EntityIds::NPC;
    }

    public function canBeMovedByCurrents(): bool {
        return false;
    }

    public function getName(): string {
        return $this->name;
    }

    public function setName(string $name): void {
        $this->name = $name;
    }

    public function setText(string $text): void {
        $this->text = $text;
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.001, 0.001);
    }

    public function attack(EntityDamageEvent $source): void {
        $source->cancel();
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);

        if ($nbt->getTag('hologram_name') !== null && $nbt->getTag('hologram_text') !== null) {
            $name = $nbt->getString('hologram_name');
            $text = $nbt->getString('hologram_text');
            $this->text = $text;
            $this->name = $name;
        }
        $this->setNameTag(TextFormat::colorize($this->text));
        $this->setNameTagAlwaysVisible(true);
        $this->setNameTagVisible(true);

    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();

        if ($this->name !== '' && $this->text !== '') {
            $nbt->setString('hologram_name', $this->name);
            $nbt->setString('hologram_text', $this->text);
        }
        return $nbt;
    }

    protected function getInitialDragMultiplier(): float
    {
        return 0.0;
    }

    protected function getInitialGravity(): float
    {
        return 0.0;
    }
}