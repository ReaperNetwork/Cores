<?php

namespace itoozh\crates\command;

use itoozh\crates\crate\Crate;
use itoozh\crates\lib\muqsit\invmenu\InvMenu;
use itoozh\crates\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class KeyCommand extends Command
{

    public function __construct()
    {
        parent::__construct("key", "Give crates keys", "Usage: /key <give|giveall>");
        $this->setPermission("key.use.command");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if (!$this->testPermission($sender)) {
            $sender->sendMessage(TextFormat::RED . "You do not have permission to use this command.");
            return;
        }

        if (count($args) < 1) {
            $sender->sendMessage(TextFormat::RED . $this->usageMessage);
            return;
        }
        switch ($args[0]) {
            case "giveall":
                if (count($args) < 3) {
                    $sender->sendMessage(TextFormat::RED . "Usage: /key giveall <name> <amount>");
                    return;
                }
                $name = $args[1];
                $amount = $args[2];

                $crate = Main::getCrate($name);
                if ($crate === null) {
                    $sender->sendMessage(TextFormat::RED . "Crate " . $name . " does not exist.");
                    return;
                }

                if (!is_numeric($amount)) {
                    $sender->sendMessage(TextFormat::RED . "Amount must be a number.");
                    return;
                }
                $keys = $crate->getKeyItem($amount);
                foreach (Server::getInstance()->getOnlinePlayers() as $player) {
                    if ($player->getInventory()->canAddItem($keys)) {
                        $player->getInventory()->addItem($keys);
                    } else {
                        $player->getWorld()->dropItem($player->getDirectionVector(), $keys);
                    }
                }
                break;
            case "give":
                if (count($args) < 4) {
                    $sender->sendMessage(TextFormat::RED . "Usage: /key give <name> <amount> <player>");
                    return;
                }
                $name = $args[1];
                $amount = $args[2];
                $playerName = $args[3];

                if (($player = Server::getInstance()->getPlayerExact($playerName)) === null) {
                    $sender->sendMessage(TextFormat::RED . "Player " . $playerName . " does not exist.");
                    return;
                }

                $crate = Main::getCrate($name);
                if ($crate === null) {
                    $sender->sendMessage(TextFormat::RED . "Crate " . $name . " does not exist.");
                    return;
                }

                if (!is_numeric($amount)) {
                    $sender->sendMessage(TextFormat::RED . "Amount must be a number.");
                    return;
                }
                $keys = $crate->getKeyItem($amount);

                if ($player->getInventory()->canAddItem($keys)) {
                    $player->getInventory()->addItem($keys);
                } else {
                    $player->getWorld()->dropItem($player->getDirectionVector(), $keys);
                }
                break;
            default:
                $sender->sendMessage(TextFormat::RED . $this->usageMessage);
                break;
        }
    }

    public function openCreateMenu(Player $player, Crate $crate) : void
    {
        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName(TextFormat::colorize("&eCreate " .$crate->getName() . " rewards."));

        $menu->setInventoryCloseListener(function () use ($player, $crate, $menu) {
            $crate->setRewards($menu->getInventory()->getContents());
            $player->sendMessage(TextFormat::colorize("&aCrate " . $crate->getName() . " has been created."));
            Main::createCrate($crate);
        });

        $menu->send($player);
    }
}