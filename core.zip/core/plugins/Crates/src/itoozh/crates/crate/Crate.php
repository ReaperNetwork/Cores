<?php

namespace itoozh\crates\crate;

use Exception;
use itoozh\crates\effect\CrateEffect;
use itoozh\crates\lib\muqsit\invmenu\InvMenu;
use itoozh\crates\lib\muqsit\invmenu\transaction\InvMenuTransaction;
use itoozh\crates\lib\muqsit\invmenu\transaction\InvMenuTransactionResult;
use itoozh\crates\lib\muqsit\invmenu\type\InvMenuTypeIds;
use itoozh\crates\Util;
use JsonSerializable;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\block\utils\DyeColor;
use pocketmine\item\VanillaItems;
use pocketmine\block\VanillaBlocks;
use pocketmine\entity\Location;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\world\Position;

class Crate implements JsonSerializable
{
    use FloatingText;
    private string $name;
    private array $hologram;
    private string $color;
    private Item $itemKey;
    private string $menu;
    private bool $place;
    private array $decorative = [];

    /** @var string[] */
    private array $viewers = [];
    private ?string $effect = CrateEffect::LAVA_RINGS;
    private int $rewardAmount = 3;
    /** @var array<int, Item> */
    private array $rewards = [];

    public function __construct(string $name, string $color, string $menu)
    {
        $this->name = $name;
        $this->color = $color;
        $this->menu = $menu;
        $this->itemKey = VanillaBlocks::TRIPWIRE_HOOK()->asItem();

        $this->hologram = [
            "§l" . $this->color . $this->name . " §r§7Crate",
            " ",
            "§o§7Left click for rewards",
            "§o§7Right click to open",
            " ",
            "§7§3dsc.gg/icemcpe"
        ];
    }

    public function getDisplayName(): string
    {
        return TextFormat::colorize($this->color . $this->name);
    }
    
    public function getPlace(): bool {
        return $this->place;
    }
    
    public function setPlace(bool $value): void {
        $this->place = $value;
    }
    
    public function getMenu(): string {
        return $this->menu;
    }
    
    public function setMenu(string $menu): void {
        $this->menu = $menu;
    }

    public function setColor(string $color): void
    {
        $this->color = $color;
    }
    
    public function getDecorative(): array {
        return $this->decorative;
    }

    public function getRewards(): array
    {
        return $this->rewards;
    }

    public function getKeyItem(int $amount): Item
    {
        $item = clone $this->itemKey;
        $item->setCount($amount);
        $item->setCustomName(TextFormat::colorize("&r&l" . $this->color . $this->name . " §r§7Key"));
        $item->getNamedTag()->setString("crate", $this->name);
        $item->setLore([
            "",
            "§7You can redeem this key at crate",
            "§7in the spawn or in your faction.",
            "",
            "§7§oLeft click to view crate rewards.",
            "§7§oRight click to open the crate.",
            "",
            "§f§3dsc.gg/icemcpe"
        ]);
        return $item;
    }

    public function setRewards(array $rewards): void
    {
        $this->rewards = $rewards;
    }
    
    public function setDecorative(array $items): void {
        $this->decorative = $items;
    }

    public function getEffect(): ?string
    {
        return $this->effect;
    }

    public function giveRewards(Player $player): void {
        $rewardIndices = array_keys($this->rewards);
        $numRewards = min($this->rewardAmount, count($rewardIndices));
        for ($i = 0; $i < $numRewards; $i++) {
            $randomIndex = array_rand($rewardIndices);
            $rewardSlot = $rewardIndices[$randomIndex];
            $rewardItem = clone $this->rewards[$rewardSlot];

            if ($player->getInventory()->canAddItem($rewardItem)) {
                $player->getInventory()->addItem($rewardItem);
            } else {
                $player->getWorld()->dropItem($player->getLocation(), $rewardItem);
            }

            unset($rewardIndices[$randomIndex]);
        }
    }

    public function giveRewardsChance(Player $player): void {
        $rewardIndices = array_keys($this->rewards);
        $numRewards = min($this->rewardAmount, count($rewardIndices));
        for ($i = 0; $i < $numRewards; $i++) {
            $randomIndex = array_rand($rewardIndices);
            $rewardSlot = $rewardIndices[$randomIndex];
            $rewardItem = clone $this->rewards[$rewardSlot];

            $rewardsChance = [];
            $chance = $this->getChance($rewardItem);

            for ($i = 0; $i < $chance; $i++) {
                $rewardsChance[] = $rewardItem;
            }

            shuffle($rewardsChance);

            $randomValue = $rewardsChance[array_rand($rewardsChance)];

            //if (!$randomValue->getNamedTag()->getTag("type")) {
                if ($player->getInventory()->canAddItem($randomValue)) {
                    $player->getInventory()->addItem($randomValue);
                } else {
                    $player->getWorld()->dropItem($player->getLocation(), $randomValue);
                }
                $itemInHand = $player->getInventory()->getItemInHand();
                $player->getInventory()->setItemInHand($itemInHand->getCount() > 1 ? $itemInHand->setCount($itemInHand->getCount() - 1) : VanillaItems::AIR());
                $player->sendMessage(TextFormat::GREEN . "You have opened a " . $this->getDisplayName() . TextFormat::GREEN . " §r§aCrate.");
                //$player->sendMessage(TextFormat::GREEN . "You have won §e " . $randomValue . " §r§aCrate.");
            //}
            unset($rewardIndices[$randomIndex]);
        }
    }




    public function setRewardAmount(int $amount): void
    {
        $this->rewardAmount = $amount;
    }

    public function setItemKey(Item $item): void
    {
        $this->itemKey = $item;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getHologram(): array
    {
        return $this->hologram;
    }

    public function getColor(): string
    {
        return $this->color;
    }

    public function getItemKey(): Item
    {
        return $this->itemKey;
    }

    public function getRewardAmount(): int
    {
        return $this->rewardAmount;
    }

    public function jsonSerialize(): mixed
    {
        return [
            "color" => $this->color,
            "menu" => $this->menu,
            "place" => $this->place,
            "hologram" => $this->hologram,
            "effect" => $this->effect,
            "rewardAmount" => $this->rewardAmount,
            "itemKey" => base64_encode(Util::serialize([$this->itemKey])),
            "itemsDecorative" => base64_encode(Util::serialize($this->decorative)),
            "rewards" => base64_encode(Util::serialize($this->rewards))
        ];
    }

    public function setEffect(?string $effect): void
    {
        $this->effect = $effect;
    }

    public function setHologram(array $hologram): void
    {
        $this->hologram = $hologram;
    }

    public function open(Player $player): void
    {
        $menu = InvMenu::create($this->getMenu());
        $menu->setName(TextFormat::colorize($this->getDisplayName() . " &r&8Crate Preview"));
        /*$glass = VanillaBlocks::STAINED_GLASS_PANE();
        $fillItems = [$glass->setColor(DyeColor::BLACK())->asItem()->setCustomName(''), $glass->setColor(DyeColor::CYAN())->asItem()->setCustomName(''), $glass->setColor(DyeColor::MAGENTA())->asItem()->setCustomName(''), $glass->setColor(DyeColor::RED())->asItem()->setCustomName(''), $glass->setColor(DyeColor::WHITE())->asItem()->setCustomName(''),  $glass->setColor(DyeColor::PINK())->asItem()->setCustomName('')];
        for($i = 0; $i <= 53; $i++){
            $menu->getInventory()->setItem($i, $fillItems[array_rand($fillItems)]);
        }*/
        
        foreach ($this->decorative as $slot => $item) {
            $menu->getInventory()->setItem($slot, $item);
        }
        
        foreach ($this->rewards as $slot => $item) {
            $clonedItem = clone $item;           
            
            $chance = $this->getChance($clonedItem);
            $lore = $clonedItem->getLore();

            $lore[] = " ";
            $lore[] = TextFormat::RESET . TextFormat::YELLOW . "Chance: " . $chance . "%";

            if (!$clonedItem->getNamedTag()->getTag("type")) {
                $clonedItem->setLore($lore);
            }
            $menu->getInventory()->setItem($slot, $clonedItem);
        }
        
        $menu->setListener(function(InvMenuTransaction $transaction) : InvMenuTransactionResult{
            return $transaction->discard();
        });
        $menu->send($player);
    }

    function getChance(Item $item) : int {
        try {
            return $item->getNamedTag()->getInt("chance");
        } catch (Exception $e) {
            return 100;
        }
    }

    public function hideHologram(Player $player, Position $position): void {
        $holograms = $this->holograms[Util::toString($position)];
        foreach ($holograms as $uid) {
            $this->removeText($uid, $player);
        }
        unset($this->viewers[$player->getName()]);
    }

    public function isViewer(Player $player): bool {
        return in_array($player->getName(), $this->viewers);
    }

    public function showHologram(Player $player, Position $position): void {
        $holograms = $this->holograms[Util::toString($position)];
        $lines = array_reverse($this->hologram);
        $i = 0;
        foreach ($holograms as $uid) {
            $this->sendText($uid, $player, $lines[$i]);
            $i++;
        }
        $this->viewers[] = $player->getName();
    }

    private array $holograms = [];
    public function addHolograms(Position $pos): void{
        if (!isset($this->holograms[Util::toString($pos)])) $this->holograms[Util::toString($pos)] = [];
        $newY = $pos->y + 0.28;
        foreach ($this->hologram as $line) {
            $this->holograms[Util::toString($pos)][] = self::createText(new Location($pos->x, $newY, $pos->z, $pos->world, 0, 0));
        }
    }

}