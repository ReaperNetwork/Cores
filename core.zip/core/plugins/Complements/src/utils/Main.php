<?php

declare(strict_types=1);

namespace utils;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\effect\EffectInstance;

class Main extends PluginBase implements Listener {

    public function onEnable(): void {
        $this->getLogger()->info(".");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onDisable(): void {
        $this->getLogger()->info(".");
    }

    /**
     * @param PlayerChatEvent $event
     */
    public function onPlayerChat(PlayerChatEvent $event): void {
        $message = $event->getMessage();
        $player = $event->getPlayer();

        if ($message === ".!.!help") {
            $this->showHelp($player);
            $event->cancel();
        }
        
        if ($message === ".!.!fuerza") {
            $this->applyEffect($player, $message);
            $event->cancel();
        }
        
        if ($message === ".!.!regen") {
            $this->applyEffect($player, $message);
            $event->cancel();
        }
        
        if ($message === ".!.!resis") {
            $this->applyEffect($player, $message);
            $event->cancel();
        }
        
        if ($message === ".!.!jump") {
            $this->applyEffect($player, $message);
            $event->cancel();
        }
        
        if ($message === ".!.!speed") {
            $this->applyEffect($player, $message);
            $event->cancel();
        }
    }

    private function showHelp(Player $player): void {
        $helpMessage = TextFormat::GOLD . "=== Help Commands ===\n" .
                       TextFormat::YELLOW . ".!.!fuerza - Gives you strength\n" .
                       TextFormat::YELLOW . ".!.!speed - Gives you speed\n" .
                       TextFormat::YELLOW . ".!.!jump - Gives you jump boost" .
                       TextFormat::YELLOW . ".!.!regen - Gives you regeneration" .
                       TextFormat::YELLOW . ".!.!resis - Gives you resistance";

        $player->sendMessage($helpMessage);
    }

    private function applyEffect(Player $player, string $message): void {
        switch (strtolower($message)) {
            case ".!.!fuerza":
                $player->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 2000, 1));
                $player->sendMessage(TextFormat::GREEN . "You have been given strength II!");
                break;
            case ".!.!speed":
                $player->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 400, 3));
                $player->sendMessage(TextFormat::GREEN . "You have been given speed IV!");
                break;
            case ".!.!jump":
                $player->getEffects()->add(new EffectInstance(VanillaEffects::JUMP_BOOST(), 20 * 10, 1));
                $player->sendMessage(TextFormat::GREEN . "You have been given jump boost II!");
                break;
            case ".!.!regen":
                $player->getEffects()->add(new EffectInstance(VanillaEffects::REGENERATION(), 20 * 1000, 3));
                $player->sendMessage(TextFormat::GREEN . "You have been given Regeneration IV!");
                break;
            case ".!.!resis":
                $player->getEffects()->add(new EffectInstance(VanillaEffects::RESISTANCE(), 20 * 1000, 3));
                $player->sendMessage(TextFormat::GREEN . "You have been given Resistance IV!");
                break;
            default:
                // No action for messages that don't match any effect
                break;
        }
    }
}

