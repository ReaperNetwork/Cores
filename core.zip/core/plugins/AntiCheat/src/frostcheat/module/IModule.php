<?php


declare(strict_types=1);

namespace frostcheat\module;

abstract class IModule {

    public const AIMBOT = 9;
    public const FLY = 8;
    public const SPEED = 7;
    public const NOCLIP = 6;
    public const AUTOCLICKER = 5;
    public const HACKEDCLIENT = 4;
    public const KILLAURA = 3;
    public const VELOCITY = 2;
    public const TIMER = 1;
    public const REACH = 0;

    public function __construct(
        private readonly int $flagId
    ) {}

    public function getFlagId(): int {
        return $this->flagId;
    }
}