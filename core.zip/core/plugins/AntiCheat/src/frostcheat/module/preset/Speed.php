<?php

namespace frostcheat\module\preset;

use frostcheat\Loader;
use frostcheat\module\IModule;
use frostcheat\session\SessionManager;
use frostcheat\util\Util;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\Listener;
use juqn\practice\session\SessionManager as SessionManagerPractice;
use hcf\HCFLoader;

class Speed extends IModule implements Listener {

    public function __construct() {
		parent::__construct($this::SPEED);
	}

    public array $lastLocation = [];

    public function checkSpeed(PlayerMoveEvent $ev){
        $player = $ev->getPlayer();
        $from = $ev->getFrom();
        $to = $ev->getTo();

        $practice = Loader::getInstance()->getServer()->getPluginManager()->getPlugin("Practice");
        $hcf = Loader::getInstance()->getServer()->getPluginManager()->getPlugin("HCF");

        if ($practice !== null) {
            $session = SessionManagerPractice::getInstance()->getSession($player);
            if ($session !== null) {
                if ($session->getPlayerData()->getEnderPearl() > 0.0) {
                    return;
                }
            }
        } 
        
        if ($hcf !== null) {
            $session = HCFLoader::getInstance()->getSessionManager()->getSession((string)$player->getUniqueId());
            if ($session !== null) {
                if ($session->getCooldown("enderpearl")) {
                    return;
                }
            }
        }

        if(isset($this->lastLocation[$player->getName()])) {
            $xDelta = abs($to->x - $this->lastLocation[$player->getName()]->x);
            $yDelta = abs($to->y - $this->lastLocation[$player->getName()]->y);
            $zDelta = abs($to->z - $this->lastLocation[$player->getName()]->z);
            $distance = sqrt($xDelta ** 2 + $yDelta ** 2 + $zDelta ** 2);
            $session = SessionManager::getInstance()->getSession($player);
            if ($session === null) return;
            if ($distance > 50) return;
            if ($player->getNetworkSession()->getPing() > 100) {
                return;
            }
            if ($distance > 18) {
                $detail = $distance;
                $session->addSpeedViolations();
                $session->speedWait = time();
                Util::getInstance()->log($this->getFlagId(), $player, $session->speedViolations, $detail, "C");
            }

            if ($distance > 15) {
                $detail = $distance;
                $session->addSpeedViolations();
                $session->speedWait = time();
                Util::getInstance()->log($this->getFlagId(), $player, $session->speedViolations, $detail, "B");
            }

            if ($distance > 12) {
                $detail = $distance;
                $session->addSpeedViolations();
                $session->speedWait = time();
                Util::getInstance()->log($this->getFlagId(), $player, $session->speedViolations, $detail, "A");
            }
        }
        $this->lastLocation[$player->getName()] = $from; 
    }
}
