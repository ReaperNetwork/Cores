<?php

declare(strict_types=1);

namespace frostcheat\module\preset;

use frostcheat\module\IModule;
use frostcheat\session\Session;
use frostcheat\session\SessionManager;
use frostcheat\util\Util;
use Exception;
use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\PlayerAuthInputPacket;
use pocketmine\player\Player;
use function microtime;

class Timer extends IModule implements Listener {

	public function __construct() {
		parent::__construct($this::TIMER);
	}

    /**
     * @throws Exception
     */
    public function verifyTimer(Player $player): void {
        if ($player->isConnected()) {
            $session = SessionManager::getInstance()->getSession($player);

            if (!$session instanceof Session) {
                return;
            }

            if (!$player->isAlive()) {
                $session->timerLastTimestamp = -1.0;
                return;
            }

            $timestamp = microtime(true);

            if ($session->timerLastTimestamp === -1.0) {
                $session->timerLastTimestamp = $timestamp;
                return;
            }

            $diff = $timestamp - $session->timerLastTimestamp;

            $session->timerBalance += 0.05;
            $session->timerBalance -= $diff;

            if ($session->timerBalance >= 0.25) {
                $session->timerBalance = 0.0;

                if (time() - $session->timerWait < 1) {
                    return;
                }
                $session->timerWait = time();

                $session->addTimerViolation();

                Util::getInstance()->log($this->getFlagId(), $player, $session->timerViolations, round($diff, 3));
            }

            $session->timerLastTimestamp = $timestamp;
        }
    }


    /**
     * @throws Exception
     * @priority HIGHEST
     */
    public function timer(DataPacketReceiveEvent $event): void {
        $player = $event->getOrigin()->getPlayer();
        $packet = $event->getPacket();
        if ($player instanceof Player and $player->isConnected() and $packet instanceof PlayerAuthInputPacket) {
            if (!$player->spawned or !$player->isSurvival()) {
            return;
        }
        $this->verifyTimer($player);
    }
}
}