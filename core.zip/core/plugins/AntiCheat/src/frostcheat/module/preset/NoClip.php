<?php

namespace frostcheat\module\preset;

use frostcheat\module\IModule;
use frostcheat\session\SessionManager;
use frostcheat\util\Util;
use pocketmine\event\player\PlayerMoveEvent;
USE pocketmine\event\Listener;
use pocketmine\math\Math;
use pocketmine\block\VanillaBlocks;

class NoClip extends IModule implements Listener {

    public function __construct() {
		parent::__construct($this::NOCLIP);
	}

    public function checkNoClip(PlayerMoveEvent $event){
        $player = $event->getPlayer();
        $bbox = $player->getBoundingBox();
        
        $minX = Math::floorFloat($bbox->minX);
        $minY = Math::floorFloat($bbox->minY);
        $minZ = Math::floorFloat($bbox->minZ);
      
        $maxX = Math::floorFloat($bbox->maxX);
        $maxY = Math::floorFloat($bbox->maxY);
        $maxZ = Math::floorFloat($bbox->maxZ);  
      
        $blocks = [];
      
        for($x = $minX; $x <= $maxX; $x++) {
            for($y = $minY; $y <= $maxY; $y++) {
                for($z = $minZ; $z <= $maxZ; $z++) {
                    $block = $player->getWorld()->getBlockAt($x, $y, $z);
              
                    if($block->isSolid()) {
                        $blocks[] = $block;
                    } else {
                        return;
                    }
                }
            }
        }

        $session = SessionManager::getInstance()->getSession($player);
      
        if(count($blocks) === 0){
            $detail = count($blocks);
            $session->addNoclipViolations();
            $session->noclipWait = time();
            Util::getInstance()->log($this->getFlagId(), $player, $session->noclipViolations, $detail, "A");
        }
    }
}
