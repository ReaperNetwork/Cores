<?php

namespace frostcheat\module\preset;

use frostcheat\module\IModule;
use frostcheat\session\SessionManager;
use frostcheat\util\Util;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\InventoryTransactionPacket;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\network\mcpe\protocol\PlayerActionPacket;
use pocketmine\network\mcpe\protocol\types\inventory\UseItemOnEntityTransactionData;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;
use pocketmine\network\mcpe\protocol\types\PlayerAction;
use pocketmine\player\Player;
use function array_unshift;
use function array_pop;
use function microtime;
use function round;
use function count;
use function array_filter;

class AutoClicker extends IModule implements Listener{

    public function __construct() {
		parent::__construct($this::AUTOCLICKER);
	}

    private const ARRAY_MAX_SIZE = 100;

    /** @var bool */
    private $countLeftClickBlock;

    /** @var array[] */
    private $clicksData = [];

    private $cps = [];

    public function initPlayerClickData(Player $p) : void{
        $this->clicksData[mb_strtolower($p->getName())] = [];
        $this->cps[mb_strtolower($p->getName())] = [];
    }

    public function addClick(Player $p) : void{
        array_unshift($this->clicksData[mb_strtolower($p->getName())], microtime(true));
        if(count($this->clicksData[mb_strtolower($p->getName())]) >= self::ARRAY_MAX_SIZE){
            array_pop($this->clicksData[mb_strtolower($p->getName())]);
        }

        $session = SessionManager::getInstance()->getSession($p);

        if ($session === null) {
            return;
        }

        if ($this->getCps($p) > 35) {
            $detail = $this->getCps($p);
            $session->addAutoclickViolations();
            $session->autoclickWait = time();
            Util::getInstance()->log($this->getFlagId(), $p, $session->autoclickViolations, $detail, "C");
            return;
        } 
        
        if ($this->getCps($p) > 26) {
            $detail = $this->getCps($p);
            $session->addAutoclickViolations();
            $session->autoclickWait = time();
            Util::getInstance()->log($this->getFlagId(), $p, $session->autoclickViolations, $detail, "B");
            return;
        }

        if ($this->getCps($p) > 20) {
            $detail = $this->getCps($p);
            $session->addAutoclickViolations();
            $session->autoclickWait = time();
            Util::getInstance()->log($this->getFlagId(), $p, $session->autoclickViolations, $detail, "A");
            return;
        }
    }

    /**
     * @param Player $player
     * @param float $deltaTime Interval of time (in seconds) to calculate CPS in
     * @param int $roundPrecision
     * @return float
     */
    public function getCps(Player $player, float $deltaTime = 1.0, int $roundPrecision = 1) : float{
        if(!isset($this->clicksData[mb_strtolower($player->getName())]) || empty($this->clicksData[mb_strtolower($player->getName())])){
            return 0.0;
        }
        $ct = microtime(true);
        return round(count(array_filter($this->clicksData[mb_strtolower($player->getName())], static function(float $t) use ($deltaTime, $ct) : bool{
            return ($ct - $t) <= $deltaTime;
        })) / $deltaTime, $roundPrecision);
    }

    public function removePlayerClickData(Player $p) : void{
        unset($this->clicksData[mb_strtolower($p->getName())]);
        unset($this->cps[mb_strtolower($p->getName())]);
    }

    public function playerJoin(PlayerJoinEvent $e) : void{
        $this->initPlayerClickData($e->getPlayer());
    }

    public function playerQuit(PlayerQuitEvent $e) : void{
        $this->removePlayerClickData($e->getPlayer());
    }

    public function packetReceive(DataPacketReceiveEvent $e) : void{
        $player = $e->getOrigin()->getPlayer();
        if($player !== null && isset($this->clicksData[mb_strtolower($player->getName())]) &&
            (
                ($e->getPacket()::NETWORK_ID === InventoryTransactionPacket::NETWORK_ID && $e->getPacket()->trData instanceof UseItemOnEntityTransactionData) ||
                ($e->getPacket()::NETWORK_ID === LevelSoundEventPacket::NETWORK_ID && $e->getPacket()->sound === LevelSoundEvent::ATTACK_NODAMAGE) ||
                ($this->countLeftClickBlock && $e->getPacket()::NETWORK_ID === PlayerActionPacket::NETWORK_ID && $e->getPacket()->action === PlayerAction::START_BREAK)
            )
        ){
            $this->addClick($player);
        }
    }
}
