<?php

namespace frostcheat\module\preset;

use frostcheat\session\SessionManager;
use frostcheat\module\IModule;
use frostcheat\util\Util;
use Exception;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\math\Vector3;

class AimBot extends IModule implements Listener {

	public function __construct() {
		parent::__construct($this::AIMBOT);
	}

    /**
     * @priority HIGHEST
     * @throws Exception
     */
    public function checkAimbot(EntityDamageByEntityEvent $event){
        $damager = $event->getDamager(); 
        $victim = $event->getEntity();
      
        if(!$damager instanceof Player || !$victim instanceof Player){
           return;
        }
      
        $dPos = $damager->getLocation();
        $vPos = $victim->getPosition();

        $dRot = $damager->getLocation();
        $dYaw = $dRot->getYaw();
        $dPitch = $dRot->getPitch();    
      
        $aimDirX = -sin(deg2rad($dYaw)) * cos(deg2rad($dPitch));
        $aimDirY = sin(deg2rad($dPitch));  
        $aimDirZ = cos(deg2rad($dYaw)) * cos(deg2rad($dPitch));   
      
        $victimDirX = $vPos->x - $dPos->x;
        $victimDirY = $vPos->y - $dPos->y;
        $victimDirZ = $vPos->z - $dPos->z;
      
        $dp = $aimDirX * $victimDirX; 
        $dp += $aimDirY * $victimDirY;
        $dp += $aimDirZ * $victimDirZ;
      
        $len1 = sqrt($aimDirX**2 + $aimDirY**2 + $aimDirZ**2);
        $len2 = sqrt($victimDirX**2 + $victimDirY**2 + $victimDirZ**2);  
        if ($len1 === 0.0 || $len2 === 0.0) {  
            return; 
        } 
        $angle = rad2deg(acos($dp / ($len1*$len2)));

        $session = SessionManager::getInstance()->getSession($damager);

        if ($angle > 150) {
            $detail = $angle;
            $session->addAimbotViolations();
            $session->aimbotWait = time();
            Util::getInstance()->log($this->getFlagId(), $damager, $session->aimbotViolations, $detail, "C");
            return;
        }
      
        if ($angle > 50 && $angle < 60) {
            $detail = $angle;
            $session->addAimbotViolations();
            $session->aimbotWait = time();
            Util::getInstance()->log($this->getFlagId(), $damager, $session->aimbotViolations, $detail, "A");
            return;
        }
    }
}