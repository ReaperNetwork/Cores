<?php

declare(strict_types=1);

namespace frostcheat\module\preset;

use frostcheat\module\IModule;
use frostcheat\util\Util;
use pocketmine\network\mcpe\protocol\types\DeviceOS;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use function explode;
use function strtoupper;

/**
 * Checks if the players using Toolbox (a popular MCPE hack client)
 */

class HackedClient extends IModule implements Listener{ 

    public function __construct() {
		parent::__construct($this::HACKEDCLIENT);
	}

    public function onJoin(PlayerJoinEvent $event): void{
        $player = $event->getPlayer();
        $playerInfo = $player->getNetworkSession()->getPlayerInfo();
        $extraData = $playerInfo->getExtraData();

        $deviceOS = $extraData["DeviceOS"];
        if($deviceOS !== DeviceOS::ANDROID) {
            return;
        }
        $deviceModel = $extraData["DeviceModel"];
        $first = explode(" ", $deviceModel)[0];
        if($first !== strtoupper($first)) {
            $array = ["device_model" => $deviceModel];
            $ret = "(";
            foreach($array as $k => $v) {
                if($ret !== "(") {
                    $ret .= ", ";
                }
                $ret .= "$k=$v";
            }
            $ret .= ")";
            Util::getInstance()->log($this->getFlagId(), $player, 1, $ret);
        }
    }
}