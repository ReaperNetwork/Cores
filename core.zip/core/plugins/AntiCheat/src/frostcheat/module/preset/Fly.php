<?php

namespace frostcheat\module\preset;

use frostcheat\module\IModule;
use frostcheat\session\SessionManager;
use frostcheat\util\Util;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\player\GameMode;

class Fly extends IModule implements Listener {

    public function __construct() {
		parent::__construct($this::FLY);
	}

    private array $lastLocation = [];
    private array $lastTimestamp = [];
    private float $timeNow;
    
    public function detectFly(PlayerMoveEvent $event) {
        $player = $event->getPlayer(); 
        $from = $event->getFrom();
        $to = $event->getTo();

        if ($player->getGamemode() === GameMode::CREATIVE) return;

        $this->timeNow = microtime(true);

        if (isset($this->lastLocation[$player->getName()])) {
            $yDifference = abs($to->y - $this->lastLocation[$player->getName()]->y);
            $timeDiff = $this->timeNow - $this->lastTimestamp[$player->getName()];

            $verticalVelocity = $yDifference/$timeDiff;
            $session = SessionManager::getInstance()->getSession($player);
            if ($session === null) return;
            if ($yDifference < 80) { 
                return;
            }
            if ($verticalVelocity > 120) {
                $detail = $verticalVelocity;
                $session->addFlyViolations();
                $session->flyWait = time();
                Util::getInstance()->log($this->getFlagId(), $player, $session->flyViolations, $detail, "C");
            }

            if ($verticalVelocity > 90) {
                $detail = $verticalVelocity;
                $session->addFlyViolations();
                $session->flyWait = time();
                Util::getInstance()->log($this->getFlagId(), $player, $session->flyViolations, $detail, "B");
            }

            if ($verticalVelocity > 77) {
                $detail = $verticalVelocity;
                $session->addFlyViolations();
                $session->flyWait = time();
                Util::getInstance()->log($this->getFlagId(), $player, $session->flyViolations, $detail, "A");
            }
        } 
        $this->lastLocation[$player->getName()] = $from;
        $this->lastTimestamp[$player->getName()] = $this->timeNow;
    }
}