<?php

namespace frostcheat\module\preset;

use frostcheat\session\SessionManager;
use frostcheat\module\IModule;
use frostcheat\util\Util;
use Exception;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\math\Vector3;
use hcf\player\disconnected\LogoutMob;

class KillAura extends IModule implements Listener {

	public function __construct() {
		parent::__construct($this::KILLAURA);
	}

    /**
     * @priority HIGHEST
     * @throws Exception
     */
    public function reach(EntityDamageByEntityEvent $event): void {
        if ($event->isCancelled()) {
            return;
        }
        $entity = $event->getEntity();
        $damager = $event->getDamager();
        if (!$damager instanceof Player || !$entity instanceof Player || $entity instanceof LogoutMob){
            return;
        }

        $blocks = $damager->getWorld()->getCollisionBlocks($damager->getBoundingBox());

        $yaw = $damager->getLocation()->getYaw();
        $pitch = $damager->getLocation()->getPitch();

        $dirX = -sin(deg2rad($yaw)) * cos(deg2rad($pitch));
        $dirY = sin(deg2rad($pitch));  
        $dirZ = cos(deg2rad($yaw)) * cos(deg2rad($pitch));
  
        $len = sqrt($dirX**2 + $dirY**2 + $dirZ**2);
        $dirX /= $len;
        $dirY /= $len;
        $dirZ /= $len;

        $targetVectorX = $entity->getPosition()->getFloorX() - $damager->getPosition()->getFloorX(); 
        $targetVectorY = $entity->getPosition()->getFloorY() - $damager->getPosition()->getFloorY();
        $targetVectorZ = $entity->getPosition()->getFloorZ() - $damager->getPosition()->getFloorZ();
    
        $angle = acos($dirX * $targetVectorX + $dirY * $targetVectorY + $dirZ * $targetVectorZ);
        $angle = rad2deg($angle);
  
        $maxAngle = 30;

        $damagerPing = $damager->getNetworkSession()->getPing();
        $playerPing = $entity->getNetworkSession()->getPing();

        $distance = $entity->getEyePos()->distance(new Vector3($damager->getEyePos()->getX(), $entity->getEyePos()->getY(), $damager->getEyePos()->getZ()));
        $distance -= $damagerPing * 0.0029;
        $distance -= $playerPing * 0.0030;
                    
        if ($distance < 1) {
            return;
        }

        if ($entity->isSprinting()) {
            $distance -= 0.97;
        } else {
            $distance -= 0.87;
        }
      
        if ($damager->isSprinting()) {
            $distance -= 0.89;
        } else {
            $distance -= 0.77;
        }
                    
        if($damagerPing > 180) {
            $distance -= 0.21;
        }

        if ($distance > 5.2) {
            $event->cancel();
            return;
        }

  
        if($angle > $maxAngle && $distance > 3) {
            $session = SessionManager::getInstance()->getSession($damager);
            $session->killauraWait = time();
            $detail = $angle;
            $session->addKillAuraViolation();
            Util::getInstance()->log($this->getFlagId(), $damager, $session->killauraViolations, $detail);
        }

        if(count($blocks) > 0 && $distance > 3) {
            $session = SessionManager::getInstance()->getSession($damager);
            $session->killauraWait = time();
            $detail = count($blocks);
            $session->addKillAuraViolation();
            if (count($blocks) > 4) {
                Util::getInstance()->log($this->getFlagId(), $damager, $session->killauraViolations, $detail, "B");
                return;
            } elseif (count($blocks) > 6) {
                Util::getInstance()->log($this->getFlagId(), $damager, $session->killauraViolations, $detail, "C");
                return;
            }
            Util::getInstance()->log($this->getFlagId(), $damager, $session->killauraViolations, $detail, "A");
        }
    }
}