<?php


declare(strict_types=1);

namespace frostcheat\module\preset;

use frostcheat\module\IModule;
use frostcheat\network\NetworkStackLatencyManager;
use frostcheat\session\Session;
use frostcheat\session\SessionManager;
use frostcheat\util\Util;
use Exception;
use pocketmine\block\Air;
use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\NetworkStackLatencyPacket;
use pocketmine\network\mcpe\protocol\PlayerAuthInputPacket;
use pocketmine\player\Player;

class Velocity extends IModule implements Listener {

	public function __construct() {
		parent::__construct($this::VELOCITY);
	}

    /**
     * @throws Exception
     * @priority HIGHEST
     */
    public function velocity(DataPacketReceiveEvent $event): void {
        $player = $event->getOrigin()->getPlayer();
        $packet = $event->getPacket();
        if ($player instanceof Player and $player->isConnected() and $packet instanceof PlayerAuthInputPacket) {
            if (!$player->spawned or !$player->isSurvival()) {
                return;
            }

            $session = SessionManager::getInstance()->getSession($player);

            if (!$session instanceof Session) {
                return;
            }

            $ping = $player->getNetworkSession()->getPing();

            if (!is_int($ping)) {
                return;
            }

            $blockAbove = $player->getWorld()->getBlockAt($player->getPosition()->getFloorX(), $player->getPosition()->getFloorY() + 2, $player->getPosition()->getFloorZ(), true, true);
            if (!$blockAbove instanceof Air) {
                return;
            }

            if ($player->isUnderwater()) {
                return;
            }

            if (is_null($session->lastLocation)) {
                $session->lastLocation = $packet->getPosition()->subtract(0, 1.62, 0);
                $session->currentMotion = null;
                return;
            }

            if (($motion = ($session->currentMotion ?? null)) !== null) {
                $movementY = $packet->getPosition()->subtract(0, 1.62, 0)->y - $session->lastLocation->y;
                if (!$player->isAlive() or $player->hasNoClientPredictions()) {
                    $motion = 0;
                    return;
                }
                if ($motion > 0.005) {
                    $percentage = ($movementY / $motion);
                    if ($percentage < 0.9999 and $percentage > 0.01) {
                        if (time() - $session->velocityWait < 1) {
                            return;
                        }
                        $session->velocityWait = time();

                        $session->addVelocityViolation();

                        Util::getInstance()->log($this->getFlagId(), $player, $session->velocityViolations, round($percentage, 3));
                    }
                    $session->currentMotion -= 0.08;
                    $session->currentMotion *= 0.98;
                } else {
                    $session->currentMotion = null;
                }
            }
            $session->lastLocation = $packet->getPosition()->subtract(0, 1.62, 0);
        } elseif ($packet instanceof NetworkStackLatencyPacket) {
            NetworkStackLatencyManager::getInstance()->execute($player, $packet->timestamp);
        }
    }
}
