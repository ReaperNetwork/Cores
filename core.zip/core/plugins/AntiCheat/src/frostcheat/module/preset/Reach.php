<?php

namespace frostcheat\module\preset;

use frostcheat\session\Session;
use frostcheat\session\SessionManager;
use frostcheat\module\IModule;
use frostcheat\util\Util;
use Exception;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByChildEntityEvent;
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\player\Player;

class Reach extends IModule implements Listener {

	public function __construct() {
		parent::__construct($this::REACH);
	}


    /**
     * @priority HIGHEST
     * @throws Exception
     */
    public function reach(EntityDamageByEntityEvent $event): void {
        if ($event->isCancelled()) {
            return;
        }
        $player = $event->getEntity();
        $cause = $event->getCause();
        if (!$event instanceof EntityDamageByChildEntityEvent) {
            if ($cause === EntityDamageEvent::CAUSE_ENTITY_ATTACK) {
                $damager = $event->getDamager();
                if ($player instanceof Player and $damager instanceof Player and $damager->isSurvival()) {
                    $session = SessionManager::getInstance()->getSession($damager);

                    if (!$session instanceof Session) {
                        return;
                    }
                    $damagerPing = $damager->getNetworkSession()->getPing();
                    $playerPing = $player->getNetworkSession()->getPing();

                    $distance = $player->getEyePos()->distance(new Vector3($damager->getEyePos()->getX(), $player->getEyePos()->getY(), $damager->getEyePos()->getZ()));
                    $distance -= $damagerPing * 0.0029;
                    $distance -= $playerPing * 0.0030;
                    
                    if ($distance < 1) {
                        return;
                    }

                    if ($player->isSprinting()) {
                        $distance -= 0.97;
                    } else {
                        $distance -= 0.87;
                    }

                    if ($damager->isSprinting()) {
                        $distance -= 0.89;
                    } else {
                        $distance -= 0.77;
                    }
                    
                    if($damagerPing > 180) {
                        $distance -= 0.21;
                    }

                    if ($distance > 6.2) {
                        $event->cancel();
                        return;
                    }

                    if ($distance > 3) {

                        $session->reachWait = time();

                        $detail = round($distance, 3);
                        $session->addReachViolation();
                        if ($distance > 5) {
                            Util::getInstance()->log($this->getFlagId(), $damager, $session->reachViolations, $detail, "B");
                            return;
                        }
                        Util::getInstance()->log($this->getFlagId(), $damager, $session->reachViolations, $detail);
                    }
                }
            }
        }
    }
}
