<?php

namespace frostcheat\module;

use pocketmine\utils\SingletonTrait;
use pocketmine\utils\TextFormat;

class ModuleUtil {
    use SingletonTrait;

    public function formatViolationMessage(int $flagId, string $player, int $ping, int $violations, float|int $details = 0.0, string $type = "A"): ?string {
        return match ($flagId) {
            IModule::REACH => TextFormat::colorize("&c[AC] $player violated &eReach &7[type: $type] [distance: $details] [ping: $ping] [x$violations]"),
            IModule::TIMER => TextFormat::colorize("&c[AC] $player violated &eTimer &7[type: $type] [difference: $details] [ping: $ping] [x$violations]"),
            IModule::VELOCITY => TextFormat::colorize("&c[AC] $player violated &eVelocity &7[type: $type] [amount: $details] [ping: $ping] [x$violations]"),
            IModule::HACKEDCLIENT => TextFormat::colorize("&c[AC] $player join used hacked client"),
            IModule::KILLAURA => TextFormat::colorize("&c[AC] $player violated &eKillaura &7[type: $type] [difference: $details] [ping: $ping] [x$violations]"),
            IModule::AUTOCLICKER => TextFormat::colorize("&c[AC] $player violated &eAutoClick &7[type: $type] [cps: $details] [ping: $ping] [x$violations]"),
            IModule::NOCLIP => TextFormat::colorize("&c[AC] $player violated &eNoClip &7[type: $type] [difference: $details] [ping: $ping] [x$violations]"),
            IModule::SPEED => TextFormat::colorize("&c[AC] $player violated &eSpeed &7[type: $type] [checked: $details] [ping: $ping] [x$violations]"),
            IModule::FLY => TextFormat::colorize("&c[AC] $player violated &eFly &7[type: $type] [checked: $details] [ping: $ping] [x$violations]"),
            IModule::AIMBOT => TextFormat::colorize("&c[AC] $player violated &eAimBot &7[type: $type] [direction: $details] [ping: $ping] [x$violations]"),
            default => null
        };
    }
}