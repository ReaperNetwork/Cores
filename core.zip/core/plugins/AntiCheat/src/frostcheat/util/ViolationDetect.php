<?php

declare(strict_types=1);

namespace frostcheat\util;

use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use frostcheat\session\Session;

class ViolationDetect extends Task {

    public function __construct(
        private readonly Session $session,
        private readonly Player $player
    ) {}

    public function onRun(): void {
        if (!$this->player->isConnected()) {
            $this->getHandler()->cancel();
            return;
        }

        if ($this->session->reachViolations > 0) {
            $this->session->reachViolations = 0;
        }
        if ($this->session->timerViolations > 0) {
            $this->session->timerViolations = 0;
        }
        if ($this->session->velocityViolations > 0) {
            $this->session->velocityViolations = 0;
        }
        if ($this->session->killauraViolations > 0) {
            $this->session->killauraViolations = 0;
        }
        if ($this->session->autoclickViolations > 0) {
            $this->session->autoclickViolations = 0;
        }
        if ($this->session->flyViolations > 0) {
            $this->session->flyViolations = 0;
        }
        if ($this->session->noclipViolations > 0) {
            $this->session->noclipViolations = 0;
        }
        if ($this->session->speedViolations > 0) {
            $this->session->speedViolations = 0;
        }
        if ($this->session->aimbotViolations > 0) {
            $this->session->aimbotViolations = 0;
        }
    }
}