<?php

declare(strict_types=1);

namespace frostcheat\util;

use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat;
use frostcheat\session\Session;

class ViolationKick extends Task {

    public function __construct(
        private readonly Session $session,
        private readonly Player $player
    ) {}

    public function onRun(): void {
        if (!$this->player->isConnected()) {
            $this->getHandler()->cancel();
            return;
        }

        if ($this->session->reachViolations >= 100) {
            Util::getInstance()->kicks(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lReach&r&7."));
            $this->player->getServer()->broadcastMessage(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lReach&r&7."));
            $this->player->kick(TextFormat::colorize("&c&lYOU HAVE BEEN KICKED.\n\n&r&cStaff&7: &eCONSOLE\n&r&cReason&7:&e Reach"));
        }
        if ($this->session->killauraViolations >= 35) {
            Util::getInstance()->kicks(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lKillAura&r&7."));
            $this->player->getServer()->broadcastMessage(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lKillAura&r&7."));
            $this->player->kick(TextFormat::colorize("&c&lYOU HAVE BEEN KICKED.\n\n&r&cStaff&7: &eCONSOLE\n&r&cReason&7:&e KillAura"));
        }
        if ($this->session->autoclickViolations >= 300) {
            Util::getInstance()->kicks(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lAutoClicker&r&7."));
            $this->player->getServer()->broadcastMessage(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lAutoClicker&r&7."));
            $this->player->kick(TextFormat::colorize("&c&lYOU HAVE BEEN KICKED.\n\n&r&cStaff&7: &eCONSOLE\n&r&cReason&7:&e AutoClicker"));
        }
        if ($this->session->speedViolations >= 50) {
            Util::getInstance()->kicks(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lSpeed&r&7."));
            $this->player->getServer()->broadcastMessage(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lSpeed&r&7."));
            $this->player->kick(TextFormat::colorize("&c&lYOU HAVE BEEN KICKED.\n\n&r&cStaff&7: &eCONSOLE\n&r&cReason&7:&e Speed"));
        }
        if ($this->session->flyViolations >= 50) {
            Util::getInstance()->kicks(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lFly&r&7."));
            $this->player->getServer()->broadcastMessage(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lFly&r&7."));
            $this->player->kick(TextFormat::colorize("&c&lYOU HAVE BEEN KICKED.\n\n&r&cStaff&7: &eCONSOLE\n&r&cReason&7:&e Fly"));
        }
        if ($this->session->noclipViolations >= 10) {
            Util::getInstance()->kicks(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lNoClip&r&7."));
            $this->player->getServer()->broadcastMessage(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lNoClip&r&7."));
            $this->player->kick(TextFormat::colorize("&c&lYOU HAVE BEEN KICKED.\n\n&r&cStaff&7: &eCONSOLE\n&r&cReason&7:&e NoClip"));
        }
        if ($this->session->timerViolations >= 10) {
            Util::getInstance()->kicks(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lTimer&r&7."));
            $this->player->getServer()->broadcastMessage(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lTimer&r&7."));
            $this->player->kick(TextFormat::colorize("&c&lYOU HAVE BEEN KICKED.\n\n&r&cStaff&7: &eCONSOLE\n&r&cReason&7:&e Timer"));
        }
        if ($this->session->velocityViolations >= 10) {
            Util::getInstance()->kicks(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lVelocity&r&7."));
            $this->player->getServer()->broadcastMessage(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lVelocity&r&7."));
            $this->player->kick(TextFormat::colorize("&c&lYOU HAVE BEEN KICKED.\n\n&r&cStaff&7: &eCONSOLE\n&r&cReason&7:&e Velocity"));
        }
        if ($this->session->aimbotViolations >= 20) {
            Util::getInstance()->kicks(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lAimBot&r&7."));
            $this->player->getServer()->broadcastMessage(TextFormat::colorize("&eCONSOLE&7 has kicked &e".$this->player->getName()."&7 for &lAimBot&r&7."));
            $this->player->kick(TextFormat::colorize("&c&lYOU HAVE BEEN KICKED.\n\n&r&cStaff&7: &eCONSOLE\n&r&cReason&7:&e AimBot"));
        }
    }
}