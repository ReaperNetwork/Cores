<?php

namespace frostcheat\util;

use frostcheat\Loader;
use frostcheat\lib\CortexPE\DiscordWebhookAPI\Embed;
use frostcheat\lib\CortexPE\DiscordWebhookAPI\Message;
use frostcheat\lib\CortexPE\DiscordWebhookAPI\Webhook;
use frostcheat\module\ModuleUtil;
use frostcheat\session\SessionManager;
use pocketmine\player\Player;
use pocketmine\utils\SingletonTrait;
use pocketmine\utils\TextFormat;

class Util {
    use SingletonTrait;

    public function getConfig(string $getter): mixed {
        return Loader::getInstance()->getConfig()->get($getter);
    }

    public function log(int $flagId, Player $player, int $violations, int|float $details, string $type = "A"): void {
        $message = ModuleUtil::getInstance()->formatViolationMessage($flagId, $player->getName(), $player->getNetworkSession()->getPing(), $violations, $details, $type);

        foreach (Loader::getInstance()->getServer()->getOnlinePlayers() as $player) {
            if(Loader::getInstance()->getServer()->isOp($player->getName()) || $player->hasPermission("alerts.message")) {
                $session = SessionManager::getInstance()->getSession($player);
                if ($session !== null && $session->isAlertsEnabled()) {
                    $player->sendMessage($message);
                }
            }
        }
        Webhook::create(Loader::getInstance()->getConfig()->get('webhook-url'))
            ->send(Message::create()
                ->addEmbed(Embed::create()
                            ->setTitle('Anti-Cheat')
                            ->setColor(0xFF8000)
                            ->setDescription(TextFormat::clean($message))
                )
            );
    }

    public function kicks(string $message) {
        Webhook::create($this->getConfig('webhook-url'))
            ->send(Message::create()
                ->addEmbed(Embed::create()
                            ->setTitle('Anti-Cheat Kick')
                            ->setColor(0xFF8000)
                            ->setDescription(TextFormat::clean($message))
                )
            );
    }

    public function logProxy(Player $player): void {
        
        Webhook::create($this->getConfig('webhook-url-proxy'))
            ->send(Message::create()
                ->addEmbed(Embed::create()
                            ->setTitle('Proxy Detected!')
                            ->setColor(0xFF8000)
                            ->setDescription("'**' . $player->getName() . '**', 'Tried to login with Proxy")
                )
            );
    }    
}