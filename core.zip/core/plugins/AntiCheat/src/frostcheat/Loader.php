<?php

declare(strict_types=1);

namespace frostcheat;

use frostcheat\command\AlertsCommand;
use frostcheat\module\preset\AimBot;
use frostcheat\module\preset\AutoClicker;
use frostcheat\module\preset\Fly;
use frostcheat\module\preset\HackedClient;
use frostcheat\module\preset\KillAura;
use frostcheat\module\preset\NoClip;
use frostcheat\module\preset\Reach;
use frostcheat\module\preset\Speed;
use frostcheat\module\preset\Timer;
use frostcheat\module\preset\Velocity;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use pocketmine\utils\TextFormat;

class Loader extends PluginBase {
    use SingletonTrait;

	protected function onLoad() : void {
		self::setInstance($this);
	}

	protected function onEnable() : void {
        $this->getLogger()->notice(TextFormat::GRAY . "Created by FrostCheatMC for AquaMC Practice" . "-" . "discord.gg/aquamcpe 4ever");
        $this->getServer()->getCommandMap()->register("anticheat", new AlertsCommand());
        $practice = Loader::getInstance()->getServer()->getPluginManager()->getPlugin("Practice");
        $hcf = Loader::getInstance()->getServer()->getPluginManager()->getPlugin("HCF");

        if ($practice !== null) {
            $this->getLogger()->notice(TextFormat::GRAY . "Plugin Extended to Practice Plugin");
        }
        if ($hcf !== null) {
            $this->getLogger()->notice(TextFormat::GRAY . "Plugin Extended to HCF Plugin");
        }

        $this->saveDefaultConfig();

        $this->register(
            new Velocity(),
            new Reach(),
            new Timer(),
            new KillAura(),
            new AutoClicker(),
            new NoClip(),
            new Fly(),
            new EventHandler()
        );
	}

    protected function onDisable(): void {
        $this->getLogger()->notice(TextFormat::GRAY . "Unloading 9 Modules");
    }

    public function register(Listener ...$handlers): void {
        foreach ($handlers as $handler) {
            $this->getServer()->getPluginManager()->registerEvents($handler, $this);
        }
    }
}