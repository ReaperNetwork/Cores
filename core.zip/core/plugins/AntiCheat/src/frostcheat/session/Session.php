<?php

declare(strict_types=1);

namespace frostcheat\session;

use Exception;
use frostcheat\util\ViolationKick;
use JsonException;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\world\Position;
use frostcheat\util\ViolationDetect;
use frostcheat\Loader;

class Session
{
    public ?float $currentMotion = null;

    public Vector3|float|null $lastLocation = null;

    public float $timerLastTimestamp = -1.0;

    public bool $alerts = true;

    public float $timerBalance = 0.0;

    public int $reachWait = -1;
    public int $timerWait = -1;
    public int $velocityWait = -1;
    public int $killauraWait = -1;
    public int $autoclickWait = -1;
    public int $noclipWait = -1;
    public int $speedWait = -1;
    public int $flyWait = -1;
    public int $aimbotWait = -1;

    public int $reachViolations = 0;
    public int $timerViolations = 0;
    public int $velocityViolations = 0;
    public int $killauraViolations = 0;
    public int $autoclickViolations = 0;
    public int $noclipViolations = 0;
    public int $speedViolations = 0;
    public int $flyViolations = 0;
    public int $aimbotViolations = 0;

    public function __construct(
        public Player $player
    ) {}

    public function onJoin(): void {
        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new ViolationDetect($this, $this->player), 20 * 60);
        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new ViolationKick($this, $this->player), 20);
    }

    /**
     * @throws Exception
     */
    public function addReachViolation(): void {
        $this->reachViolations++;
    }

    /**
     * @throws Exception
     */
    public function addTimerViolation(): void {
        $this->timerViolations++;
    }

    /**
     * @throws Exception
     */
    public function addVelocityViolation(): void {
        $this->velocityViolations++;
    }

    /**
     * @throws Exception
     */
    public function addKillAuraViolation(): void {
        $this->killauraViolations++;
    }

    /**
     * @throws Exception
     */
    public function addAutoclickViolations(): void {
        $this->autoclickViolations++;
    }

    /**
     * @throws Exception
     */
    public function addNoclipViolations(): void {
        $this->noclipViolations++;
    }

    /**
     * @throws Exception
     */
    public function addSpeedViolations(): void {
        $this->speedViolations++;
    }

    /**
     * @throws Exception
     */
    public function addFlyViolations(): void {
        $this->flyViolations++;
    }

    /**
     * @throws Exception
     */
    public function addAimbotViolations(): void {
        $this->aimbotViolations++;
    }

    public function isAlertsEnabled(): bool {
        return $this->alerts;
    }

    public function setAlertsEnabled(bool $value) {
        $this->alerts = $value;
    }
}