<?php

namespace frostcheat;

use frostcheat\session\SessionManager;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\TextFormat;

class EventHandler implements Listener {

    /*
     * @priority HIGH
     */
    public function handleLogin(PlayerLoginEvent $event): void {
        $player = $event->getPlayer();

        SessionManager::getInstance()->createSession($player);
    }

    public function handleJoin(PlayerJoinEvent $event) {
        $player = $event->getPlayer();
        $session = SessionManager::getInstance()->getSession($player);
        $session->onJoin();
    }
}