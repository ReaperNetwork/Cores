<?php

declare(strict_types=1);

namespace frostcheat\command;

use frostcheat\session\SessionManager;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;

class AlertsCommand extends Command
{

    public function __construct()
    {
        parent::__construct('alerts', 'Use command for on or off alerts', '/alerts', ["ac"]);
        $this->setPermission('alerts.message');
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender instanceof Player) {
            return;
        }

        $session = SessionManager::getInstance()->getSession($sender);
        if ($session !== null) {
            if ($session->isAlertsEnabled()) {
                $session->setAlertsEnabled(false);
                $sender->sendMessage(TextFormat::colorize("&cYou desactivated alerts of anticheat!"));
            } else {
                $session->setAlertsEnabled(true);
                $sender->sendMessage(TextFormat::colorize("&aYou activated alerts of anticheat!"));
            }
        }
    }
}