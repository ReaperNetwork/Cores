<?php

namespace rxduz\ban\listeners;

use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\utils\TextFormat;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class PlayerJoinListener - Listener
 * @package rxduz\ban\listeners
 */
class PlayerJoinListener implements Listener {
	
	/**
	 * PlayerJoinListener constructor
	 * @param Main $plugin
	 */
	public function __construct(){
		Server::getInstance()->getPluginManager()->registerEvents($this, Main::getInstance());
	}
	
	/**
	 * @param PlayerJoinEvent $ev
	 */ 
	public function onJoin(PlayerJoinEvent $ev){
		$player = $ev->getPlayer();
		
		if($player->hasPermission(Permissions::NOTIFY_MESSAGES)){
            foreach(Server::getInstance()->getOnlinePlayers() as $staffs){
                if($staffs->hasPermission(Permissions::NOTIFY_MESSAGES)){
                    $staffs->sendMessage("§7[§eStaff§7] §r" . $player->getName() . " §ajoined the server");
                }
            }
        }
	}
	
}

?>