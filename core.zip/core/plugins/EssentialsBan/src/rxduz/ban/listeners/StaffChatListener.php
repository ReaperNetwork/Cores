<?php

namespace rxduz\ban\listeners;

use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\utils\TextFormat as Color;
use rxduz\ban\utils\Permissions;
use rxduz\ban\system\StaffChat;
use rxduz\ban\Main;

/**
 * Class StaffChatListener - Listener
 * @package rxduz\ban\listeners
 */
class StaffChatListener implements Listener {
	
	/**
	 * StaffChatListener constructor
	 * @param Main $plugin
	 */
	public function __construct(){
		Server::getInstance()->getPluginManager()->registerEvents($this, Main::getInstance());
	}
	
	/**
	 * @param PlayerChatEvent $ev
	 * 
	 * * @priority HIGHEST
	 */ 
	public function onChat(PlayerChatEvent $ev): void {
		$player = $ev->getPlayer();
		
		if($ev->isCancelled()) return;
		
		if(StaffChat::getInstance()->inStaffChat($player->getName()) && $player->hasPermission(Permissions::STAFFCHAT_COMMAND_USE)){
			$message = Color::colorize(str_replace(["{staff}", "{message}"], [$player->getName(), $ev->getMessage()], Main::getInstance()->getTranslatorManager()->getMessages()["STAFFCHAT_MESSAGE"]));
			
			StaffChat::getInstance()->sendStaffMessage($message);
			$ev->cancel();
		}
	}
	
}

?>