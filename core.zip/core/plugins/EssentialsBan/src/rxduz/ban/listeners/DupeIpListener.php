<?php

namespace rxduz\ban\listeners;

use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use rxduz\ban\Main;

/**
 * Class DupeIpListener - Listener
 * @package ban\listeners
 */
class DupeIpListener implements Listener {
	
	/**
	 * DupeIpListener constructor
	 */
	public function __construct(){
		Server::getInstance()->getPluginManager()->registerEvents($this, Main::getInstance());
	}
	
	/**
	 * @param PlayerJoinEvent $ev
	 */ 
	public function onJoin(PlayerJoinEvent $ev){
		Main::getInstance()->getDupeIpManager()->searchAccount($ev->getPlayer());
	}
	
}

?>