<?php

namespace rxduz\ban\listeners;

use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\utils\TextFormat as Color;
use rxduz\ban\system\ChatCooldown;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class ChatCooldownListener - Listener
 * @package ban\listeners
 */
class ChatCooldownListener implements Listener {
	
	/**
	 * ChatCooldownListener constructor
	 */
	public function __construct(){
		Server::getInstance()->getPluginManager()->registerEvents($this, Main::getInstance());
	}
	
	/**
	 * @param PlayerChatEvent $ev
	 */ 
	public function onChat(PlayerChatEvent $ev){
		$player = $ev->getPlayer();
		
		$pluginConfig = Main::getInstance()->getProvider()->getPluginConfig();
		
		if(ChatCooldown::getInstance()->hasCooldow($player->getName())){
			if(!$player->hasPermission(Permissions::CHAT_BYPASS)){
			    $player->sendMessage(Color::colorize(str_replace("{time}", ChatCooldown::getInstance()->getCooldow($player->getName()), Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_MESSAGE_COOLDOWN_CHAT"])));
			    $ev->cancel();
			}
		} else {
			ChatCooldown::getInstance()->addCooldow($player->getName(), $pluginConfig["chat-cooldown-time"]);
		}
	}
	
}

?>