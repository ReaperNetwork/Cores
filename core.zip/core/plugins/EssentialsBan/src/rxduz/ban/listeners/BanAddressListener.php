<?php

namespace rxduz\ban\listeners;

use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\utils\TextFormat as Color;
use rxduz\ban\utils\Utils;
use rxduz\ban\Main;

/**
 * Class BanAddressListener - Listener
 * @package rxduz\ban\listeners
 */
class BanAddressListener implements Listener {
	
	/**
	 * BanAddressListener constructor
	 * @param Main $plugin
	 */
	public function __construct(){
		Server::getInstance()->getPluginManager()->registerEvents($this, Main::getInstance());
	}
	
	/**
	 * @param PlayerLoginEvent $ev
	 */ 
	public function onLogin(PlayerLoginEvent $ev){
		$player = $ev->getPlayer();
		
		$playerAddress = $player->getNetworkSession()->getIp();
		
		if(Main::getInstance()->getBanAddressManager()->isBanned($playerAddress)){
			$data = Main::getInstance()->getBanAddressManager()->getDataByPlayer($playerAddress);
		
		    if($data["permanent"]){
			    $message = Color::colorize(str_replace(["{bannedBy}", "{reason}", "{date}"], [$data["bannedBy"], $data["reason"], $data["date"]], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_KICK_PERMANENTLY_BANNED"]));
		    } else {
			    $message = Color::colorize(str_replace(["{bannedBy}", "{reason}", "{date}", "{time}"], [$data["bannedBy"], $data["reason"], $data["date"], Utils::expiredToString($data["time"])], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_KICK_TEMPORARILY_BANNED"]));
		    }
		
		    $player->kick($message);
		    Utils::banNotify($data["user"], $data["reason"]);
	    }
	}
	
}

?>