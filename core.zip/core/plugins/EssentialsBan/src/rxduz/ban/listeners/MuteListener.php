<?php

namespace rxduz\ban\listeners;

use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\player\Player;
use pocketmine\event\server\CommandEvent;
use pocketmine\utils\TextFormat as Color;
use rxduz\ban\utils\Utils;
use rxduz\ban\Main;

/**
 * Class MuteListener - Listener
 * @package ban\listeners
 */
class MuteListener implements Listener {
	
	/**
	 * MuteListener constructor
	 */
	public function __construct(){
		Server::getInstance()->getPluginManager()->registerEvents($this, Main::getInstance());
	}
	
	/**
	 * @param PlayerChatEvent $ev
	 */ 
	public function onChat(PlayerChatEvent $ev){
		$player = $ev->getPlayer();
		
		if(Main::getInstance()->getMuteManager()->isMuted($player->getName())){
			$data = Main::getInstance()->getMuteManager()->getDataByPlayer($player->getName());
		
		    if($data["permanent"]){
			    $message = Color::colorize(str_replace(["{mutedBy}", "{reason}", "{date}"], [$data["mutedBy"], $data["reason"], $data["date"]], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_MESSAGE_PERMANENTLY_MUTED"]));
		    } else {
			    $message = Color::colorize(str_replace(["{mutedBy}", "{reason}", "{date}", "{time}"], [$data["mutedBy"], $data["reason"], $data["date"], Utils::expiredToString($data["time"])], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_MESSAGE_TEMPORARILY_MUTED"]));
		    }
		
		    $player->sendMessage($message);
		    Utils::muteNotify($data["user"], $data["reason"]);
		    $ev->cancel();
			
	    }
	}
    public function onCommand(CommandEvent $ev): void {
        $sender = $ev->getSender();
        if ($sender instanceof Player) {
            $commandLine = explode(" ", $ev->getCommand());
		if(Main::getInstance()->getMuteManager()->isMuted($sender->getName())){

			$data = Main::getInstance()->getMuteManager()->getDataByPlayer($sender->getName());
		    if($data["permanent"]){

			    $message = Color::colorize(str_replace(["{mutedBy}", "{reason}", "{date}"], [$data["mutedBy"], $data["reason"], $data["date"]], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_MESSAGE_PERMANENTLY_MUTED"]));

		    } else {
			    $message = Color::colorize(str_replace(["{mutedBy}", "{reason}", "{date}", "{time}"], [$data["mutedBy"], $data["reason"], $data["date"], Utils::expiredToString($data["time"])], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_MESSAGE_TEMPORARILY_MUTED"]));
		    }
            if (!isset($commandLine[0])) return;
            if ($commandLine[0] == "/") $command = Server::getInstance()->getCommandMap()->getCommand(substr($commandLine[0], 1));
            else $command = Server::getInstance()->getCommandMap()->getCommand($commandLine[0]);
            if ($command !== null) {
                 $blockedCommands = ["tell", "w", "msg"];
                $anyAliasBlocked = in_array($command->getName(), $blockedCommands);
                if (!$anyAliasBlocked) foreach (array_filter($command->getAliases(), fn(string $alias) => in_array($alias, $blockedCommands)) as $alias) {
                    $anyAliasBlocked = true;
                    break;
                }
            if ($anyAliasBlocked) {
		    $sender->sendMessage($message);
		    Utils::muteNotify($data["user"], $data["reason"]);
		    $ev->cancel();
                    }
                }
            }
        }
	}
}

?>