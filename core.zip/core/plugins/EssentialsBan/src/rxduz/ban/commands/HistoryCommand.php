<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class HistoryCommand - Command
 * @package rxduz\ban\commands
 */
class HistoryCommand extends Command {
	
	/**
	 * HistoryCommand constructor
	 */
	public function __construct(){
		parent::__construct("history", "View history for player", null, []);
		
		$this->setPermission(Permissions::HISTORY_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $commandLabel
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0])){
			$sender->sendMessage(Color::RED . "use /history (target)");
			
			return;
		}
		
		$name = $args[0];
		
		if(($player = Server::getInstance()->getPlayerByPrefix($args[0])) instanceof Player){
			$name = $player->getName();
		}
		
		$message = Color::AQUA . "==== History for " . Color::YELLOW . $name . Color::AQUA . " ====" . Color::RESET . PHP_EOL;
		
		if(Main::getInstance()->getBanManager()->isBanned($name)){
			
			$banData = Main::getInstance()->getBanManager()->getDataByPlayer($name);
			
			$message .= Color::GRAY . "Banned: " . Color::GREEN . "Yes " . PHP_EOL . Color::GRAY . "Banned by: " . Color::YELLOW . $banData["bannedBy"] . Color::GRAY . " Date: " . Color::YELLOW . $banData["date"] . PHP_EOL;
			
		} else {
			
			$message .= Color::GRAY . "Banned: " . Color::RED . "No" . PHP_EOL;
		
		}
		
		$address = Main::getInstance()->getBanAddressManager()->searchAddressBanned($name);
		
		if(!is_null($address)){
			
			$banData = Main::getInstance()->getBanAddressManager()->getDataByPlayer($address);
			
			$message .= Color::GRAY . "Banned (Address): " . Color::GREEN . "Yes " . PHP_EOL . Color::GRAY . "Banned by: " . Color::YELLOW . $banData["bannedBy"] . Color::GRAY . " Date: " . Color::YELLOW . $banData["date"] . PHP_EOL;
			
		} else {
			
			$message .= Color::GRAY . "Banned (Address): " . Color::RED . "No" . PHP_EOL;
			
		}
		
		if(Main::getInstance()->getMuteManager()->isMuted($name)){
			
			$muteData = Main::getInstance()->getMuteManager()->getDataByPlayer($name);
			
			$message .= Color::GRAY . "Muted: " . Color::GREEN . "Yes " . PHP_EOL . Color::GRAY . "Muted by: " . Color::YELLOW . $muteData["mutedBy"] . Color::GRAY . " Date: " . Color::YELLOW . $muteData["date"] . PHP_EOL;
			
		} else {
			
			$message .= Color::GRAY . "Muted: " . Color::RED . "No" . PHP_EOL;
		
		}
		
		if(count(Main::getInstance()->getWarnManager()->getWarnsPlayer($name)) > 0){
			
			$message .= Color::GRAY . "Warns: " . Color::YELLOW . implode(", ", Main::getInstance()->getWarnManager()->getWarnsPlayer($name));
			
		} else {
			
			$message .= Color::GRAY . "Warns: " . Color::RED . "Empty";
			
		}
		
		$sender->sendMessage($message);
		
		return;
	}
	
}

?>