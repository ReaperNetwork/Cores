<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Utils;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class ReportCommand - Command
 * @package ban\commands
 */
class ReportCommand extends Command {
	
	/**
	 * ReportCommand constructor
	 */
	public function __construct(){
		parent::__construct("report", "Report player", null, ["hacker"]);
        $this->setPermission("bancomponents.command.report");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $label
	 * @param array $args
	 */
	public function execute(CommandSender $sender, string $label, array $args) : void {
		if(!$sender instanceof Player){
			$sender->sendMessage(Color::RED . "Use this command in the game!");
			
			return;
		}
		
		if(!isset($args[0], $args[1])){
			$sender->sendMessage(Color::RED . "Use /" . $label . " (player) (reason)");
			
			return;
		}
		
		$name = $args[0];
		
		if(($player = Server::getInstance()->getPlayerByPrefix($args[0])) instanceof Player){
			$name = $player->getName();
		}
		
		if($name == $sender->getName()){
			$sender->sendMessage(Color::RED . "Why do you select yourself?");
			
			return;
		}
		
		$translator = Main::getInstance()->getTranslatorManager()->getMessages();
		
		$sender->sendMessage(Color::colorize(str_replace("{user}", $name, $translator["REPORT_SUCCESSFULLY"])));
		
		$reason = implode(" ", array_splice($args, 1));
		
		$message = Color::colorize(str_replace(["{reported}", "{player}", "{reason}"], [$name, $sender->getName(), $reason], $translator["NEW_REPORT_RECEIVED"]));
		
		Utils::notifyConsole($message);

		Utils::createWebHook($name, $reason, $sender->getName());
		
		foreach(Server::getInstance()->getOnlinePlayers() as $players){
			if($players->hasPermission(Permissions::NOTIFY_MESSAGES)){
				$players->sendMessage($message);
			}
	    }
		
		return;
	}
	
}

?>