<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use rxduz\ban\utils\Utils;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class TBanIPCommand - Command
 * @package ban\commands
 */
class TBanIPCommand extends Command {
	
	/**
	 * TBanIPCommand constructor
	 */
	public function __construct(){
		parent::__construct("tban-ip", "Ban address player temporary", null, []);
		
		$this->setPermission(Permissions::TBANIP_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $label
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $label, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0]) || !isset($args[1]) || !isset($args[2])){
			$sender->sendMessage(Color::RED . "use /tban-ip (target) (time) (reason)");
			
			return;
		}
		
		$target = Server::getInstance()->getPlayerByPrefix($args[0]);
		
		if(!$target instanceof Player){
			$sender->sendMessage(Color::RED . "Player is not online!");
			
			return;
		}
		
		if(Main::getInstance()->getBanAddressManager()->isBanned($target->getNetworkSession()->getIp())){
			$sender->sendMessage(Color::RED . $target->getName() . " is already banned!");
			
			return;
		}
		
		$time = Utils::replaceTimer($args[1]);
		
		$timeToString = (Utils::intCharacters($args[1]) . " " . Utils::stringCharacters($args[1]));
		
		if(is_null($time)){
			$sender->sendMessage(Color::RED . "Time format is invalid!");
			
			return;
		}
		
		unset($args[0], $args[1]);
		
		$reason = implode(" ", $args);
		
		$date = date(Main::getInstance()->getProvider()->getPluginConfig()["date-format"]);
		
		Main::getInstance()->getBanAddressManager()->addBan($target->getNetworkSession()->getIp(), $target->getName(), $sender->getName(), $reason, $time, $date);
		
		$target->kick(Color::colorize(str_replace(["{bannedBy}", "{reason}", "{date}", "{time}"], [$sender->getName(), $reason, $date, Utils::expiredToString($time)], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_KICK_TEMPORARILY_BANNED"])));
		
		$message = Color::colorize(str_replace(["{user}", "{bannedBy}", "{time}", "{reason}"], [$target->getName(), $sender->getName(), $timeToString, $reason], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_TEMPORARILY_BANNED"]));
		
		Server::getInstance()->broadcastMessage($message);
		
		Utils::notifyConsole($message);
		
		return;
	}
	
}

?>