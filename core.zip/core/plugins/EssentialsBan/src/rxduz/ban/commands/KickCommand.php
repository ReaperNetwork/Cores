<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Utils;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class KickCommand - Command
 * @package rxduz\ban\commands
 */
class KickCommand extends Command {
	
	/**
	 * KickCommand constructor
	 */
	public function __construct(){
		parent::__construct("kick", "Kick player from the server", null, []);
		
		$this->setPermission(Permissions::KICK_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $commandLabel
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0]) || !isset($args[1])){
			$sender->sendMessage(Color::RED . "use /kick (target) (reason)");
			
			return;
		}
		
		$target = Server::getInstance()->getPlayerByPrefix($args[0]);
		
		if(!$target instanceof Player){
			$sender->sendMessage(Color::RED . "Player is not online!");
			
			return;
		}
		
		$reason = implode(" ", array_slice($args, 1));
		
		$target->kick(Color::colorize(str_replace(["{kickedBy}", "{reason}"], [$sender->getName(), $reason], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_KICK"])));
		
		$message = Color::colorize(str_replace(["{user}", "{kickedBy}", "{reason}"], [$target->getName(), $sender->getName(), $reason], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_KICKED"]));
		
		Server::getInstance()->broadcastMessage($message);
		
		Utils::notifyConsole($message);
		
		return;
	}
	
}

?>