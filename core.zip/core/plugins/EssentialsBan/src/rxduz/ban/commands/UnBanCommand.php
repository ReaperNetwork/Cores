<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use rxduz\ban\utils\Utils;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class UnBanCommand - PluginCommand
 * @package ban\commands
 */
class UnBanCommand extends Command {
	
	/**
	 * UnBanCommand constructor
	 * @param Main $plugin
	 */
	public function __construct(){
		parent::__construct("pardon", "Pardon player", null, ["unban"]);
		
		$this->setPermission(Permissions::PARDON_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $label
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $label, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0])){
			$sender->sendMessage(Color::RED . "use /" . $label . " (name)");
			
			return;
		}
		
		if(!Main::getInstance()->getBanManager()->isBanned($args[0])){
			$sender->sendMessage(Color::RED . $args[0] . " is not banned!");
			
			return;
		}
		
	    Main::getInstance()->getBanManager()->removeBan($args[0]);
		
		$message = Color::colorize(str_replace(["{user}", "{unbannedBy}"], [$args[0], $sender->getName()], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_UNBANNED"]));
		
		Utils::notifyConsole($message);
		foreach(Server::getInstance()->getOnlinePlayers() as $players){
			if($players->hasPermission(Permissions::NOTIFY_MESSAGES)){
				$players->sendMessage($message);
			}
	    }
		
		return;
	}
	
}

?>