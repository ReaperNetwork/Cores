<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Utils;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class BanIPCommand - Command
 * @package rxduz\ban\commands
 */
class BanIPCommand extends Command {
	
	/**
	 * BanIPCommand constructor
	 */
	public function __construct(){
		parent::__construct("ban-ip", "Ban address player permanently", null, []);
		
		$this->setPermission(Permissions::BANIP_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command!");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $commandLabel
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0], $args[1])){
			$sender->sendMessage(Color::RED . "use /ban-ip (target) (reason)");
			
			return;
		}
		
		if(!($player = Server::getInstance()->getPlayerByPrefix($args[0])) instanceof Player){
			$sender->sendMessage(Color::RED . "Player is not online!");
			
			return;
		}

		$address = $player->getNetworkSession()->getIp();

		$name = $player->getName();
		
		if(Main::getInstance()->getBanAddressManager()->isBanned($address)){
			$sender->sendMessage(Color::RED . $name . " is already banned!");
			
			return;
		}
		
		$reason = implode(" ", array_slice($args, 1));
		
		$this->processIPBan($address, $name, $sender->getName(), $reason);
		
		$message = Color::colorize(str_replace(["{user}", "{bannedBy}", "{reason}"], [$name, $sender->getName(), $reason], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_PERMANENTLY_BANNED"]));
		
		Server::getInstance()->broadcastMessage($message);
		
		Utils::notifyConsole($message);
		
		return;
	}
	
	public function processIPBan(string $address, string $name, string $bannedBy, string $reason) : void {
		$date = date(Main::getInstance()->getProvider()->getPluginConfig()["date-format"]);
		
		Main::getInstance()->getBanAddressManager()->addBan($address, $name, $bannedBy, $reason, 0, $date);
		
		foreach(Server::getInstance()->getOnlinePlayers() as $player){
			if($player->getNetworkSession()->getIp() === $address){
				$player->kick(Color::colorize(str_replace(["{bannedBy}", "{reason}", "{date}"], [$bannedBy, $reason, $date], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_KICK_PERMANENTLY_BANNED"])));
			}
		}
	}
	
}

?>