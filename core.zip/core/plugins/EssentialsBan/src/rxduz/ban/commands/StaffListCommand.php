<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class StaffListCommand - Command
 * @package ban\commands
 */
class StaffListCommand extends Command {
	
	/**
	 * StaffListCommand constructor
	 */
	public function __construct(){
		parent::__construct("stafflist", "See staffs available on the server", null, ["staffs"]);
        $this->setPermission("bancomponents.command.stafflist");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $label
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $label, array $args) : void {
		$staffs = [];
		
        foreach(Server::getInstance()->getOnlinePlayers() as $players){
			if($players->hasPermission(Permissions::STAFFCHAT_COMMAND_USE)){
				$staffs[] = $players->getName();
			}
	    }

        if(empty($staffs)){
            $sender->sendMessage(TextFormat::RED . "There are no staffs available on the server!");

            return;
        }

        $sender->sendMessage(TextFormat::GREEN . "Staffs Online: " . TextFormat::WHITE . count($staffs) . TextFormat::EOL . TextFormat::YELLOW . implode(", ", $staffs));
		return;
	}
	
}

?>