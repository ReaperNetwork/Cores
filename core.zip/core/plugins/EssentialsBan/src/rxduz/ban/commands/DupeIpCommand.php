<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class DupeIpCommand - Command
 * @package rxduz\ban\commands
 */
class DupeIpCommand extends Command {
	
	/**
	 * DupeIpCommand constructor
	 */
	public function __construct(){
		parent::__construct("dupeip", "Scanning player and view accounts", null, []);
		
		$this->setPermission(Permissions::DUPEIP_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $commandLabel
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0])){
			$sender->sendMessage(Color::RED . "use /dupeip (target)");
			
			return;
		}
		
		$name = $args[0];
		
		if(($player = Server::getInstance()->getPlayerByPrefix($args[0])) instanceof Player){
			$name = $player->getName();
		}
		
		$accounts = Main::getInstance()->getDupeIpManager()->getAccountsByName($name);
		
		if(empty($accounts)){
			$sender->sendMessage(Color::RED . "This account is not registered in the database!");
			
			return;
		}
		
		$message = Color::WHITE . "Scanning: " . Color::GREEN . $name . Color::WHITE . " on " . Color::GREEN . count($accounts) . Color::WHITE . " IP" . (count($accounts) == 1 ? "" : "(s)") . PHP_EOL;
		
		foreach($accounts as $address => $value){
			$message .= Color::GREEN . $address . " " . Color::GRAY . implode(", ", $value) . " ";
		}
		
		$sender->sendMessage($message);
		
		return;
	}
	
}

?>