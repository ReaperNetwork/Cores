<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Utils;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class MuteCommand - Command
 * @package rxduz\ban\commands
 */
class MuteCommand extends Command {
	
	/**
	 * MuteCommand constructor
	 */
	public function __construct(){
		parent::__construct("mute", "Mute player permanently", null, []);
		
		$this->setPermission(Permissions::MUTE_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $commandLabel
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
		         if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0]) || !isset($args[1])){
			$sender->sendMessage(Color::RED . "use /mute (target) (reason)");
			
			return;
		}
		
		$target = Server::getInstance()->getPlayerByPrefix($args[0]);
		
		if(!$target instanceof Player){
			$target = Server::getInstance()->getOfflinePlayer($args[0]);
		}
		
		if(Main::getInstance()->getMuteManager()->isMuted($target->getName())){
			$sender->sendMessage(Color::RED . $target->getName() . " is already muted!");
			
			return;
		}
		
		$reason = implode(" ", array_slice($args, 1));
		
		$date = date(Main::getInstance()->getProvider()->getPluginConfig()["date-format"]);
		
		Main::getInstance()->getMuteManager()->addMute($target->getName(), $sender->getName(), $reason, 0, $date);
		
		if($target instanceof Player && $target->isOnline()){
		    $target->sendMessage(Color::colorize(str_replace(["{mutedBy}", "{reason}", "{date}"], [$sender->getName(), $reason, $date], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_MESSAGE_PERMANENTLY_MUTED"])));
		}
		
		$message = Color::colorize(str_replace(["{user}", "{mutedBy}", "{reason}"], [$target->getName(), $sender->getName(), $reason], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_PERMANENTLY_MUTED"]));
		
		Server::getInstance()->broadcastMessage($message);
		
		Utils::notifyConsole($message);
		
		return;
	}
	
}

?>