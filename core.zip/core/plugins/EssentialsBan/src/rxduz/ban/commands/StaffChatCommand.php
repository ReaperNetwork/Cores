<?php

namespace rxduz\ban\commands;

use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Permissions;
use rxduz\ban\system\StaffChat;
use rxduz\ban\Main;

/**
 * Class StaffChatCommand - Command
 * @package ban\commands
 */
class StaffChatCommand extends Command {
	
	/**
	 * StaffChatCommand constructor
	 */
	public function __construct(){
		parent::__construct("staffchat", "Send message to staff", null, ["sc"]);
		
		$this->setPermission(Permissions::STAFFCHAT_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $label
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $label, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		// If the message is by CONSOLE
		if(!$sender instanceof Player){
			$message = Color::colorize(str_replace(["{staff}", "{message}"], ["CONSOLE", implode(" ", $args)], Main::getInstance()->getTranslatorManager()->getMessages()["STAFFCHAT_MESSAGE"]));
			
			StaffChat::getInstance()->sendStaffMessage($message);
			
			return;
		}
		
		if(StaffChat::getInstance()->inStaffChat($sender->getName())){
			StaffChat::getInstance()->removeStaffChat($sender->getName());
			
			$sender->sendMessage(Color::RED . "StaffChat disabled!");
		} else {
			StaffChat::getInstance()->addStaffChat($sender->getName());
			
			$sender->sendMessage(Color::GREEN . "StaffChat enabled!");
		}
		
		return;
	}
	
}

?>