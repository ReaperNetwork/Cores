<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Utils;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class ClearWarnCommand - PluginCommand
 * @package rxduz\ban\commands
 */
class ClearWarnCommand extends Command {
	
	/**
	 * ClearWarnCommand constructor
	 */
	public function __construct(){
		parent::__construct("clearwarn", "Clean up warns from player", null, []);
		
		$this->setPermission(Permissions::CLEARWARN_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $commandLabel
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0])){
			$sender->sendMessage(Color::RED . "use /clearwarn (name)");
			
			return;
		}
		
		if(count(Main::getInstance()->getWarnManager()->getWarnsPlayer($args[0])) == 0){
			$sender->sendMessage(Color::RED . $args[0] . " does not have any warns!");
			
			return;
		}
		
	    Main::getInstance()->getWarnManager()->clearWarns($args[0]);
		
		$message = Color::colorize(str_replace(["{user}", "{clearwarnBy}"], [$args[0], $sender->getName()], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_CLEARWARN"]));
		
		Utils::notifyConsole($message);
		
		foreach(Server::getInstance()->getOnlinePlayers() as $players){
			if($players->hasPermission(Permissions::NOTIFY_MESSAGES)){
				$players->sendMessage($message);
			}
	    }
		
		return;
	}
	
}

?>