<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Utils;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class WarnCommand - Command
 * @package ban\commands
 */
class WarnCommand extends Command {
	
	/**
	 * WarnCommand constructor
	 */
	public function __construct(){
		parent::__construct("warn", "Add warning to player", null, []);
		
		$this->setPermission(Permissions::WARN_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $label
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $label, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0]) || !isset($args[1])){
			$sender->sendMessage(Color::RED . "use /warn (target) (reason)");
			
			return;
		}
		
		$name = $args[0];
		
		if(($player = Server::getInstance()->getPlayerByPrefix($args[0])) instanceof Player){
			$name = $player->getName();
		}
		
		$reason = implode(" ", array_slice($args, 1));
		
		$date = date(Main::getInstance()->getProvider()->getPluginConfig()["date-format"]);
		
		if(count(Main::getInstance()->getWarnManager()->getWarnsPlayer($name)) >= Main::getInstance()->getProvider()->getPluginConfig()["max-warns-player"]){
			$sender->sendMessage(Color::YELLOW . $name . Color::RED . " Reached the limit of wars " . "(" . count(Main::getInstance()->getWarnManager()->getWarnsPlayer($name)) . ")");
			
			return;
		}
		
		Main::getInstance()->getWarnManager()->addWarn($name, $reason . " WarnBy: " . $sender->getName() . " Date: " . $date);
		
		$message = Color::colorize(str_replace(["{user}", "{warnBy}", "{reason}"], [$name, $sender->getName(), $reason], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_WARN"]));
		
		Server::getInstance()->broadcastMessage($message);
		
		Utils::notifyConsole($message);
		
		return;
	}
	
}

?>