<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class ClearIpCommand - Command
 * @package rxduz\ban\commands
 */
class ClearIpCommand extends Command {
	
	/**
	 * ClearIpCommand constructor
	 */
	public function __construct(){
		parent::__construct("clearip", "Deleted player ips", null, []);
		
		$this->setPermission(Permissions::CLEARIP_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $commandLabel
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0])){
			$sender->sendMessage(Color::RED . "use /clearip (target)");
			
			return;
		}
		
		$name = $args[0];
		
		if(($player = Server::getInstance()->getPlayerByPrefix($args[0])) instanceof Player){
			$name = $player->getName();
		}
		
		$accounts = Main::getInstance()->getDupeIpManager()->getAccountsByName($name);
		
		if(empty($accounts)){
			$sender->sendMessage(Color::RED . "This account is not registered in the database!");
			
			return;
		}
		
		Main::getInstance()->getDupeIpManager()->removeAccount($name);
		
		$sender->sendMessage(Color::GREEN . "Removed " . count($accounts) . " address of the player: " . $name);
		
		return;
	}
	
}

?>