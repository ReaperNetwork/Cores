<?php

namespace rxduz\ban\commands;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use rxduz\ban\utils\Utils;
use rxduz\ban\utils\Permissions;
use rxduz\ban\Main;

/**
 * Class BanCommand - Command
 * @package rxduz\ban\commands
 */
class BanCommand extends Command {
	
	/**
	 * BanCommand constructor
	 */
	public function __construct(){
		parent::__construct("ban", "Ban player permanently", null, []);
		
		$this->setPermission(Permissions::BAN_COMMAND_USE);
		
		$this->setPermissionMessage(Color::RED . "You do not have permissions to use this command!");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param string $commandLabel
	 * @param Array[] $args
	 */
	public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
		        if (!$this->testPermissionSilent($sender)) {
            $sender->sendMessage("§cYou do not have permission to use this command.");
			
			return;
		}
		
		if(!isset($args[0], $args[1])){
			$sender->sendMessage(Color::RED . "use /ban (target) (reason)");
			
			return;
		}
		
		$target = Server::getInstance()->getPlayerByPrefix($args[0]);
		
		if(!$target instanceof Player){
			$target = Server::getInstance()->getOfflinePlayer($args[0]);
		}
		
		if(Main::getInstance()->getBanManager()->isBanned($target->getName())){
			$sender->sendMessage(Color::RED . $target->getName() . " is already banned!");
			
			return;
		}
		
		$reason = implode(" ", array_slice($args, 1));
		
		$date = date(Main::getInstance()->getProvider()->getPluginConfig()["date-format"]);
		
		Main::getInstance()->getBanManager()->addBan($target->getName(), $sender->getName(), $reason, 0, $date);
		
		if($target instanceof Player && $target->isOnline()){
		    $target->close("", Color::colorize(str_replace(["{bannedBy}", "{reason}", "{date}"], [$sender->getName(), $reason, $date], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_KICK_PERMANENTLY_BANNED"])));
		}
		
		$message = Color::colorize(str_replace(["{user}", "{bannedBy}", "{reason}"], [$target->getName(), $sender->getName(), $reason], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_PERMANENTLY_BANNED"]));
		
		Server::getInstance()->broadcastMessage($message);
		Utils::notifyConsole($message);
		
		return;
	}
	
}

?>