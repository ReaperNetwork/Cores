<?php

namespace rxduz\ban\system;

use pocketmine\utils\Config;
use rxduz\ban\Main;

/**
 * Class WarnManager
 * @package rxduz\ban\system
 */
class WarnManager {
	
	/** @var Array[] */
	private array $warns = [];
	
	/** @var Config */
	private Config $data;
	
	public function __construct(){
		$this->data = Main::getInstance()->getProvider()->getNewConfig("players/warns");
		
		foreach($this->data->getAll() as $name => $value){
			$this->warns[strtolower($name)] = $value;
		}
	}
	
	/*
	 * @return array $warns
	 */
	public function getWarns() : array {
		return $this->warns;
	}
	
	/**
	 * @param string $name
	 * @return array $warns
	 */
	public function getWarnsPlayer(string $name) : array {
		return $this->warns[strtolower($name)]["warns"] ?? [];
	}
	
	/**
	 * @param string $name
	 * @param string $reason
	 */
	public function addWarn(string $name, string $reason){
		$warns = [];
		
		if(count($this->getWarnsPlayer($name)) > 0){
			$warns = $this->getWarnsPlayer($name);
             
             
		}
		
		if(!in_array($reason, $warns)){
			array_push($warns, $reason);
		}
		
		$this->warns[strtolower($name)]["warns"] = $warns;
         $this->save(); 
	}
	
	/**
	 * @param string $name
	 */
	public function clearWarns(string $name){
		if(isset($this->warns[strtolower($name)])){
			unset($this->warns[strtolower($name)]);
             $this->save(); 
		}
	}
	
    /**
     * Save the last sanctions when shutting down the server
     */
    public function save(){
		$this->data->setAll($this->getWarns());
		$this->data->save();
	}
	
}

?>