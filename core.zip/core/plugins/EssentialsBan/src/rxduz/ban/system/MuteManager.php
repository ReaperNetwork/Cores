<?php

namespace rxduz\ban\system;

use pocketmine\utils\Config;
use rxduz\ban\Main;

/**
 * Class MuteManager
 * @package rxduz\ban\system
 */
class MuteManager {
	
	/** @var Array[] */
	private array $mutes = [];
	
	/** @var Config */
	private Config $data;
	
	public function __construct(){
		$this->data = Main::getInstance()->getProvider()->getNewConfig("players/mutes");
		
		foreach($this->data->getAll() as $name => $value){
			$this->mutes[strtolower($name)] = $value;
		}
	}
	
	/*
	 * @return array $mutes
	 */
	public function getMutes() : array {
		return $this->mutes;
	}
	
	/*
	 * @param string $name
	 * @return array $mutes
	 */
	public function getDataByPlayer(string $name) : array {
		return $this->mutes[strtolower($name)] ?? [];
	}
	
	/**
	 * @param string $name
	 * @param string $mutedBy
	 * @param string $reason
	 * @param int $time
	 * @param string $date
	 */
	public function addMute(string $name, string $mutedBy, string $reason, int $time, string $date){
		if($time > 0){
			$permanent = false;
		} else {
			$permanent = true;
		}
		
		$data = [
		    "user" => strtolower($name),
		    "mutedBy" => strtolower($mutedBy),
		    "reason" => $reason,
		    "permanent" => $permanent,
		    "time" => $time,
		    "date" => $date
		];
		
		$this->mutes[strtolower($name)] = $data;
         $this->save(); 
	}
	
	/**
	 * @param string
	 */
	public function removeMute(string $name){
		if(isset($this->mutes[strtolower($name)])){
			unset($this->mutes[strtolower($name)]);
             $this->save(); 
		}
	}
	
	/*
	 * @param string $name
	 * @return bool
	 */
	public function isMuted(string $name) : bool {
		return isset($this->mutes[strtolower($name)]);
	}
    
    /**
     * Save the last sanctions when shutting down the server
     */
    public function save(){
		$this->data->setAll($this->mutes);
		$this->data->save();
	}
	
}

?>