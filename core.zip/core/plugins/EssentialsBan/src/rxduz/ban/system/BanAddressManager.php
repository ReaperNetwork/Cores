<?php

namespace rxduz\ban\system;

use pocketmine\utils\Config;
use rxduz\ban\Main;

/**
 * Class BanAddressManager
 * @package rxduz\ban\system
 */
class BanAddressManager {
	
	/** @var Array[] */
	private array $bans = [];
	
	/** @var Config */
	private Config $data;
	
	public function __construct(){
		$this->data = Main::getInstance()->getProvider()->getNewConfig("players/bansaddress");
		
		foreach($this->data->getAll() as $address => $value){
			$this->bans[$address] = $value;
		}
	}
	
	public function getBans() : array {
		return $this->bans;
	}
	
	public function getDataByPlayer(string $address) : array {
		return $this->bans[$address] ?? [];
	}
	
	public function searchAddressBanned(string $name) : ? string {
		foreach($this->getBans() as $key => $value){
			if($value["user"] == strtolower($name)){
				return $key;
			}
		}
		
		return null;
	}
	
	/**
	 * @param string $address
	 * @param string $name
	 * @param string $bannedBy
	 * @param string $reason
	 * @param int $time
	 * @param string $date
	 */
	public function addBan(string $address, string $name, string $bannedBy, string $reason, int $time, string $date){
		if($time > 0){
			$permanent = false;
		} else {
			$permanent = true;
		}
		
		$data = [
		    "user" => strtolower($name),
		    "bannedBy" => strtolower($bannedBy),
		    "reason" => $reason,
		    "permanent" => $permanent,
		    "time" => $time,
		    "date" => $date
		];
		
		$this->bans[$address] = $data;
         $this->save(); 
	}
	
	/**
	 * @param string
	 */
	public function removeBan(string $address){
		if(isset($this->bans[$address])){
		    unset($this->bans[$address]);
             $this->save(); 
		}
	}
	
	public function isBanned(string $address) : bool {
		return isset($this->bans[$address]);
	}
    
    /**
     * Save the last sanctions when shutting down the server
     */
    public function save(){
		$this->data->setAll($this->bans);
		$this->data->save();
	}
	
}

?>