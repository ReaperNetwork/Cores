<?php

namespace rxduz\ban\system;

use pocketmine\Server;
use rxduz\ban\utils\Utils;
use rxduz\ban\utils\Permissions;
use rxduz\ban\utils\InstancePluginReference;


/**
 * Class StaffChat
 * @package rxduz\ban\system
 */
class StaffChat {
	
	use InstancePluginReference;
	
	/** @var Array[] */
	private array $chatPlayers = [];
	
	/**
	 * @param string $name
	 * @return bool 
	 */
	public function inStaffChat(string $name) : bool {
		return in_array($name, $this->chatPlayers);
	}
	
	/**
	 * @param string $name
	 */
	public function addStaffChat(string $name){
		array_push($this->chatPlayers, $name);
	}
	
	/**
	 * @param string $name
	 */
	public function removeStaffChat(string $name){
		$this->chatPlayers = array_diff($this->chatPlayers, [$name]);
	}
	
	/**
	 * @param string $message
	 */
	public function sendStaffMessage(string $message){
		Utils::notifyConsole($message);
		
		foreach(Server::getInstance()->getOnlinePlayers() as $players){
			if($players->hasPermission(Permissions::NOTIFY_MESSAGES)){
				$players->sendMessage($message);
			}
	    }
	}
	
}

?>