<?php

namespace rxduz\ban\system;

use pocketmine\utils\Config;
use rxduz\ban\Main;

/**
 * Class BanManager
 * @package rxduz\ban\system
 */
class BanManager {
	
	/** @var Array[] */
	private array $bans = [];
	
	/** @var Config */
	private Config $data;
	
	public function __construct(){
		$this->data = Main::getInstance()->getProvider()->getNewConfig("players/bans");
		
		foreach($this->data->getAll() as $name => $value){
			$this->bans[strtolower($name)] = $value;
		}
	}
	
	public function getBans() : array {
		return $this->bans;
	}
	
	public function getDataByPlayer(string $name) : array {
		return $this->bans[strtolower($name)] ?? [];
	}
	
	/**
	 * @param string $name
	 * @param string $bannedBy
	 * @param string $reason
	 * @param int $time
	 * @param string $date
	 */
	public function addBan(string $name, string $bannedBy, string $reason, int $time, string $date){
		if($time > 0){
			$permanent = false;
		} else {
			$permanent = true;
		}
		
		$data = [
		    "user" => strtolower($name),
		    "bannedBy" => strtolower($bannedBy),
		    "reason" => $reason,
		    "permanent" => $permanent,
		    "time" => $time,
		    "date" => $date
		];
		
		$this->bans[strtolower($name)] = $data;
         $this->save(); 
	}
	
	/**
	 * @param string
	 */
	public function removeBan(string $name){
		if(isset($this->bans[strtolower($name)])){
			unset($this->bans[strtolower($name)]);
             $this->save(); 
		}
	}
	
	public function isBanned(string $name) : bool {
		return isset($this->bans[strtolower($name)]);
	}
    
    /**
     * Save the last sanctions when shutting down the server
     */
    public function save(){
		$this->data->setAll($this->bans);
		$this->data->save();
	}
	
}

?>