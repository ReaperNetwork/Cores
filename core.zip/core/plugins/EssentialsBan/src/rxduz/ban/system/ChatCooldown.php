<?php

namespace rxduz\ban\system;

use rxduz\ban\utils\InstancePluginReference;

class ChatCooldown {
	
    use InstancePluginReference;
	
	private array $cooldowns = [];
    
    public function addCooldow(string $name, int $time){
        $this->cooldowns[$name] = time() + $time;
    }
    
    public function hasCooldow(string $name) : bool {   	
        if(isset($this->cooldowns[$name])){     	
            if(time() < $this->cooldowns[$name]){
                     	
                return true;
            }        	
        }
        
        return false;
    }
    
    public function getCooldow(string $name) : int { 	
        if(!$this->hasCooldow($name)) return 0;
        
        return $this->cooldowns[$name] - time();
    }
}

?>