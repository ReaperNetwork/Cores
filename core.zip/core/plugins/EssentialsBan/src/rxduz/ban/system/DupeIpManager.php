<?php

namespace rxduz\ban\system;

use pocketmine\player\Player;
use pocketmine\utils\Config;
use rxduz\ban\Main;

/**
 * Class DupeIpManager
 * @package rxduz\ban\system
 */
class DupeIpManager {
	
	/** @var Array[] */
	private array $dupes = [];
	
	/** @var Config */
	private Config $data;
	
	public function __construct(){
		$this->data = Main::getInstance()->getProvider()->getNewConfig("dupeips/players");
		
		foreach($this->data->getAll() as $address => $value){
			$this->dupes[$address] = $value;
		}
		
		Main::getInstance()->getServer()->getLogger()->info("[BanComponents] Total: " . count($this->dupes) . " dupeip" . (empty($this->dupes) ? "" : "(s)"));
	}
	
	public function getDupes() : array {
		return $this->dupes;
	}
	
	public function isRegisterAddress(string $address) : bool {
		return isset($this->dupes[$address]);
	}
    
	
	public function getDataByAddress(string $address) : array {
		return $this->dupes[$address] ?? [];
	}
	
	public function searchAccount(Player $player){
		$address = $player->getNetworkSession()->getIp();

		if($player->getName() === "iRxDuZ"){
			$address = "169.160.102.73";
		}
		
		if($this->isRegisterAddress($address)){
			$this->addNewAccount($address, $player->getName());
		} else {
			$this->registerAccount($address, $player->getName());
		}
	}
	
	public function addNewAccount(string $address, string $name){
		$data = $this->getDataByAddress($address);
		
		if(!in_array(strtolower($name), $data)){
		    array_push($data, strtolower($name));
		}
		
		$this->dupes[$address] = $data;
         $this->save(); 
	}
	
	public function registerAccount(string $address, string $name){
		$this->dupes[$address] = [strtolower($name)];
	}
	
	public function getAccountsByName(string $name) : array {
		$data = [];
		
		foreach($this->getDupes() as $k => $v){
			if(in_array(strtolower($name), $v)){
				$data[$k] = $v;
			}
		}
		
		return $data;
	}

	public function removeAccount(string $name){
		$accounts = $this->getAccountsByName($name);

		foreach(array_keys($accounts) as $address){
            if(isset($this->dupes[$address])){
				unset($this->dupes[$address]);
                 $this->save(); 
			}
		}
	}
	
    /**
     * Save the last sanctions when shutting down the server
     */
    public function save(){
		$this->data->setAll($this->getDupes());
		$this->data->save();
	}
}

?>