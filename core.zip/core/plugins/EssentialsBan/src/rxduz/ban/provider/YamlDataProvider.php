<?php

namespace rxduz\ban\provider;

use pocketmine\utils\Config;
use rxduz\ban\Main;

/**
 * Class YamlDataProvider
 * @package ban\provider
 */
class YamlDataProvider {
	
	/** @var Main $plugin */
	private Main $plugin;
	
	private array $pluginConfig = [];
	
	/**
	 * YamlDataProvider constructor
     * @param Main $plugin
	 */
	public function __construct(Main $plugin){
		$this->plugin = $plugin;
		
		$this->pluginConfig = $this->plugin->getConfig()->getAll();
		
		$this->init();
	}
	
	public function getPluginConfig() : array {
		return $this->pluginConfig;
	}
	
	/**
	 * @param string $location
	 * @return Config
	 */
	public function getNewConfig(string $location) : Config {
		return new Config($this->plugin->getDataFolder() . $location . ".yml", Config::YAML);
	}
	
	/**
	 * Create folders
	 */
	public function init(){
		if(!is_dir($this->plugin->getDataFolder() . "players/")){
		    @mkdir($this->plugin->getDataFolder() . "players/");
		}
		if(!is_dir($this->plugin->getDataFolder() . "depeips/")){
		    @mkdir($this->plugin->getDataFolder() . "dupeips/");
		}
	}
	
}

?>