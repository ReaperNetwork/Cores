<?php

namespace rxduz\ban\task;

use pocketmine\Server;
use pocketmine\scheduler\Task;
use rxduz\ban\utils\Utils;
use rxduz\ban\Main;

/**
 * Class BanAddressTask
 * @package rxduz\ban\task
 */
class BanAddressTask extends Task {
	
	/**
	 * BanAddressTask constructor
	 */
	public function __construct(){
		$this->setHandler(Main::getInstance()->getScheduler()->scheduleRepeatingTask($this, 20));
	}
	
	/**
	 * Actions to execute when run
	 *
	 * @throws CancelTaskException
	 */
	public function onRun() : void {
		foreach(Main::getInstance()->getBanAddressManager()->getBans() as $address => $value){
			if(!$value["permanent"]){
					
				$time = $value["time"];
					
				$now = time();
					
				if($time < $now){
					Main::getInstance()->getBanAddressManager()->removeBan($address);
					
					Utils::notifyConsole("Ban address of " . $value["user"] . " (" . $address . ") " . "has expired!");
				}
			}
		}
	}
	
}

?>