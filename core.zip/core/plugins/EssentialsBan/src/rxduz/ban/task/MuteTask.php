<?php

namespace rxduz\ban\task;

use pocketmine\Server;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as Color;
use rxduz\ban\utils\Utils;
use rxduz\ban\Main;

/**
 * Class MuteTask
 * @package rxduz\ban\task
 */
class MuteTask extends Task {
	
	/**
	 * MuteTask constructor
	 */
	public function __construct(){
        $this->setHandler(Main::getInstance()->getScheduler()->scheduleRepeatingTask($this, 20));
	}
	
	/**
	 * Actions to execute when run
	 *
	 * @throws CancelTaskException
	 */
	public function onRun() : void {
		foreach(Main::getInstance()->getMuteManager()->getMutes() as $name => $value){
			if(!$value["permanent"]){
				$time = $value["time"];
					
				$now = time();
					
				if($time < $now){
					Main::getInstance()->getMuteManager()->removeMute($name);
					
					Utils::notifyConsole("Mute of " . $name . " (" . $value["reason"] . ") has expired!");
				}
			}
		}
	}
	
}

?>