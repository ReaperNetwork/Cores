<?php

/**
 * Plugin: BanComponents
 * Software: PocketMine-MP - 4.0.0
 * Version: 1.2.2
 * Author: iRxDuZ | Discord: iRxDuZ#0001 | Twitter: @zRxDuZ
 */

namespace rxduz\ban;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as Color;
use rxduz\ban\provider\YamlDataProvider;
use rxduz\ban\translator\TranslatorManager;
use rxduz\ban\system\BanManager;
use rxduz\ban\system\BanAddressManager;
use rxduz\ban\system\MuteManager;
use rxduz\ban\system\WarnManager;
use rxduz\ban\system\DupeIpManager;
use rxduz\ban\commands\BanCommand;
use rxduz\ban\commands\TBanCommand;
use rxduz\ban\commands\UnBanCommand;
use rxduz\ban\commands\BanIPCommand;
use rxduz\ban\commands\TBanIPCommand;
use rxduz\ban\commands\UnBanIPCommand;
use rxduz\ban\commands\MuteCommand;
use rxduz\ban\commands\TMuteCommand;
use rxduz\ban\commands\UnMuteCommand;
use rxduz\ban\commands\KickCommand;
use rxduz\ban\commands\HistoryCommand;
use rxduz\ban\commands\StaffChatCommand;
use rxduz\ban\commands\StaffListCommand;
use rxduz\ban\commands\ReportCommand;
use rxduz\ban\commands\WarnCommand;
use rxduz\ban\commands\ClearWarnCommand;
use rxduz\ban\commands\DupeIpCommand;
use rxduz\ban\commands\ClearIpCommand;
use rxduz\ban\commands\ReportAdminCommand;
use rxduz\ban\commands\ReportListCommand;
use rxduz\ban\listeners\BanListener;
use rxduz\ban\listeners\BanAddressListener;
use rxduz\ban\listeners\MuteListener;
use rxduz\ban\listeners\StaffChatListener;
use rxduz\ban\listeners\DupeIpListener;
use rxduz\ban\listeners\ChatCooldownListener;
use rxduz\ban\listeners\PlayerJoinListener;
use rxduz\ban\task\BanTask;
use rxduz\ban\task\BanAddressTask;
use rxduz\ban\task\MuteTask;

/**
 * Class Main - PluginBase
 * @package ban
 */
class Main extends PluginBase {
	
	/**
	 * ¿What things were implemented v1.2.0?
	 * Best optimization
     * Best time format
     * Hystory of player
     * Report system added
     * StaffChat added
     * Warn system added
     * AntiFlood added
     * Show expiration time
     * Notifications to the console and staff
	 */
	
	/** @var Main $instance */
	private static Main $instance;
	
	/** @var YamlDataProvider $dataProvider */
	private YamlDataProvider $dataProvider;
	
	/** @var TranslatorManager $translatorManager */
	private TranslatorManager $translatorManager;
	
	/** @var BanManager $banManager */
	private BanManager $banManager;
	
	/** @var BanAddressManager $banAddressManager */
	private BanAddressManager $banAddressManager;
	
	/** @var MuteManager $muteManager */
	private MuteManager $muteManager;
	
	/** @var WarnManager $warnManager */
	private WarnManager $warnManager;
	
	/** @var DupeIpManager $dupeIpManager */
	private DupeIpManager $dupeIpManager;
	
	/**
	 * @throws \Exeption
	 */
	public function onEnable() : void {
		self::$instance = $this;
		
		// set location for time
		date_default_timezone_set("America/Los_Angeles");
		
		$this->saveDefaultConfig();
		
		$this->saveResource("/messages.yml");
		
		$this->loadManagers();
		
		$this->loadCommands();
		
		$this->loadEvents();
		
		$this->loadTask();
		
		$this->getServer()->getLogger()->info(Color::GREEN . "[BanComponents] enabled successfully, running version: " . $this->getDescription()->getVersion() . " for PMM4!");
	}
	
	public function onDisable() : void {
		$this->getBanManager()->save();
		
		$this->getBanAddressManager()->save();
		
		$this->getMuteManager()->save();
		
		$this->getWarnManager()->save();
		
		$this->getDupeIpManager()->save();
		
		$this->getServer()->getLogger()->info(Color::GREEN . "[BanComponents] disabled and saved all data successfully!");
	}
	
	/**
	 * @return Main
	 */
	public static function getInstance() : Main {
		return self::$instance;
	}
	
	/**
	 * @return YamlDataProvider
	 */
	public function getProvider() : YamlDataProvider {
		return $this->dataProvider;
	}
	
	/**
	 * @return TranslatorManager
	 */
	public function getTranslatorManager() : TranslatorManager {
		return $this->translatorManager;
	}
	
	/**
	 * @return BanManager
	 */
	public function getBanManager() : BanManager {
		return $this->banManager;
	}
	
	/**
	 * @return BanAddressManager
	 */
	public function getBanAddressManager() : BanAddressManager {
		return $this->banAddressManager;
	}
	
	/**
	 * @return MuteManager
	 */
	public function getMuteManager() : MuteManager {
		return $this->muteManager;
	}
	
	/**
	 * @return WarnManager
	 */
	public function getWarnManager() : WarnManager {
		return $this->warnManager;
	}
	
	/**
	 * @return DupeIpManager
	 */
	public function getDupeIpManager() : DupeIpManager {
		return $this->dupeIpManager;
	}
	
	/**
	 * Register all Managers
	 */
	public function loadManagers(){
		$this->dataProvider = new YamlDataProvider($this);
		
		$this->banManager = new BanManager();
		
		$this->banAddressManager = new BanAddressManager();
		
		$this->muteManager = new MuteManager();
		
		$this->warnManager = new WarnManager();
		
		$this->dupeIpManager = new DupeIpManager();
		
		$this->translatorManager = new TranslatorManager();
	}
	
	/**
	 * Register all commands
	 */
	public function loadCommands(){
		$map = $this->getServer()->getCommandMap();
		
		$oldCommands = ["ban", "ban-ip", "pardon", "pardon-ip", "kick", "banlist"];
		
		foreach($oldCommands as $cmd){
			$map->unregister($map->getCommand($cmd));
		}

        $map->registerAll("BanComponents", [
		    new BanCommand(),
		    new TBanCommand(),
		    new UnBanCommand(),
		    new BanIPCommand(),
		    new TBanIPCommand(),
		    new UnBanIPCommand(),
		    new MuteCommand(),
		    new TMuteCommand(),
		    new UnMuteCommand(),
		    new KickCommand(),
		    new HistoryCommand(),
		    //new StaffChatCommand(),
			//new StaffListCommand(),
		    new ReportCommand(),
		    new WarnCommand(),
		    new ClearWarnCommand(),
		    new DupeIpCommand(),
			new ClearIpCommand()
        ]);
	}
	
	/**
	 * Register all events
	 */
	public function loadEvents(){
		new BanListener();
		
		new BanAddressListener();
		
		new MuteListener();
		
		new StaffChatListener();
		
		new DupeIpListener();
		
		new ChatCooldownListener();

		new PlayerJoinListener();
	}
	
	/**
	 * Register all tasks
	 */
	public function loadTask(){
		new BanTask();
		
		new BanAddressTask();
		
		new MuteTask();
	}
	
}

?>