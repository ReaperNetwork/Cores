<?php

namespace rxduz\ban\translator;

use rxduz\ban\Main;

class TranslatorManager {
	
	private array $messages = [];
	
	public function __construct(){
		$this->messages = Main::getInstance()->getProvider()->getNewConfig("/messages")->getAll();
	}
	
	public function getMessages() : array {
		return $this->messages;
	}
	
}

?>