<?php

namespace rxduz\ban\utils;

use pocketmine\Server;
use pocketmine\utils\TextFormat as Color;
use rxduz\ban\libs\CortexPE\DiscordWebhookAPI\Embed;
use rxduz\ban\libs\CortexPE\DiscordWebhookAPI\Message;
use rxduz\ban\libs\CortexPE\DiscordWebhookAPI\Webhook;
use rxduz\ban\Main;

class Utils {
	
	/**
	 * @param string $time
	 * @return int|null
	 */
	public static function intCharacters(string $time): ? int {
		$chars = str_split($time);
		
		$currentCharacters = null;
		
		for($i = 0; $i < count($chars); $i++){
			if(is_numeric($chars[$i])) $currentCharacters .= $chars[$i];
		}
		
		return ($currentCharacters == null ? null : intval($currentCharacters));
	}
	
	/**
	 * @param string $time
	 * @return string|null
	 */
	public static function stringCharacters(string $time): ? string {
		$chars = str_split($time);

		for($i = 0; $i < count($chars); $i++){
			if(is_string($chars[$i])){
				$key = strtolower($chars[$i]);
				
				if($key == "s") return "seconds";
				
				if($key == "m"){
					if(isset($chars[$i + 1])) if(strtolower($chars[$i + 1]) == "o") return "months";
					
					return "minutes";
				}
				
				if($key == "h") return "hours";
				
				if($key == "d") return "days";
				
				if($key == "w") return "weeks";
				
				if($key == "y") return "years";
			}
		}
		
		return null;
	}
	
	/**
	 * @param string $format
	 * @return int|null
	 */
	public static function replaceTimer(string $format): ? int {
		$time = self::intCharacters($format);
		
		$date = self::stringCharacters($format);
		
		if($time != null || $date != null){
			if($time <= 0) return null;
			
			if($date == "years") return time() + ($time * 31536000);
			
		    if($date == "months") return time() + ($time * 2592000);
		
		    if($date == "weeks") return time() + ($time * 604800);
		
		    if($date == "days") return time() + ($time * 86400);
		
		    if($date == "hours") return time() + ($time * 3600);
		
		    if($date == "minutes") return time() + ($time * 60);
		
		    if($date == "seconds") return (time() + $time);
		}
		
		return null;
	}
	
	/**
	 * @param string $message
	 */
	public static function notifyConsole(string $message){
		$data = Main::getInstance()->getProvider()->getPluginConfig();
		
		if($data["notify-console"]){
			Server::getInstance()->getLogger()->info(Color::colorize(Main::getInstance()->getTranslatorManager()->getMessages()["CONSOLE_PREFIX"]) . Color::RESET . $message);
		}
	}
	
	/**
	 * @param string $name
	 * @param string $reason
	 */
	public static function banNotify(string $name, string $reason){
		$data = Main::getInstance()->getProvider()->getPluginConfig();
		
		$message = Color::colorize(str_replace(["{user}", "{reason}"], [$name, $reason], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_TRIED_JOIN_BANNED"]));
		
		if($data["notify-tried-join"]){
			self::notifyConsole($message);
			
			foreach(Server::getInstance()->getOnlinePlayers() as $players){
				if($players->hasPermission(Permissions::NOTIFY_MESSAGES)){
					$players->sendMessage($message);
				}
			}
		}
	}
	
	/**
	 * @param string $name
	 * @param string $reason
	 */
	public static function muteNotify(string $name, string $reason){
		$data = Main::getInstance()->getProvider()->getPluginConfig();
		
		$message = Color::colorize(str_replace(["{user}", "{reason}"], [$name, $reason], Main::getInstance()->getTranslatorManager()->getMessages()["PLAYER_TRIED_SPEAK_MUTED"]));
		
		if($data["notify-tried-speak"]){
			self::notifyConsole($message);
			
			foreach(Server::getInstance()->getOnlinePlayers() as $players){
				if($players->hasPermission(Permissions::NOTIFY_MESSAGES)){
					$players->sendMessage($message);
			    }
			}
		}
	}
	
	/**
	 * @param int $banTime
	 * @return string
	 */
	public static function expiredToString(int $banTime): string {
		$now = time();
		
		$remainingTime = $banTime - $now;
		
		$day = floor($remainingTime / 86400);
		
		$hourSeconds = $remainingTime % 86400;
		
		$hour = floor($hourSeconds / 3600);
		
		$minuteSec = $hourSeconds % 3600;
		
		$minute = floor($minuteSec / 60);
		
		$remainingSec = $minuteSec % 60;
		
		$second = ceil($remainingSec);

        return $day . " Days " . $hour . " Hours " . $minute . " Minutes " . $second . " Seconds";
    }

	/**
     * @param string $player
     * @param string $reason
     * @param array $extradata
     */
    public static function createWebHook(string $player, string $reason, string $reportBy): void {
		$pluginConfig = Main::getInstance()->getProvider()->getPluginConfig();

		if(!$pluginConfig["discord-webhook"]){
			return;
		}

        //Webhook url
        $webHook = new Webhook($pluginConfig["webhook-url"]);

        $msg = new Message();
        $msg->setUsername("BanComponents");
        $msg->setAvatarURL($pluginConfig["discord-avatar"]);
        $msg->setContent(Main::getInstance()->getTranslatorManager()->getMessages()["DISCORD_REPORT_CONTENT"]);

        $embed = new Embed();
        $embed->setTitle(Main::getInstance()->getTranslatorManager()->getMessages()["DISCORD_REPORT_TITLE"]);
        $embed->setColor(10181046); // Purple
		$embed->addField("Reported player:", $player);
		$embed->addField("Reported by:", $reportBy);
        $embed->addField("Reason:", $reason);
        $embed->setTimestamp( new \DateTime("NOW"));

        $msg->addEmbed($embed);

        $webHook->send($msg);
    }
	
}

?>