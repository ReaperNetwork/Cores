<?php

namespace rxduz\ban\utils;

/**
 * Class Permissions
 * @package rxduz\ban\utils
 */
class Permissions {
	
	/**
	 * List of all permissions and bypass
	 */
	const BAN_COMMAND_USE = "bancomponents.command.ban";
	
	const TBAN_COMMAND_USE = "bancomponents.command.tban";
	
	const BANIP_COMMAND_USE = "bancomponents.command.banip";
	
	const TBANIP_COMMAND_USE = "bancomponents.command.tbanip";
	
	const MUTE_COMMAND_USE = "bancomponents.command.mute";
	
	const TMUTE_COMMAND_USE = "bancomponents.command.tmute";
	
	const KICK_COMMAND_USE = "bancomponents.command.kick";

    const PARDON_COMMAND_USE = "bancomponents.command.pardon";
    
    const PARDONIP_COMMAND_USE = "bancomponents.command.pardonip";
    
    const UNMUTE_COMMAND_USE = "bancomponents.command.unmute";
    
    const CLEARWARN_COMMAND_USE = "bancomponents.command.clearwarn";
    
    const WARN_COMMAND_USE = "bancomponents.command.warn";
    
    const STAFFCHAT_COMMAND_USE = "bancomponents.command.staffchat";
    
    const HISTORY_COMMAND_USE = "bancomponents.command.history";
    
    const DUPEIP_COMMAND_USE = "bancomponents.command.dupeip";

	const CLEARIP_COMMAND_USE = "bancomponents.command.clearip";
	
	const NOTIFY_MESSAGES = "bancomponents.notify";
	
	const CHAT_BYPASS = "bancomponents.chat.bypass";
	
}

?>