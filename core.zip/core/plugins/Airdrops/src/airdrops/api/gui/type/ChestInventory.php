<?php

namespace airdrops\api\gui\type;

use airdrops\utils\Utils;

use airdrops\api\gui\Inventory;
use airdrops\api\gui\utils\WhateverInventory;

use pocketmine\player\Player;
use pocketmine\world\Position;

use pocketmine\block\VanillaBlocks;
use pocketmine\block\utils\DyeColor;

use pocketmine\block\inventory\BlockInventory;

use pocketmine\network\mcpe\protocol\BlockEventPacket;
use pocketmine\network\mcpe\protocol\types\BlockPosition;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;

class ChestInventory extends Inventory implements BlockInventory, WhateverInventory {

    /** @var bool */
    protected bool $interactable = false;

    /**
     * ChestInventory Constructor.
     * @param Player $player
     * @param Position $holder
     */
    public function __construct(Player $player, Position $holder){
        $this->player = $player;
        $this->holder = $holder;
        parent::__construct(27);
    }

    /**
     * @return bool
     */
    public function isInteractable() : bool {
        return $this->interactable;
    }

    /**
     * @param bool $v
     * @return void
     */
    public function interactable(bool $v) : void {
        $this->interactable = $v;
    }

    /**
     * @param Player $who
     * @return void
     */
    public function onOpen(Player $who) : void {
        parent::onOpen($who);
        if($this->getHolder()->isValid() && count($this->getViewers()) === 1){
            $this->animateBlock(true);

            $who->getNetworkSession()->sendDataPacket(Utils::addSound($this->getHolder(), LevelSoundEvent::CHEST_OPEN));
        }
    }

    /**
     * @param Player $who
     * @return void
     */
    public function onClose(Player $who) : void {
        if($this->getHolder()->isValid() && count($this->getViewers()) === 1){
            $this->animateBlock(false);

            $who->getNetworkSession()->sendDataPacket(Utils::addSound($this->getHolder(), LevelSoundEvent::CHEST_CLOSED));
        }
        parent::onClose($who);
    }

    /**
     * @param bool $isOpen
     * @return void
     */
    protected function animateBlock(bool $isOpen) : void {
        $holder = $this->getHolder();
        if(!$this->player->isOnline() || !$this->player->isAlive()){
            return;
        }
        $this->player->getNetworkSession()->sendDataPacket(BlockEventPacket::create(BlockPosition::fromVector3($holder), 1, $isOpen ? 1 : 0));
    }

    /**
     * @param Player $player
     * @param array $contents
     * @param bool $interactable
     * @param Position|null $position
     * @param bool $fillEmpty
     * @return static
     */
    public static function create(Player $player, array $contents, bool $interactable, ?Position $position, bool $fillEmpty) : self {
        if($position === null){
            $position = Position::fromObject($player->getPosition()->subtract(0, 4, 0)->floor(), $player->getWorld());
        }
        $inventory = new self($player, $position);

        $inventory->interactable($interactable);
        $inventory->setContents($contents);

        $glass = VanillaBlocks::STAINED_GLASS_PANE();

        $fillItems = [$glass->setColor(DyeColor::GREEN())->asItem(), $glass->setColor(DyeColor::YELLOW())->asItem(), $glass->setColor(DyeColor::BLACK())->asItem(), $glass->setColor(DyeColor::BLUE())->asItem(), $glass->setColor(DyeColor::BROWN())->asItem(), $glass->setColor(DyeColor::CYAN())->asItem(), $glass->setColor(DyeColor::MAGENTA())->asItem(), $glass->setColor(DyeColor::RED())->asItem(), $glass->setColor(DyeColor::WHITE())->asItem(), $glass->setColor(DyeColor::LIGHT_BLUE())->asItem(), $glass->setColor(DyeColor::PINK())->asItem()];
        foreach($inventory->getContents($fillEmpty) as $slot => $item){
            if($item->isNull()){
                $inventory->setItem($slot, $fillItems[array_rand($fillItems)]);
            }
        }
        return $inventory;
    }
}

?>