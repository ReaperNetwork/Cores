<?php

namespace airdrops\api\gui\utils;

use pocketmine\player\Player;

trait CallbackInventory {

    /** @var Player */
    protected Player $player;

    /** @var callable|null */
    protected $onOpenCallable = null;

    /** @var callable|null */
    protected $onCloseCallable = null;

    /**
     * @return callable|null
     */
    public function getOpenCallable() : ?callable {
        return $this->onOpenCallable;
    }

    /**
     * @param callable|null $callable
     * @return void
     */
    public function onOpenCallable(callable $callable = null) : void {
        $this->onOpenCallable = $callable;
    }

    /**
     * @return callable|null
     */
    public function getCloseCallable() : ?callable {
        return $this->onCloseCallable;
    }

    /**
     * @param callable|null $callable
     * @return void
     */
    public function onCloseCallable(callable $callable = null) : void {
        $this->onCloseCallable = $callable;
    }

    /**
     * @return Player
     */
    public function getPlayer() : Player {
        return $this->player;
    }
}

?>