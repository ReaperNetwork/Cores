<?php

namespace airdrops\api\gui\utils;

interface WhateverInventory {

    /**
     * @return bool
     */
    public function isInteractable() : bool;

    /**
     * @param bool $v
     * @return void
     */
    public function interactable(bool $v) : void;
}

?>