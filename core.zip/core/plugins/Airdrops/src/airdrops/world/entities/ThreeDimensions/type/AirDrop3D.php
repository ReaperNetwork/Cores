<?php

namespace airdrops\world\entities\ThreeDimensions\type;

use airdrops\HCFLoaderAirDrop;
use airdrops\utils\Utils;
use airdrops\utils\Builder;
use airdrops\utils\TextHelper;
use airdrops\utils\TaskHelper;

use airdrops\utils\skin\Skin3D;

use airdrops\other\airdrop\AirDrop;
use airdrops\other\airdrop\AirDropFactory;

use airdrops\api\gui\type\HopperInventory;

use airdrops\world\entities\ThreeDimensions\ThreeDimensions;

use pocketmine\entity\Skin;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\entity\EntitySizeInfo;

use pocketmine\scheduler\Task;

use pocketmine\math\Vector3;
use pocketmine\player\Player;

use pocketmine\world\World;
use pocketmine\world\Position;
use pocketmine\world\sound\ClickSound;

use pocketmine\block\Block;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\utils\DyeColor;

use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;

class AirDrop3D extends ThreeDimensions {

    /** @var int */
    const DEFAULT_TIME = 180;

    /** @var float */
    protected float $gravity = 0.003;
    /** @var float */
    protected float $drag = 0.001;

    /** @var int */
    protected int $time = self::DEFAULT_TIME;

    /** @var Block|null */
    protected ?Block $restoreBlock = null;

    /** @var bool */
    public bool $isOpened = false;

    /** @var bool */
    public bool $isOnGround = false;

    /** @var HopperInventory|null */
    protected ?HopperInventory $hopperInventory = null;

    /**
     * AirDrop3D Constructor.
     * @param Location $location
     * @param Skin $skin
     * @param CompoundTag|null $nbt
     */
    public function __construct(Location $location, Skin $skin, ?CompoundTag $nbt = null){
        parent::__construct($location, $skin, $nbt);

        $this->setNameTag(TextHelper::replace("&l&6(&dAirdrop&6)"));
        $this->setNameTagVisible();
        $this->setNameTagAlwaysVisible();
        $this->setHasGravity();
        $this->setGravity($this->gravity);
        $this->setCanSaveWithChunk(true);
    }

    /**
     * @return EntitySizeInfo
     */
    protected function getInitialSizeInfo() : EntitySizeInfo {
        return new EntitySizeInfo(1.0, 1.0);
    }

    /**
     * @param CompoundTag $nbt
     * @return void
     */
    protected function initEntity(CompoundTag $nbt): void {

        $this->isOpened = $nbt->getByte("isOpened", 0) !== 0;
        $this->isOnGround = $nbt->getByte("isOnGround", 0) !== 0;

        parent::initEntity($nbt);
    }

    /**
     * @return CompoundTag
     */
    public function saveNBT() : CompoundTag {
        $nbt = parent::saveNBT();

        $nbt->setByte("isOpened", $this->isOpened ? 1 : 0);
        $nbt->setByte("isOnGround", $this->isOnGround ? 1 : 0);

        return $nbt;
    }

    /**
     * @param EntityDamageEvent $source
     * @return void
     */
    public function attack(EntityDamageEvent $source) : void {
        $source->cancel();
    }

    /**
     * @return float|null
     */
    protected function onHitGround() : ?float{
        foreach($this->getViewers() as $player){
            $player->getNetworkSession()->sendDataPacket(Utils::addSound($this->getPosition(), LevelSoundEvent::EXPLODE));
            $player->getNetworkSession()->sendDataPacket(Utils::addParticle($this->getPosition(), "minecraft:huge_explosion_emitter"));
        }
        // RESTORE OLD BLOCK REPLACING BY RED WOOL
        if($this->restoreBlock !== null){
            $this->getPosition()->getWorld()->setBlock($this->restoreBlock->getPosition(), $this->restoreBlock);
        }
        $this->isOnGround = true;

        $skin = Skin3D::process(HCFLoaderAirDrop::getInstance()->getDataFolder()."model".DIRECTORY_SEPARATOR."airdrop".DIRECTORY_SEPARATOR."airdrop.text.png", HCFLoaderAirDrop::getInstance()->getDataFolder()."model".DIRECTORY_SEPARATOR."airdrop".DIRECTORY_SEPARATOR."airdrop.geo.json", "geometry.vital.airdrop");
        if($skin === null){
            return null;
        }

        $this->setSkin($skin);
        $this->sendSkin();

        return null;
    }

    /**
     * @param Player $player
     * @param Vector3 $clickPos
     * @return bool
     */
    public function onInteract(Player $player, Vector3 $clickPos) : bool {
        if(!($airDrop = AirDropFactory::getInstance()->get()) instanceof AirDrop){
            return false;
        }
        if(!$this->isOnGround){
            return false;
        }
        if($this->isOpened){
            $this->reopen($player);
            return false;
        }
        $this->open($player, $airDrop);
        return true;
    }

    /**
     * @param Player $player
     * @return void
     */
    protected function reopen(Player $player) : void {
        if(($oldInventoryHopper = $this->hopperInventory) === null){
            $this->flagForDespawn();
            return;
        }
        $player->getNetworkSession()->sendDataPacket(Builder::buildBlock(($position = Position::fromObject($player->getPosition()->subtract(0, 4, 0)->floor(), $player->getWorld())), VanillaBlocks::HOPPER()));

        $this->hopperInventory = new HopperInventory($player, $position);
        $this->hopperInventory->interactable(true);
        $this->hopperInventory->setContents($oldInventoryHopper->getContents());

        $player->setCurrentWindow($this->hopperInventory);
    }

    /**
     * @param Player $player
     * @param AirDrop $airDrop
     * @return void
     */
    protected function open(Player $player, AirDrop $airDrop) : void {
        $player->getNetworkSession()->sendDataPacket(Builder::buildBlock(($position = Position::fromObject($player->getPosition()->subtract(0, 4, 0)->floor(), $player->getWorld())), VanillaBlocks::HOPPER()));

        $this->hopperInventory = new HopperInventory($player, $position);
        $this->hopperInventory->interactable(false);

        $this->isOpened = true;

        $this->hopperInventory->onOpenCallable(function(Player $player, HopperInventory $inventory) use ($airDrop) : void {
            TaskHelper::runAnyTask(new class($this, $player, $inventory, $airDrop) extends Task {

                /** @var int */
                protected int $time = 8;

                /**
                 * doTick Constructor.
                 * @param AirDrop3D $airDrop3D
                 * @param Player $player
                 * @param HopperInventory $inventory
                 * @param AirDrop $airDrop
                 */
                public function __construct(
                    protected AirDrop3D $airDrop3D,
                    protected Player $player,
                    protected HopperInventory $inventory,
                    protected AirDrop $airDrop,
                ){}

                /**
                 * @return void
                 */
                public function onRun() : void {
                    if(!$this->player->getCurrentWindow() instanceof HopperInventory){
                        $this->getHandler()->cancel();
                        return;
                    }
                    for($i = 0; $i <= 4; $i++){
                        $this->inventory->setItem($i, $this->airDrop->getInventoryReward());
                    }

                    $this->inventory->getHolder()->getWorld()->addSound($this->inventory->getHolder(), new ClickSound(), [$this->player]);

                    if(--$this->time <= 0){

                        $this->inventory->interactable(true);

                        $this->getHandler()->cancel();
                    }
                }
            }, TaskHelper::REPEATING, 20);
        });

        $player->setCurrentWindow($this->hopperInventory);
    }

    /**
     * @param int $tickDiff
     * @return bool
     */
    protected function entityBaseTick(int $tickDiff = 1) : bool {
        if($this->closed){
            return false;
        }
        if($this->isOpened){

            $this->setNameTag(TextHelper::replace("&r&l&bAirDrop&r &7(&aOpened&7)"));

            if(--$this->time <= 0){
                if(($inventory = $this->hopperInventory) !== null){
                    if(count($inventory->getContents()) > 0){
                        foreach($inventory->getContents() as $item){
                            $this->getPosition()->getWorld()->dropItem($this->getPosition(), $item);
                            foreach($this->getViewers() as $player){
                                $player->getNetworkSession()->sendDataPacket(Utils::addSound($this->getPosition(), LevelSoundEvent::EXPLODE));
                                $player->getNetworkSession()->sendDataPacket(Utils::addParticle($this->getPosition(), "minecraft:huge_explosion_emitter"));
                            }
                        }
                    }
                    if($inventory->getPlayer()->getCurrentWindow() !== null){
                        $inventory->getPlayer()->removeCurrentWindow();
                    }
                }
                $this->flagForDespawn();
            }
        }
        return parent::entityBaseTick($tickDiff);
    }

    /**
     * @param int $currentTick
     * @return bool
     */
    public function onUpdate(int $currentTick) : bool {
        if($this->closed){
            return false;
        }
        $this->timings->startTiming();

        for($y = $this->getPosition()->getFloorY(); $y >= World::Y_MIN; $y--){
            if(!($block = $this->getPosition()->getWorld()->getBlockAt($this->getPosition()->getFloorX(), $y, $this->getPosition()->getFloorZ()))->isSolid()){
                continue;
            }
            if($block->getIdInfo()->getBlockTypeId() === VanillaBlocks::BEDROCK()->getIdInfo()->getBlockTypeId()){
                continue;
            }
            if($this->isOnGround || $this->restoreBlock !== null){
                break;
            }
            $this->getPosition()->getWorld()->setBlock(($this->restoreBlock = $block)->getPosition(), VanillaBlocks::WOOL()->setColor(DyeColor::RED()));
            break;
        }
        $this->timings->stopTiming();

        return parent::onUpdate($currentTick);
    }
}

?>