<?php

namespace airdrops\world\entities\ThreeDimensions;

use pocketmine\entity\Human;

abstract class ThreeDimensions extends Human {

    /** @var callable|null */
    protected $callable = null;

    /**
     * @return callable|null
     */
    public function getCallable() : ?callable {
        return $this->callable;
    }

    /**
     * @param callable|null $callable
     * @return void
     */
    public function setCallable(?callable $callable) : void {
        $this->callable = $callable;
    }
}

?>