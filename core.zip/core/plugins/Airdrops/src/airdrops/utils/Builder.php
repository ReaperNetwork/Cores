<?php

namespace airdrops\utils;

use pocketmine\item\VanillaItems;
use pocketmine\network\mcpe\convert\BlockStateDictionary;
use pocketmine\network\mcpe\convert\BlockTranslator;
use pocketmine\network\mcpe\convert\TypeConverter;
use pocketmine\player\Player;
use pocketmine\world\Position;
use pocketmine\block\{Block, VanillaBlocks};

use pocketmine\network\mcpe\protocol\UpdateBlockPacket;
use pocketmine\network\mcpe\protocol\types\BlockPosition;

final class Builder {

    /**
     * @param Position $position
     * @param Block|null $block
     * @return UpdateBlockPacket
     */
    public static function buildBlock(Position $position, ?Block $block = null) : UpdateBlockPacket {
        return UpdateBlockPacket::create(new BlockPosition($position->getFloorX(), $position->getFloorY(), $position->getFloorZ()), TypeConverter::getInstance()->getBlockTranslator()->internalIdToNetworkId($block !== null ? $block->getStateId() : VanillaItems::AIR()->getStateId()), UpdateBlockPacket::FLAG_NETWORK, UpdateBlockPacket::DATA_LAYER_NORMAL);
    }

    /**
     * @param Position $position
     * @return void
     */
    public static function destroyBlock(Position $position) : void {
        self::buildBlock($position, VanillaBlocks::AIR());
    }

    /**
     * @param Player $player
     * @param Position $position
     * @param Block|null $block
     * @return void
     */
    public static function buildTower(Player $player, Position $position, ?Block $block = null) : void {
        for($y = $position->getFloorY(); $y <= $position->getFloorY() + 20; $y++){
            $player->getNetworkSession()->sendDataPacket(self::buildBlock(new Position($position->getFloorX(), $y, $position->getFloorZ(), $position->getWorld()), $block ?? self::getRandomBlocks($y)));
        }
    }

    /**
     * @param Player $player
     * @param Position $position
     * @param bool $truth
     * @param Block|null $block
     * @return void
     */
    public static function buildMappingTower(Player $player, Position $position, bool $truth = false, ?Block $block = null) : void {
        for($y = $position->getFloorY(); $y <= $position->getFloorY() + 40; $y++){
            $player->getNetworkSession()->sendDataPacket(self::buildBlock(new Position($position->getFloorX(), $y, $position->getFloorZ(), $position->getWorld()), $block ?? ($truth ? self::getRandomMappingBlocks($y) : self::getRandomTruthMappingBlocks($y))));
        }
    }

    /**
     * @param Player $player
     * @param Position $position
     * @return void
     */
    public static function destroyTower(Player $player, Position $position) : void {
        self::buildTower($player, $position, VanillaBlocks::AIR());
    }

    /**
     * @param int $y
     * @return Block
     */
    protected static function getRandomBlocks(int $y) : Block {
        return ($y % 3) === 0 ? VanillaBlocks::DIAMOND() : VanillaBlocks::GLASS();
    }

    /**
     * @param int $y
     * @return Block
     */
    protected static function getRandomMappingBlocks(int $y) : Block {
        return ($y % 3) === 0 ? VanillaBlocks::EMERALD() : VanillaBlocks::GLASS();
    }

    /**
     * @param int $y
     * @return Block
     */
    protected static function getRandomTruthMappingBlocks(int $y) : Block {
        return ($y % 3) === 0 ? VanillaBlocks::REDSTONE() : VanillaBlocks::GLASS();
    }
}

?>