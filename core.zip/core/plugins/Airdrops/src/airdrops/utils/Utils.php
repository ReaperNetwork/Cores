<?php

namespace airdrops\utils;

use pocketmine\math\Vector3;;
use pocketmine\world\Position;

use pocketmine\network\mcpe\protocol\types\DimensionIds;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;

final class Utils {

    /**
     * @param Position $position
     * @param string $particleName
     * @return SpawnParticleEffectPacket
     */
    public static function addParticle(Position $position, string $particleName) : SpawnParticleEffectPacket {
        return SpawnParticleEffectPacket::create(DimensionIds::OVERWORLD, -1, $position, $particleName, null);
    }

    /**
     * @param Vector3 $position
     * @param int $sound
     * @return LevelSoundEventPacket
     */
    public static function addSound(Vector3 $position, int $sound) : LevelSoundEventPacket {
        return LevelSoundEventPacket::nonActorSound($sound, $position, false, -1);
    }
}

?>