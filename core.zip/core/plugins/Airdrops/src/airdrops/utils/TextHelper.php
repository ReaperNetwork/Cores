<?php 

namespace airdrops\utils;

use airdrops\HCFLoaderAirDrop;

use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TE;

final class TextHelper {

    /**
     * @param string|array $message
     * @param array $findMessage
     * @param bool $isArray
     * @return string
     */
    public static function replace(string|array $message, array $findMessage = [], bool $isArray = true) : string {
        $replace = function(array $findMessage, string|array $message) use ($isArray) : string {
            if($isArray && is_array($message)){
                return self::replace(implode(TE::EOL, $message), $findMessage);
            }
            foreach($findMessage as $search => $replace){
                $message = str_replace("{".$search."}", $replace, $message);
            }
            return TE::colorize($message);
        };
        return $replace($findMessage, $message);
    }

    /**
     * @param string $message
     * @return string
     */
    public static function clean(string $message) : string {
        return str_replace("&", "", TE::clean($message));
    }

    /**
     * @return Config
     */
    public static function getMessageFile() : Config {
        return HCFLoaderAirDrop::$messages;
    }
}

?>
