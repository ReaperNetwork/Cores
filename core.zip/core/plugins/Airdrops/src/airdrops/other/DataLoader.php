<?php

namespace airdrops\other;

use airdrops\other\airdrop\AirDropFactory;
use pocketmine\utils\SingletonTrait;

class DataLoader {
    use SingletonTrait;

    /**
     * @return void
     */
    public function load() : void {
        AirDropFactory::getInstance()->load();
    }

    /**
     * @return void
     */
    public function save() : void {
        AirDropFactory::getInstance()->save();
    }
}

?>