<?php

namespace airdrops\other\airdrop\command\subcommands;

use airdrops\utils\TextHelper;
use airdrops\commands\utils\SubCommand;
use pocketmine\command\CommandSender;

class AirDropHelpSubCommand extends SubCommand {

    public function __construct(){
        parent::__construct("help", "", ["?"]);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return void
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
        $sender->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-help-information")));
    }
}

?>