<?php

namespace airdrops\other\airdrop\command;

use airdrops\utils\TextHelper;
use airdrops\commands\utils\Command;

use pocketmine\player\Player;
use pocketmine\command\CommandSender;

use airdrops\other\airdrop\command\subcommands\AirDropCreateSubCommand;
use airdrops\other\airdrop\command\subcommands\AirDropDeleteSubCommand;
use airdrops\other\airdrop\command\subcommands\AirDropGiveSubCommand;
use airdrops\other\airdrop\command\subcommands\AirDropEditSubCommand;
use airdrops\other\airdrop\command\subcommands\AirDropHelpSubCommand;

class AirDropCommand extends Command {

    /**
     * @param string $name
     * @param string $description
     * @param string|null $permission
     * @param array $alias
     */
    public function __construct(string $name, string $description, ?string $permission, array $alias = []){
        parent::__construct($name, $description, "", $alias);

        parent::setPermission($permission);

        $this->addSubCommand(new AirDropCreateSubCommand());
        $this->addSubCommand(new AirDropDeleteSubCommand());
        $this->addSubCommand(new AirDropGiveSubCommand());
        $this->addSubCommand(new AirDropEditSubCommand());
        $this->addSubCommand(new AirDropHelpSubCommand());
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return void
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
        if($sender instanceof Player && !$this->testPermission($sender)){
            $sender->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("no-permission")));
            return;
        }
        if(count($args) === 0){
            ($this->getSubCommand("help"))->execute($sender, $commandLabel, $args);
            return;
        }
        if(($subCommand = $this->getSubCommand($args[0])) === null){
            $sender->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("some-error-occurred")));
            return;
        }
        $subCommand->execute($sender, $commandLabel, $args);
    }
}

?>