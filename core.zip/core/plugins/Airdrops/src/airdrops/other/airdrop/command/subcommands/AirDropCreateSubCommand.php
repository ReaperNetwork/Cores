<?php

namespace airdrops\other\airdrop\command\subcommands;

use airdrops\utils\TextHelper;

use airdrops\other\airdrop\AirDrop;
use airdrops\other\airdrop\AirDropFactory;

use airdrops\commands\utils\SubCommand;

use pocketmine\player\Player;
use pocketmine\command\CommandSender;

class AirDropCreateSubCommand extends SubCommand {

    public function __construct(){
        parent::__construct("create", "", []);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return void
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
        /** @var Player $sender */
        if(AirDropFactory::getInstance()->get() instanceof AirDrop){
            $sender->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-already-exists")));
            return;
        }
        if(($item = $sender->getInventory()->getItemInHand())->isNull()){
            $sender->sendMessage(TextHelper::replace("&cItem can't be null"));
            return;
        }
        $airdrop = AirDropFactory::getInstance()->add($item, []);

        $sender->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-create")));

        $airdrop->save();
    }
}

?>