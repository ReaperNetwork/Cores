<?php

namespace airdrops\other\airdrop;

use airdrops\HCFLoaderAirDrop;

use airdrops\utils\skin\Skin3D;
use airdrops\utils\TextHelper;
use airdrops\utils\Translator;

use airdrops\other\Handler;

use airdrops\world\entities\ThreeDimensions\type\AirDrop3D;

use pocketmine\entity\Location;

use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\world\Position;

class AirDrop {

    protected array $showItem = [];

    /**
     * AirDrop Constructor.
     * @param Item|null $item
     * @param array<int, Item> $contents
     */
    public function __construct(
        protected ?Item $item,
        protected array $contents,
    ){}

    /**
     * @return Item|null
     */
     
     public function getContents() : array {
        return $this->contents;
    }
     
     public function getItem(int $count = 1): Item
    {
        $item = VanillaBlocks::CHEST()->asItem();
        $item->setCount($count);
        $item->setCustomName(TextFormat::colorize('AirDrop'));
        //$item->getNamedTag()->setInt('mystery_crate', 1);

        $lore = [
            '&bUnlock at IceMC',
            ' ',
            '&a&lCONTENT'
        ];

        $colors = [
            TextFormat::DARK_GREEN,
            TextFormat::GREEN,
            TextFormat::YELLOW,
            TextFormat::GOLD,
            TextFormat::RED,
            TextFormat::DARK_RED,
            TextFormat::AQUA,
            TextFormat::DARK_AQUA,
            TextFormat::BLUE,
            TextFormat::DARK_BLUE,
            TextFormat::LIGHT_PURPLE,
            TextFormat::DARK_PURPLE,
        ];

        $iColor = 0;
        $countItem = 0;

    if($this->getContents() !== null) {
        foreach ($this->getContents() as $itemCommon) {
            $countItem++;
            $count = $itemCommon->getCount() > 1 ? $itemCommon->getCount() . ' ' : '';
            $lore[] = TextFormat::GRAY . '* ' . $colors[$iColor] . $count . TextFormat::clean($itemCommon->getCustomName() !== '' ? $itemCommon->getCustomName() : $itemCommon->getName());

            if ($countItem % 3 == 0) {
                $iColor = ($iColor + 1) % count($colors);
            }
        }
     }

        $lore[] = ' ';

        $l = [];

        foreach ($lore as $line) {
            $l[] = TextFormat::RESET . TextFormat::colorize($line);
        }

        $item->setLore($l);

        return $item;
    }

    /**
     * @param Item|null $item
     * @return void
     */
    public function setItem(Item $item = null) : void {
        $this->item = $item;
    }

    /**
     * @return Item
     */
    public function getInventoryReward() : Item {
        $items = $this->getContents();

        rsort($items);

        return $items[array_rand($items)];
    }

    /**
     * @param array $contents
     * @return void
     */
    public function setContents(array $contents) : void {
        $this->contents = $contents;
    }

    /**
     * @param Player $player
     * @param int|null $count
     * @return void
     */
    public function give(Player $player, int $count = null) : void {
        if(!($item = $this->getItem()) instanceof Item){
            $player->sendMessage(TextHelper::replace("&cAirDrop item can't be null"));
            return;
        }
        if(HCFLoaderAirDrop::getInstance()->getConfig()->get('show-item')){
            if($this->getContents() !== null) {
                foreach ($this->getContents() as $item) {
                    $this->showItem[] = "&l&7* &r&f{$item->getName()}&r";
                }
            }
            $showNow = $this->showItem !== null ? implode("\n", $this->showItem) : "&a* &7None.";
            $item->setLore([TextFormat::colorize("&r".HCFLoaderAirDrop::getInstance()->getConfig()->get('lore-item')."\n\n&a&lCONTENT&r\n$showNow")]);
        } else {
            $item->setLore([TextFormat::colorize("&r".HCFLoaderAirDrop::getInstance()->getConfig()->get('lore-item'))]);
        }
        $item->setCustomName(TextFormat::colorize('&r&l&6AirDrop&r&a'));
        $item->getNamedTag()->setString(Handler::AIRDROP, $item->getName());


        $player->getInventory()->addItem($item->setCount($count ?? $item->getCount()));
        $player->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-give"), [
            "item_name" => $item->getName(),
        ]));
    }

    /**
     * @param Player $clicker
     * @param Position $position
     * @return void
     */
    public function open(Player $clicker, Position $position) : void {
        $hand = $clicker->getInventory()->getItemInHand();
        if(count($this->getContents()) === 0){
            $clicker->sendMessage(TextHelper::replace("&cEmpty ..."));
            return;
        }
        $skin = Skin3D::process(HCFLoaderAirDrop::getInstance()->getDataFolder()."model".DIRECTORY_SEPARATOR."airdrop".DIRECTORY_SEPARATOR."airdrop.parachute.text.png", HCFLoaderAirDrop::getInstance()->getDataFolder()."model".DIRECTORY_SEPARATOR."airdrop".DIRECTORY_SEPARATOR."airdrop.parachute.geo.json", "geometry.vital.airdrop.parachute");
        if($skin === null){
            $clicker->sendMessage(TextHelper::replace("&cSkin can't be null"));
            return;
        }
        $clicker->getInventory()->setItemInHand($hand->getCount() > 1 ? $hand->setCount($hand->getCount() - 1) : VanillaItems::AIR());

        $airdrop3D = new AirDrop3D(Location::fromObject(new Vector3($position->getFloorX() + 0.5, $position->getFloorY() + 10, $position->getFloorZ() + 0.5), $position->getWorld()), $skin);
        $airdrop3D->spawnToAll();

        $clicker->sendTitle(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-is-coming"), [
            "item_name" => $hand->getCustomName(),
        ]));
    }

    /**
     * @return void
     */
    public function save() : void {
        $rawData = [];

        $whereStored = AirDropFactory::getInstance()->getFileIterator();
        /*if(($item = $this->getItem()) instanceof Item){
            $rawData["item"] = Translator::itemToString($item);
        }*/
        foreach($this->getContents() as $slot => $item){
            $rawData["contents"][$slot] = Translator::encodeItem($item);
        }

        $whereStored->set(Handler::AIRDROP, $rawData);
        try {
            $whereStored->save();
        } catch(\JsonException $exception){
            HCFLoaderAirDrop::getInstance()->getLogger()->warning($exception->getMessage());
        }
    }
}

?>