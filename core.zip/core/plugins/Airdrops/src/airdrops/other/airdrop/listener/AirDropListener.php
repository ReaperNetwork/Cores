<?php

namespace airdrops\other\airdrop\listener;

use airdrops\api\gui\utils\WhateverInventory;
use airdrops\utils\TextHelper;

use airdrops\other\airdrop\AirDrop;
use airdrops\other\airdrop\AirDropFactory;

use airdrops\other\Handler;

use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\world\World;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockPlaceEvent;

class AirDropListener implements Listener {

    /**
     * @param BlockPlaceEvent $event
     * @return void
     */
    public function onBlockPlaceEvent(BlockPlaceEvent $event) : void {
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();
        $blocks = $event->getTransaction()->getBlocks();
        foreach ($blocks as [$x, $y, $z, $block]) {
            $position = $block->getPosition();
        }
        if($item->getNamedTag()->getTag(Handler::AIRDROP) !== null){

            $event->cancel();

            if(!($airdrop = AirDropFactory::getInstance()->get()) instanceof AirDrop){
                $player->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-not-exists")));
                return;
            }
            for($y = $position->getFloorY(); $y <= World::Y_MAX; $y++){
                if($player->getWorld()->getBlockAt($position->getFloorX(), $y, $position->getFloorZ())->isSolid()){
                    $player->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-has-obstruction")));
                    return;
                }
            }
            $airdrop->open($player, $position);
        }
    }

    /**
     * @param InventoryTransactionEvent $event
     * @return void
     */
    public function onInventoryTransactionEvent(InventoryTransactionEvent $event) : void {
        $transaction = $event->getTransaction();
        foreach($transaction->getActions() as $inventoryAction){
            if($inventoryAction instanceof SlotChangeAction){
                if(($inventory = $inventoryAction->getInventory()) instanceof WhateverInventory && !$inventory->isInteractable()){
                    $event->cancel();
                }
            }
        }
    }
}

?>