<?php

namespace airdrops\other\airdrop;

use airdrops\HCFLoaderAirDrop;

use airdrops\utils\Translator;
use airdrops\utils\item\EnchantmentDeserializer;

use airdrops\other\IData;
use airdrops\other\Handler;

use pocketmine\item\Item;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;

class AirDropFactory implements Handler {
    use SingletonTrait, IData;

    /** @var array<int, AirDrop> */
    protected array $airdrops = [];

    /**
     * @return void
     */
    public function load() : void {
        $this->setFileIterator(new Config(HCFLoaderAirDrop::getInstance()->getDataFolder()."other".DIRECTORY_SEPARATOR."airdrops.json", Config::JSON));
        try {
            foreach($this->getFileIterator()->getAll(true) as $name){
                $this->processSerializeData($name);
            }
        } catch(\Exception $exception){
            HCFLoaderAirDrop::getInstance()->getLogger()->warning($exception->getMessage());
        }
    }

    /**
     * @return void
     */
    public function save() : void {
        $this->get()?->save();
    }

    /**
     * @param mixed $data
     * @return void
     */
    public function processSerializeData(mixed $data) : void {

        $rawData = $this->getFileIterator()->get($data);
        if(isset($rawData["item"])){
            $xd = $rawData["item"];
            $rawData["item"] = Translator::stringToItem($xd);
        }
        if(isset($rawData["contents"])){
            foreach($rawData["contents"] as $slot => $serializedItem){
                $deserializedItem = Translator::decodeItem($serializedItem);

                $rawData["contents"][$slot] = EnchantmentDeserializer::deserialize($deserializedItem);
            }
        }
        $this->add($rawData["item"] ?? null, $rawData["contents"] ?? []);
    }

    /**
     * @param Item|null $item
     * @param array $contents
     * @return AirDrop
     */
    public function add(?Item $item, array $contents) : AirDrop {
        return $this->airdrops[self::AIRDROP] = new AirDrop($item, $contents);
    }

    /**
     * @return void
     */
    public function remove() : void {
        unset($this->airdrops[self::AIRDROP]);

        $this->removeFromFileIterator(self::AIRDROP);
    }

    /**
     * @return AirDrop|null
     */
    public function get() : ?AirDrop {
        return $this->airdrops[self::AIRDROP] ?? null;
    }
}

?>