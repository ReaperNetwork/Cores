<?php

namespace airdrops\other\airdrop\command\subcommands;

use airdrops\utils\TextHelper;

use airdrops\other\airdrop\AirDrop;
use airdrops\other\airdrop\AirDropFactory;

use airdrops\commands\utils\SubCommand;
use pocketmine\command\CommandSender;

class AirDropDeleteSubCommand extends SubCommand {

    public function __construct(){
        parent::__construct("delete", "", []);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return void
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
        if(!AirDropFactory::getInstance()->get() instanceof AirDrop){
            $sender->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-not-exists")));
            return;
        }
        AirDropFactory::getInstance()->remove();

        $sender->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-delete")));
    }
}

?>