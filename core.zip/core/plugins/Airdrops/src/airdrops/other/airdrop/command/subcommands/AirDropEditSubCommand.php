<?php

namespace airdrops\other\airdrop\command\subcommands;

use airdrops\utils\Builder;
use airdrops\utils\TextHelper;

use airdrops\api\gui\type\ChestInventory;

use airdrops\other\airdrop\AirDrop;
use airdrops\other\airdrop\AirDropFactory;

use airdrops\commands\utils\SubCommand;

use pocketmine\utils\TextFormat;
use pocketmine\world\Position;
use pocketmine\block\VanillaBlocks;

use pocketmine\player\Player;
use pocketmine\command\CommandSender;

class AirDropEditSubCommand extends SubCommand {

    public function __construct(){
        parent::__construct("edit", "", []);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return void
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
        /** @var Player $sender */
        if(!AirDropFactory::getInstance()->get() instanceof AirDrop){
            $sender->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-not-exists")));
            return;
        }
        $form = AirDropFactory::menu(function(Player $player, mixed $result) : void {
            if($result === null){
                return;
            }
            $airdrop = AirDropFactory::getInstance()->get();
            switch($result){
                case 0:
                    if(($item = $player->getInventory()->getItemInHand())->isNull()){
                        $player->sendMessage(TextHelper::replace("&cItem can't be null"));
                        return;
                    }
                    $airdrop->setItem($item);
                    $airdrop->save();
                    return;
                break;
                case 1:
                    $player->getNetworkSession()->sendDataPacket(Builder::buildBlock(($position = Position::fromObject($player->getPosition()->subtract(0, 4, 0)->floor(), $player->getWorld())), VanillaBlocks::CHEST()));
                    $player->setCurrentWindow(($inventory = ChestInventory::create($player, $airdrop->getContents(), true, $position, false)));

                    $inventory->onCloseCallable(function(Player $player, ChestInventory $inventory) use ($airdrop) : void {
                        $contents = count($inventory->getContents()) === 0 ? $airdrop->getContents() : $inventory->getContents();

                        $airdrop->setContents($contents);
                        $airdrop->save();
                    });
                    return;
                break;
                case 2:
                    if(count($airdrop->getContents()) === 0){
                        $player->sendMessage(TextHelper::replace("&cEmpty ..."));
                        return;
                    }
                    $player->getNetworkSession()->sendDataPacket(Builder::buildBlock(($position = Position::fromObject($player->getPosition()->subtract(0, 4, 0)->floor(), $player->getWorld())), VanillaBlocks::CHEST()));
                    $player->setCurrentWindow(ChestInventory::create($player, $airdrop->getContents(), false, $position, false));
                    return;
                break;
            }
        });
        $form->setTitle(TextHelper::replace("&r&l&6EDITOR"));

        $form->addButton(TextHelper::replace("&rITEM".TextFormat::EOL."&aEdit item"));
        $form->addButton(TextHelper::replace("&rCONTENTS".TextFormat::EOL."&aEdit contents"));
        $form->addButton(TextHelper::replace("&rSEE REWARDS"));

        $sender->sendForm($form);
    }
}

?>