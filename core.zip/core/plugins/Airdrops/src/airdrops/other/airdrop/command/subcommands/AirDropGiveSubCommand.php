<?php

namespace airdrops\other\airdrop\command\subcommands;

use airdrops\utils\TextHelper;

use airdrops\other\airdrop\AirDrop;
use airdrops\other\airdrop\AirDropFactory;

use airdrops\commands\utils\SubCommand;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\command\CommandSender;

class AirDropGiveSubCommand extends SubCommand {

    public function __construct(){
        parent::__construct("give", "", []);
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     * @return void
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args) : void {
        if(count($args) <= 1){
            $sender->sendMessage(TextHelper::replace("&c/airdrop give <player|@a> <amount>"));
            return;
        }
        if(!($airdrop = AirDropFactory::getInstance()->get()) instanceof AirDrop){
            $sender->sendMessage(TextHelper::replace(TextHelper::getMessageFile()->get("airdrop-not-exists")));
            return;
        }
        $amount = 1;
        if(count($args) > 2){
            $amount = is_numeric($args[2]) ? intval($args[2]) : $amount;
        }
        switch($args[1]){
            case ($player = Server::getInstance()->getPlayerByPrefix($args[1])) instanceof Player:
                $airdrop->give($player, $amount);
            break;
            case "all":
                foreach(Server::getInstance()->getOnlinePlayers() as $player){
                    $airdrop->give($player, $amount);
                }
            break;
        }
    }
}

?>