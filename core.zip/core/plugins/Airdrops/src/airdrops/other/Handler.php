<?php

namespace airdrops\other;

interface Handler {

    const AIRDROP = "airdrop";
}

?>