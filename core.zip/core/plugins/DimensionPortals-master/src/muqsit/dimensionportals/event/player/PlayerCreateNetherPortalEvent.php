<?php

declare(strict_types=1);

namespace muqsit\dimensionportals\event\player;

class PlayerCreateNetherPortalEvent extends PlayerCreatePortalEvent{
}