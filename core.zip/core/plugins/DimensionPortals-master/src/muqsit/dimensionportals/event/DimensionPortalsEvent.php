<?php

declare(strict_types=1);

namespace muqsit\dimensionportals\event;

use pocketmine\event\Event;

abstract class DimensionPortalsEvent extends Event{
}