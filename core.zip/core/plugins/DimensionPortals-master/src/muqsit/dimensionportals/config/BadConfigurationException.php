<?php

declare(strict_types=1);

namespace muqsit\dimensionportals\config;

use RuntimeException;

class BadConfigurationException extends RuntimeException{
}