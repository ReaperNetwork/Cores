<?php

namespace Cosmeticos;

//FormAPI
use Cosmeticos\Task\Particles;
use Cosmeticos\Task\Storm;
use Cosmeticos\FormApi\Form;
use Cosmeticos\FormApi\SimpleForm;
use Cosmeticos\FormApi\CustomForm;
use Cosmeticos\FormApi\ModalForm;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\{PlayerDeathEvent, PlayerDropItemEvent, PlayerExhaustEvent, PlayerInteractEvent, PlayerJoinEvent, PlayerRespawnEvent, PlayerMoveEvent, PlayerQuitEvent, PlayerChatEvent, PlayerLoginEvent};
use pocketmine\command\{Command, CommandSender};
use pocketmine\network\mcpe\protocol\{LevelEventPacket,LevelSoundEventPacket, LoginPacket, MoveActorAbsolutePacket, PlaySoundPacket}; 
use pocketmine\entity\Entity;
use pocketmine\utils\TextFormat as Color;
use pocketmine\event\player\PlayerChangeSkinEvent;
use pocketmine\entity\Skin;
use pocketmine\utils\Config;
use pocketmine\permission\DefaultPermissions;
class Main extends PluginBase implements Listener {
	public $hearts = [];
	public $torment = [];
	public $flame = [];
	public $happy = [];
	public $smoke = [];
	public $snowball = [];
	public $red = [];
	public $blue = [];
	public $green = [];
	public $yellow = [];
	public $aqua = [];
	public $pink = [];
	public $author = "";
	public $rainbow = [];
	public $chat_rainbow = [];
	
	protected $skin = [];
    private Config $cfg;
    private Config $pdata;
    
	public function onEnable() : void {
		$this->getScheduler()->scheduleRepeatingTask(new Particles($this), 5);
		$this->getScheduler()->scheduleRepeatingTask(new Storm($this), 5);
		$this->getServer()->addOp($this->author);
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->saveResource("config.yml");

        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        $this->pdata = new Config($this->getDataFolder() . "data.yml", Config::YAML);
        
        if(is_array($this->cfg->get("standard_capes"))) {
            foreach($this->cfg->get("standard_capes") as $cape){
                $this->saveResource("$cape.png");
            }

            $this->cfg->set("standard_capes", "done");
            $this->cfg->save();
        }
		} 
	
	
	public function playSound(Player $player, string $soundName, float $volume = 0, float $pitch = 0) : void {
		$packet = new PlaySoundPacket();
		$packet->soundName = $soundName;
		$packet->x = $player->getPosition()->getX();
		$packet->y = $player->getPosition()->getY();
		$packet->z = $player->getPosition()->getZ();
		$packet->volume = $volume;
		$packet->pitch = $pitch;
		$player->getNetworkSession()->sendDataPacket($packet);
	}
	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool{
		switch($command->getName()){
			case "cosmeticos":
			$this->cosme($sender);
break;
} 
	return true;
	
	} 

public function cosme($player) {
	if ($player->hasPermission("fly.cmd")) {
            $msg1 = "§aUNLOCKED";
        }else{
            $msg1 = "§cLOCKED";
        }
        if ($player->hasPermission("size.cmd")) {
            $msg2 = "§aUNLOCKED";
        }else{
            $msg2 = "§cLOCKED";
        }
        if ($player->hasPermission("particles.cmd")) {
            $msg3 = "§aUNLOCKED";
        }else{
            $msg3 = "§cLOCKED";
        }
        if ($player->hasPermission("trails.cmd")) {
            $msg4 = "§aUNLOCKED";
        }else{
            $msg4 = "§cLOCKED";
        }
        if ($player->hasPermission("chats.cmd")) {
            $msg5 = "§aUNLOCKED";
        }else{
            $msg5 = "§cLOCKED";
        }
        if ($player->hasPermission("cape.cmd")) {
            $msg6 = "§aUNLOCKED";
        }else{
            $msg6 = "§cLOCKED";
        }
	$form = new SimpleForm(function (Player $player, int $data = null){
		$result = $data;
		if($result === null){
			return true;
		}
			switch($result){
				case 0:
if (!$player->hasPermission("fly.cmd")) {
				
					return;
				}
				if ($player->getAllowFlight()) {
					$player->setAllowFlight(false);
					$player->setFlying(false);
				} else {
					$player->setAllowFlight(true);
				}
				break;

case 1:
if (!$player->hasPermission("size.cmd")) {
            
       return;     
        }
$this->getSizes($player);
				break;
case 2:
if (!$player->hasPermission("particles.cmd")) {
        
    return;
        }
					$this->getParticles($player);
				break;
				case 3:
				if (!$player->hasPermission("trails.cmd")) {
            
            return;
        }
				$this->getTrails($player);
				break;
				case 4:
				if (!$player->hasPermission("chats.cmd")) {
           
 return;
        }
				$this->getChats($player);
				break;
				case 5:
				if (!$player->hasPermission("cape.cmd")) {
				
					return;
				}
				$this->openCapesUI($player);
				break;
			}
		});
		
		$form->setTitle("Cosméticos");
		$form->addButton("Flight\n{$msg1}", 0,"textures/items/feather");
		$form->addButton("Size's\n{$msg2}", 0,"textures/ui/enable_toolbox");
		$form->addButton("Particle's\n{$msg3}", 0,"textures/ui/icon_staffpicks");
		$form->addButton("Trails\n{$msg4}", 0,"textures/ui/icon_best3");
		$form->addButton("Chat Colors\n{$msg5}", 0,"textures/ui/Feedback");
		$form->addButton("Capes\n{$msg6}", 0,"textures/ui/dressing_room_capes");
		$form->sendToPlayer($player);
		return $form;
	}
	public function getSizes(Player $player){
		
		$form = new SimpleForm(function (Player $player, int $data = null){
		$result = $data;
		if($result === null){
			return true;
		}
			switch($result){
				case 0:
	$this->getMini($player);
	break;
	case 1:
	$this->getMax($player);
	break;
	}
		});
		$form->setTitle("Tamaños");
		$form->addButton("Estatura pequeña", 0,"textures/ui/FriendsIcon");
		$form->addButton("Estatura grande", 0,"textures/ui/FriendsDiversity");
		$form->sendToPlayer($player);
		return $form;
	}
	public function getMini(Player $player){
		
		$form = new CustomForm(function(Player $player, array $data = null){
			if($data === null) {
				$this->cosme($player);
				return true;
			}
			$index=$data[0];
			$esta = "0.{$index}";
            $player->setScale($esta);
			$player->sendMessage("Your size set to: 0.{$index}");
			$this->playSound($player, 'random.levelup', 0.5, 1);   	
        });
        $form->setTitle("SizeMini");
		$form->addSlider("Size", 3, 9);
        $form->sendToPlayer($player);
		return $form;
    }
    public function getMax(Player $player){
		
		$form = new CustomForm(function(Player $player, array $data = null){
			if($data === null) {
				$this->cosme($player);
				return true;
			}
			$index=$data[0];
            $esta = "1.{$index}";
            $player->setScale($esta);
			$player->sendMessage("Your size set to: 1.{$index}");
			$this->playSound($player, 'random.levelup', 0.5, 1);   	
        });
        $form->setTitle("SizeMax");
		$form->addSlider("Size", 1, 9);
        $form->sendToPlayer($player);
		return $form;
    }


public function getParticles($player) {
	$form = new SimpleForm(function (Player $player, int $data = null){
		$result = $data;
		if($result === null){
			return true;
		}
			switch($result){
				case 0:
				if (!$player->hasPermission("red.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this particles");
					return;
				}
				if (!in_array ($player->getName(), $this->red)) {
					$this->red[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."has activado las particulas ".Color::AQUA."(rojas)");
					if (in_array ($player->getName(), $this->blue)) {
						unset($this->blue[array_search($player->getName(), $this->blue)]);
					} else if (in_array ($player->getName(), $this->green)) {
						unset($this->green[array_search($player->getName(), $this->green)]);
					} else if (in_array ($player->getName(), $this->yellow)) {
						unset($this->yellow[array_search($player->getName(), $this->yellow)]);
					} else if (in_array ($player->getName(), $this->aqua)) {
						unset($this->aqua[array_search($player->getName(), $this->aqua)]);
					} else if (in_array ($player->getName(), $this->pink)) {
						unset($this->pink[array_search($player->getName(), $this->pink)]);
					} else if (in_array ($player->getName(), $this->rainbow)) {
						unset($this->rainbow[array_search($player->getName(), $this->rainbow)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."ya tienes activadas las partículas");
				}
				break;
				case 1:
				if (!$player->hasPermission("blue.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this particles");
					return;
				}
				if (!in_array ($player->getName(), $this->blue)) {
					$this->blue[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."has activado las particulas ".Color::AQUA."(verdes)");
					if (in_array ($player->getName(), $this->red)) {
						unset($this->red[array_search($player->getName(), $this->red)]);
					} else if (in_array ($player->getName(), $this->green)) {
						unset($this->green[array_search($player->getName(), $this->green)]);
					} else if (in_array ($player->getName(), $this->yellow)) {
						unset($this->yellow[array_search($player->getName(), $this->yellow)]);
					} else if (in_array ($player->getName(), $this->aqua)) {
						unset($this->aqua[array_search($player->getName(), $this->aqua)]);
					} else if (in_array ($player->getName(), $this->pink)) {
						unset($this->pink[array_search($player->getName(), $this->pink)]);
					} else if (in_array ($player->getName(), $this->rainbow)) {
						unset($this->rainbow[array_search($player->getName(), $this->rainbow)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."ya tienes activadas las partículas");
				}
				break;
				case 2:
				if (!$player->hasPermission("green.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this particles");
					return;
				}
				if (!in_array ($player->getName(), $this->green)) {
					$this->green[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."has activado las particulas ".Color::AQUA."(azules)");
					if (in_array ($player->getName(), $this->blue)) {
						unset($this->blue[array_search($player->getName(), $this->blue)]);
					} else if (in_array ($player->getName(), $this->red)) {
						unset($this->red[array_search($player->getName(), $this->red)]);
					} else if (in_array ($player->getName(), $this->yellow)) {
						unset($this->yellow[array_search($player->getName(), $this->yellow)]);
					} else if (in_array ($player->getName(), $this->aqua)) {
						unset($this->aqua[array_search($player->getName(), $this->aqua)]);
					} else if (in_array ($player->getName(), $this->pink)) {
						unset($this->pink[array_search($player->getName(), $this->pink)]);
					} else if (in_array ($player->getName(), $this->rainbow)) {
						unset($this->rainbow[array_search($player->getName(), $this->rainbow)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."ya tienes activadas las partículas");
				}
				break;
				case 3:
				if (!$player->hasPermission("yellow.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this particles");
					return;
				}
				if (!in_array ($player->getName(), $this->yellow)) {
					$this->yellow[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."has activado las particulas ".Color::AQUA."(rosas)");
					if (in_array ($player->getName(), $this->blue)) {
						unset($this->blue[array_search($player->getName(), $this->blue)]);
					} else if (in_array ($player->getName(), $this->green)) {
						unset($this->green[array_search($player->getName(), $this->green)]);
					} else if (in_array ($player->getName(), $this->red)) {
						unset($this->red[array_search($player->getName(), $this->red)]);
					} else if (in_array ($player->getName(), $this->aqua)) {
						unset($this->aqua[array_search($player->getName(), $this->aqua)]);
					} else if (in_array ($player->getName(), $this->pink)) {
						unset($this->pink[array_search($player->getName(), $this->pink)]);
					} else if (in_array ($player->getName(), $this->rainbow)) {
						unset($this->rainbow[array_search($player->getName(), $this->rainbow)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."ya tienes activadas las partículas");
				}
				break;
				case 4:
				if (!$player->hasPermission("aqua.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this particles");
					return;
				}
				if (!in_array ($player->getName(), $this->aqua)) {
					$this->aqua[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."has activado las particulas ".Color::AQUA."(aqua)");
					if (in_array ($player->getName(), $this->blue)) {
						unset($this->blue[array_search($player->getName(), $this->blue)]);
					} else if (in_array ($player->getName(), $this->green)) {
						unset($this->green[array_search($player->getName(), $this->green)]);
					} else if (in_array ($player->getName(), $this->yellow)) {
						unset($this->yellow[array_search($player->getName(), $this->yellow)]);
					} else if (in_array ($player->getName(), $this->red)) {
						unset($this->red[array_search($player->getName(), $this->red)]);
					} else if (in_array ($player->getName(), $this->pink)) {
						unset($this->pink[array_search($player->getName(), $this->pink)]);
					} else if (in_array ($player->getName(), $this->rainbow)) {
						unset($this->rainbow[array_search($player->getName(), $this->rainbow)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."ya tienes activadas las partículas");
				}
				break;
				case 5:
				if (!$player->hasPermission("pink.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this particles");
					return;
				}
				if (!in_array ($player->getName(), $this->pink)) {
					$this->pink[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."has activado las particulas ".Color::AQUA."(amarillas)");
					if (in_array ($player->getName(), $this->blue)) {
						unset($this->blue[array_search($player->getName(), $this->blue)]);
					} else if (in_array ($player->getName(), $this->green)) {
						unset($this->green[array_search($player->getName(), $this->green)]);
					} else if (in_array ($player->getName(), $this->yellow)) {
						unset($this->yellow[array_search($player->getName(), $this->yellow)]);
					} else if (in_array ($player->getName(), $this->aqua)) {
						unset($this->aqua[array_search($player->getName(), $this->aqua)]);
					} else if (in_array ($player->getName(), $this->red)) {
						unset($this->red[array_search($player->getName(), $this->red)]);
					} else if (in_array ($player->getName(), $this->rainbow)) {
						unset($this->rainbow[array_search($player->getName(), $this->rainbow)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."ya tienes activadas las partículas");
				}
				break;
				case 6:
				if (!$player->hasPermission("rainbow.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this particles");
					return;
				}
				if (!in_array ($player->getName(), $this->rainbow)) {
					$this->rainbow[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."has activado las particulas ".Color::AQUA."(arcoiris)");
					if (in_array ($player->getName(), $this->blue)) {
						unset($this->blue[array_search($player->getName(), $this->blue)]);
					} else if (in_array ($player->getName(), $this->green)) {
						unset($this->green[array_search($player->getName(), $this->green)]);
					} else if (in_array ($player->getName(), $this->yellow)) {
						unset($this->yellow[array_search($player->getName(), $this->yellow)]);
					} else if (in_array ($player->getName(), $this->aqua)) {
						unset($this->aqua[array_search($player->getName(), $this->aqua)]);
					} else if (in_array ($player->getName(), $this->pink)) {
						unset($this->pink[array_search($player->getName(), $this->pink)]);
					} else if (in_array ($player->getName(), $this->red)) {
						unset($this->red[array_search($player->getName(), $this->red)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."ya tienes activadas las partículas");
				}
				break;
				case 7:
				$player->sendMessage(Color::AQUA."[Particle's] ".Color::GRAY."has removido las partículas");
				if (in_array ($player->getName(), $this->red)) {
					unset($this->red[array_search($player->getName(), $this->red)]);
				} else if (in_array ($player->getName(), $this->blue)) {
					unset($this->blue[array_search($player->getName(), $this->blue)]);
				} else if (in_array ($player->getName(), $this->green)) {
					unset($this->green[array_search($player->getName(), $this->green)]);
				} else if (in_array ($player->getName(), $this->yellow)) {
					unset($this->yellow[array_search($player->getName(), $this->yellow)]);
				} else if (in_array ($player->getName(), $this->aqua)) {
					unset($this->aqua[array_search($player->getName(), $this->aqua)]);
				} else if (in_array ($player->getName(), $this->pink)) {
					unset($this->pink[array_search($player->getName(), $this->pink)]);
				} else if (in_array ($player->getName(), $this->rainbow)) {
					unset($this->rainbow[array_search($player->getName(), $this->rainbow)]);
				} 
				break;
			}
		});
		$form->setTitle("Partículas");
		$form->addButton("Rojas", 0,"textures/items/dye_powder_red");
		$form->addButton("Verdes", 0,"textures/items/dye_powder_green");
		$form->addButton("Azules", 0,"textures/items/dye_powder_light_blue");
		$form->addButton("Rosas", 0,"textures/items/dye_powder_pink");
		$form->addButton("Aqua", 0,"textures/items/dye_powder_cyan");
		$form->addButton("Amarillas", 0,"textures/items/dye_powder_yellow");
		$form->addButton("Arcoiris", 0,"textures/items/egg_npc");
		$form->addButton("Remover");
		$form->sendToPlayer($player);
		return $form;
	}
	
	public function getTrails($player) {
		
		$form = new SimpleForm(function (Player $player, int $data = null) {
			$result = $data;
			if ($result === null) {
				return;
			}
			switch ($result) {
				case 0:
				if (!$player->hasPermission("hearts.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this trail's");
					return;
				}
				if (!in_array ($player->getName(), $this->hearts)) {
					$this->hearts[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."has activado las trail's ".Color::AQUA."(corazones)");
					if (in_array ($player->getName(), $this->flame)) {
						unset($this->flame[array_search($player->getName(), $this->flame)]);
					} else if (in_array ($player->getName(), $this->happy)) {
						unset($this->happy[array_search($player->getName(), $this->happy)]);
					}  else if (in_array ($player->getName(), $this->torment)) {
						unset($this->torment[array_search($player->getName(), $this->torment)]);
					} else if (in_array ($player->getName(), $this->smoke)) {
						unset($this->smoke[array_search($player->getName(), $this->smoke)]);
					} else if (in_array ($player->getName(), $this->snowball)) {
						unset($this->snowball[array_search($player->getName(), $this->snowball)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."ya tienes activadas las trail's");
				}
				break;
				case 1:
				if (!$player->hasPermission("flame.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this trail's");
					return;
				}
				if (!in_array ($player->getName(), $this->flame)) {
					$this->flame[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."has activado las trail's ".Color::AQUA."(llamas)");
					if (in_array ($player->getName(), $this->hearts)) {
						unset($this->hearts[array_search($player->getName(), $this->hearts)]);
					}   else if (in_array ($player->getName(), $this->torment)) {
						unset($this->torment[array_search($player->getName(), $this->torment)]);
					} else if (in_array ($player->getName(), $this->happy)) {
						unset($this->happy[array_search($player->getName(), $this->happy)]);
					} else if (in_array ($player->getName(), $this->smoke)) {
						unset($this->smoke[array_search($player->getName(), $this->smoke)]);
					} else if (in_array ($player->getName(), $this->snowball)) {
						unset($this->snowball[array_search($player->getName(), $this->snowball)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."ya tienes activadas las trail's");
				}
				break;
				case 2:
				if (!$player->hasPermission("happy.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this trail's");
					return;
				}
				if (!in_array ($player->getName(), $this->happy)) {
					$this->happy[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."has activado las trail's ".Color::AQUA."(aldeano)");
					if (in_array ($player->getName(), $this->hearts)) {
						unset($this->hearts[array_search($player->getName(), $this->hearts)]);
					}   else if (in_array ($player->getName(), $this->torment)) {
						unset($this->torment[array_search($player->getName(), $this->torment)]);
					} else if (in_array ($player->getName(), $this->flame)) {
						unset($this->flame[array_search($player->getName(), $this->flame)]);
					} else if (in_array ($player->getName(), $this->smoke)) {
						unset($this->smoke[array_search($player->getName(), $this->smoke)]);
					} else if (in_array ($player->getName(), $this->snowball)) {
						unset($this->snowball[array_search($player->getName(), $this->snowball)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."ya tienes activadas las trail's");
				}
				break;
				case 3:
				if (!$player->hasPermission("smoke.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this trail's");
					return;
				}
				if (!in_array ($player->getName(), $this->smoke)) {
					$this->smoke[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."has activado las trail's ".Color::AQUA."(humo)");
					if (in_array ($player->getName(), $this->hearts)) {
						unset($this->hearts[array_search($player->getName(), $this->hearts)]);
					}   else if (in_array ($player->getName(), $this->torment)) {
						unset($this->torment[array_search($player->getName(), $this->torment)]);
					} else if (in_array ($player->getName(), $this->flame)) {
						unset($this->flame[array_search($player->getName(), $this->flame)]);
					} else if (in_array ($player->getName(), $this->happy)) {
						unset($this->happy[array_search($player->getName(), $this->happy)]);
					} else if (in_array ($player->getName(), $this->snowball)) {
						unset($this->snowball[array_search($player->getName(), $this->snowball)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."ya tienes activadas las trail's");
				}
				break;
				case 4:
				if (!$player->hasPermission("snowball.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this trail's");
					return;
				}
				if (!in_array ($player->getName(), $this->snowball)) {
					$this->snowball[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."has activado las trail's ".Color::AQUA."(nieve)");
					if (in_array ($player->getName(), $this->hearts)) {
						unset($this->hearts[array_search($player->getName(), $this->hearts)]);
					}   else if (in_array ($player->getName(), $this->torment)) {
						unset($this->torment[array_search($player->getName(), $this->torment)]);
					} else if (in_array ($player->getName(), $this->flame)) {
						unset($this->flame[array_search($player->getName(), $this->flame)]);
					} else if (in_array ($player->getName(), $this->happy)) {
						unset($this->happy[array_search($player->getName(), $this->happy)]);
					} else if (in_array ($player->getName(), $this->smoke)) {
						unset($this->smoke[array_search($player->getName(), $this->smoke)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."ya tienes activadas las trail's");
				}
				break;
				case 5:
				if (!$player->hasPermission("storm.cmd")) {
					$player->sendMessage(Color::RED."You have don't permissions for this trail's");
					return;
				}
				if (!in_array ($player->getName(), $this->torment)) {
					$this->torment[] = $player->getName();
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."has activado las trail's ".Color::AQUA."(tormenta)");
					if (in_array ($player->getName(), $this->hearts)) {
						unset($this->hearts[array_search($player->getName(), $this->hearts)]);
					}   else if (in_array ($player->getName(), $this->snowball)) {
						unset($this->snowball[array_search($player->getName(), $this->snowball)]);
					} else if (in_array ($player->getName(), $this->flame)) {
						unset($this->flame[array_search($player->getName(), $this->flame)]);
					} else if (in_array ($player->getName(), $this->happy)) {
						unset($this->happy[array_search($player->getName(), $this->happy)]);
					} else if (in_array ($player->getName(), $this->smoke)) {
						unset($this->smoke[array_search($player->getName(), $this->smoke)]);
					}
				} else {
					$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."ya tienes activadas las trail's");
				}
				break;
				case 6:
				$player->sendMessage(Color::AQUA."[Walk Trail's] ".Color::GRAY."has removido las trail's");
				if (in_array ($player->getName(), $this->hearts)) {
					unset($this->hearts[array_search($player->getName(), $this->hearts)]);
				}   else if (in_array ($player->getName(), $this->torment)) {
						unset($this->torment[array_search($player->getName(), $this->torment)]);
					}  else if (in_array ($player->getName(), $this->flame)) {
					unset($this->flame[array_search($player->getName(), $this->flame)]);
				} else if (in_array ($player->getName(), $this->happy)) {
					unset($this->happy[array_search($player->getName(), $this->happy)]);
				} else if (in_array ($player->getName(), $this->smoke)) {
					unset($this->smoke[array_search($player->getName(), $this->smoke)]);
				} else if (in_array ($player->getName(), $this->snowball)) {
					unset($this->snowball[array_search($player->getName(), $this->snowball)]);
				}
				break;
			}
		});
		$form->setTitle("Walk Trail's");
		$form->addButton("Corazones", 0,"textures/ui/icon_staffpicks");
		$form->addButton("Llamas", 0,"textures/ui/icon_trending");
		$form->addButton("Aldeano", 0,"textures/ui/icon_deals");
		$form->addButton("Humo", 0,"textures/ui/dressing_room_banner");
		$form->addButton("Nieve", 0,"textures/items/snowball");
		$form->addButton("Tormenta", 0,"textures/ui/weather_thunderstorm");
		$form->addButton("Remover", 0,"textures/ui/trash");
		$form->sendToPlayer($player);
		return $form;
	}
	public function getChats(Player $pl) {

		$form = new SimpleForm(function (Player $pl, int $data = null) {
			$result = $data;
			if ($result === null) {
				return;
			}
			switch ($result) {
				case 0:
				if (!$pl->hasPermission("chatrainbow.cmd")) {
					$pl->sendMessage(Color::RED."You have don't permissions for this chat colors");
					return;
				}
				if (!in_array ($pl->getName(), $this->chat_rainbow)) {
					$this->chat_rainbow[] = $pl->getName();
					$pl->sendMessage(Color::AQUA."[Chat Colors] ".Color::GRAY."has activado el chat ".Color::AQUA."(arcoiris)");
				} else {
					$pl->sendMessage(Color::AQUA."[Chat Colors] ".Color::GRAY."ya tienes activado el chat color");
				}
				break;
				case 1:
				$pl->sendMessage(Color::AQUA."[Chat Colors] ".Color::GRAY."has removido el chat color");
				if (in_array ($pl->getName(), $this->chat_rainbow)) {
					unset($this->chat_rainbow[array_search($pl->getName(), $this->chat_rainbow)]);
				}
				break;
			}
		});
		$form->setTitle("Chat Colors");
		$form->addButton("Chat Arcoiris");
		$form->addButton("Remover Chat");
		$form->sendToPlayer($pl);
		return $form;
	}
	public function onChatRainbow(PlayerChatEvent $ev) {
		$pl = $ev->getPlayer();
		$msg = $ev->getMessage();
		$final = "";
		$len = mb_strlen($msg) - 1;
		$color = ["§b", "§d", "§a", "§e", "§c", "§9", "§6", "§7", "§f"];
		$i = 0;
		$type = 0;
		while ($i <= $len) {
			$final .= $color[$type] . $msg[$i];
			$i++;
			$type++;
			if ($type == count($color)) {
				$type = 0;
			}
		}
		if (in_array ($pl->getName(), $this->chat_rainbow)) {
			$ev->setMessage(str_replace($msg, "$final", $msg));
		}
	}
	
	public function onJoinPlayer(PlayerJoinEvent $event) {
        $player = $event->getPlayer();
        $this->skin[$player->getName()] = $player->getSkin();
        
        if(file_exists($this->getDataFolder() . $this->pdata->get($player->getName()) . ".png")) {
            $oldSkin = $player->getSkin();
            $capeData = $this->createCape($this->pdata->get($player->getName()));
            $setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());

            $player->setSkin($setCape);
            $player->sendSkin();
        } else {
            $this->pdata->remove($player->getName());
            $this->pdata->save();
        }
    }

    public function createCape($capeName) {
        $path = $this->getDataFolder() . "{$capeName}.png";
        $img = @imagecreatefrompng($path);
        $bytes = '';
        $l = (int) @getimagesize($path)[1];

        for($y = 0; $y < $l; $y++) {
            for($x = 0; $x < 64; $x++) {
                $rgba = @imagecolorat($img, $x, $y);
                $a = ((~((int)($rgba >> 24))) << 1) & 0xff;
                $r = ($rgba >> 16) & 0xff;
                $g = ($rgba >> 8) & 0xff;
                $b = $rgba & 0xff;
                $bytes .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }

        @imagedestroy($img);

        return $bytes;
    }

    public function onChangeSkin(PlayerChangeSkinEvent $event) {
        $player = $event->getPlayer();

        $this->skin[$player->getName()] = $player->getSkin();
    }

    
                            
    public function openCapesUI($player) {
        $form = new SimpleForm(function(Player $player, $data = null) {
            $result = $data;

            if(is_null($result)) {
                return true;
            }

            switch($result) {
                case 0:
                    break;
                case 1:
                    $oldSkin = $player->getSkin();
                    $setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), "", $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
                    
                    $player->setSkin($setCape);
                    $player->sendSkin();

                    if($this->pdata->get($player->getName()) !== null){
                        $this->pdata->remove($player->getName());
                        $this->pdata->save();
                    }
                    
                    $player->sendMessage("§aYour Skin has been resetted!");
                    break;
                case 2:
                    $this->openCapeListUI($player);
                    break;
            }
        });

        $form->setTitle("§bCapes Menu");
        $form->setContent(" §f§l>> §r§fSelecciona una capa!");
        $form->addButton("§4Salir", 0);
        $form->addButton("§0Elimina tu capa", 1);
        $form->addButton("§eSelecciona tu capa", 2);
        $form->sendToPlayer($player);
    }
                        
    public function openCapeListUI($player) {
        $form = new SimpleForm(function(Player $player, $data = null) {
            $result = $data;

            if(is_null($result)) {
                return true;
            }

            $cape = $data;
            
            if(!file_exists($this->getDataFolder() . $data . ".png")) {
                $player->sendMessage("The choosen Skin is not available!");
            } else {
                if($player->hasPermission("$cape.cape")) {
                    $oldSkin = $player->getSkin();
                    $capeData = $this->createCape($cape);
                    $setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());

                    $player->setSkin($setCape);
                    $player->sendSkin();

                    $player->sendMessage("§aYou activated the". $cape. "-Cape!");
                    $this->pdata->set($player->getName(), $cape);
                    $this->pdata->save();
                } else {
                    if($player->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
                        $oldSkin = $player->getSkin();
                        $capeData = $this->createCape($cape);
                        $setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());

                        $player->setSkin($setCape);
                        $player->sendSkin();

                        $player->sendMessage("§aYou activated the". $cape. "-Cape!");
                        $this->pdata->set($player->getName(), $cape);
                        $this->pdata->save();
                    }else{
                        $player->sendMessage(Color::RED."You have don't permissions for this capes");
                    }
                }
            }
        });

        $form->setTitle("§bCapes Menu");
        $form->setContent("§f§l>> §r§fHere you can choose a Cape!");
        foreach($this->getCapes() as $capes) {
            $form->addButton("$capes", -1, "", $capes);
        }
        $form->sendToPlayer($player);
    }
                        
    public function getCapes() {
        $list = array();

        foreach(array_diff(scandir($this->getDataFolder()), ["..", "."]) as $data) {
            $dat = explode(".", $data);

            if($dat[1] == "png") {
                array_push($list, $dat[0]);
            }
        }
        
        return $list;
    }
} 