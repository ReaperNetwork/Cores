<?php

namespace Cosmeticos\Task;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat as Color;
use pocketmine\utils\Config;
use pocketmine\scheduler\Task;
use pocketmine\scheduler\TaskHandler;
use pocketmine\math\Vector3;
use pocketmine\world\particle\{DustParticle, CriticalParticle};
use pocketmine\level\Level;
use pocketmine\world\particle\HeartParticle;
use pocketmine\world\particle\FlameParticle;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\world\particle\SmokeParticle;
use pocketmine\world\particle\SnowballPoofParticle;
use Cosmeticos\Main;
use Cosmeticos\Particles\{EvaporationParticle, WaterSplashParticle};

	class Storm extends Task {
    private Main $plugin;
    private int $count = 0;

    public function __construct(Main $caller)
    {
        $this->plugin = $caller;
    }

    
    public function onRun(): void
    {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if (in_array ($player->getName(), $this->plugin->torment)) {
                $x = $player->getPosition()->getX();
                $y = $player->getPosition()->getY();
                $z = $player->getPosition()->getZ();
                $a = cos(deg2rad($this->count / 0.04)) * 0.5;
                $b = sin(deg2rad($this->count / 0.04)) * 0.5;
                $c = cos(deg2rad($this->count / 0.04)) * 0.8;
                $d = sin(deg2rad($this->count / 0.04)) * 0.8;
                $player->getWorld()->addParticle(new Vector3($x - $a, $y + 3, $z - $b), new EvaporationParticle());
                $player->getWorld()->addParticle(new Vector3($x - $b, $y + 3, $z - $a), new EvaporationParticle());

                $player->getWorld()->addParticle(new Vector3($x - $a, $y + 2.3, $z - $b), new WaterSplashParticle());
                $player->getWorld()->addParticle(new Vector3($x - $b, $y + 2.3, $z - $a), new WaterSplashParticle());

                $player->getWorld()->addParticle(new Vector3($x + $c, $y + 3, $z + $d), new EvaporationParticle());
                $player->getWorld()->addParticle(new Vector3($x + $c, $y + 3, $z + $d), new EvaporationParticle());

                $player->getWorld()->addParticle(new Vector3($x, $y + 3, $z), new EvaporationParticle());
                $player->getWorld()->addParticle(new Vector3($x, $y + 2.3, $z), new WaterSplashParticle());
            }
        }
    }
}