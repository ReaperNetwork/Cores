<?php

declare(strict_types = 1);

namespace Cosmeticos\FormApi;

use pocketmine\plugin\PluginBase;

class FormAPI extends PluginBase{

}
