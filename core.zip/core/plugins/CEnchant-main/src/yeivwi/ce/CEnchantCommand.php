<?php

declare(strict_types=1);

namespace yeivwi\ce;

use hcf\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\entity\effect\EffectInstance;
use yeivwi\ce\enchantments\CustomEnchant;
use pocketmine\item\enchantment\EnchantmentInstance;

class CEnchantCommand extends Command
{

    public function __construct()
    {
        parent::__construct('ce', 'Use command for ce');
        $this->setPermission('ce.command');
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender instanceof Player) {
            return;
        }
        if (count($args) < 2) {
            $sender->sendMessage(TextFormat::colorize("&c/ce [int: id] [int: level]"));
            return;
        }

        if ($args[0] === "test") {
            foreach($sender->getInventory()->getContents() as $slot => $item){
                if($item instanceof Tool||$item instanceof Armor){
                    if($item->getDamage() > 0 and !$item->hasEnchantment(EnchantmentIdMap::getInstance()->fromId(self::IRREPARABLE))){
                        $sender->getInventory()->setItem($slot, $item->setDamage(0));
                    }
                }
            }
            foreach($sender->getArmorInventory()->getContents() as $slot => $item){
                if($item instanceof Tool||$item instanceof Armor){
                    if($item->getDamage() > 0 and !$item->hasEnchantment(EnchantmentIdMap::getInstance()->fromId(self::IRREPARABLE))){
                        $sender->getArmorInventory()->setItem($slot, $item->setDamage(0));
                    }
                }
            }
            $sender->sendMessage(TextFormat::GREEN . "All your inventory was repaired!");
            return;
        }
        
        if (!is_numeric($args[0]) || !is_numeric($args[1])) {
            $sender->sendMessage(TextFormat::colorize("&cThe enchantment must be of type int and given a string"));
            return;
        }
        
        $ench = EnchantmentIdMap::getInstance()->fromId((int)$args[0]);
        if(!$ench instanceof CustomEnchant) {
            $sender->sendMessage("Invalid enchant");
            return;
        }
        $item = $sender->getInventory()->getItemInHand();
        (int)$level = $args[1] ?? 1;
        
        $itemLore = $item->getLore();
        if (count($itemLore) === 0) {
            $itemLore[] = TextFormat::colorize('&r');
        }
        if ($item->hasEnchantment($ench)) {
            $oldEnchant = $item->getEnchantment($ench);
            if ($oldEnchant->getLevel() !== (int)$level) {
                if (in_array(TextFormat::colorize('&r'.$ench->getLoreLine($oldEnchant->getLevel())), $itemLore, true)) {
                    $itemLore[array_search(TextFormat::colorize('&r' . $ench->getLoreLine($oldEnchant->getLevel())), $itemLore, true)] = TextFormat::colorize('&r' . $ench->getLoreLine((int)$level));
                }
            } else {
                $sender->sendMessage(TextFormat::colorize('&cThis item already has ' . $ench->getName() . ' enchant.')); 
                return;
            }
        } else {
            $itemLore[] = TextFormat::colorize('&r'.$ench->getLoreLine((int)$level));
        }
        $item->addEnchantment(new EnchantmentInstance($ench, (int)$level));
        $item->setLore($itemLore);
        $sender->getInventory()->setItemInHand($item);
        $sender->sendMessage("§aCustom Enchantment placed on the item correctly.");
        return;
    }
}