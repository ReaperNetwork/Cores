<?php


namespace yeivwi\ce\enchantments;

use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\Rarity;
use pocketmine\utils\TextFormat;

class CustomEnchant extends Enchantment {
	/** @var string */
	private $description;
    private $id;

	public function __construct(string $name, string $description, int $id, int $rarity, int $primaryItemFlags, int $secondaryItemFlags, int $maxLevel) {
		$this->description = $description;
        $this->id = $id;
		parent::__construct($name, $rarity, $primaryItemFlags, $secondaryItemFlags, $maxLevel);
	}

	/**
	 * @return string
	 */
	public function getDescription(): string {
		return $this->description;
	}
    
    public function getId(): int {
        return $this->id;
    }

	public function getLoreLine(int $level): string {
		static $romanNumerals = [
			1 => "I", 2 => "II", 3 => "III", 4 => "IV", 5 => "V",
			6 => "VI", 7 => "VII", 8 => "VII", 9 => "IX", 10 => "X"
		];
		static $rarityColors = [
			Rarity::COMMON => TextFormat::YELLOW,
			Rarity::UNCOMMON => TextFormat::MINECOIN_GOLD,
			Rarity::RARE => TextFormat::RED,
			Rarity::MYTHIC => TextFormat::DARK_RED,
		];
		return $rarityColors[$this->getRarity()] . $this->getName() . " " . ($romanNumerals[$level] ?? ((string)$level));
	}
}