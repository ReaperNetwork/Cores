<?php


namespace yeivwi\ce\enchantments;

use pocketmine\player\Player;

interface ItemHeldEnchant {
	public function onHeld(Player $p, int $level): void;

	public function onUnHeld(Player $p, int $level): void;
}