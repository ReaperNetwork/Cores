<?php


namespace yeivwi\ce\enchantments;

use pocketmine\item\VanillaItems;
use pocketmine\block\BlockTypeIds;
use pocketmine\crafting\FurnaceType;
use pocketmine\event\block\BlockBreakEvent;

class AutoSmeltEnchant extends CustomEnchant implements BlockBreakEnchant {
	public function onBreak(BlockBreakEvent $ev, int $level): void {
        $block = $ev->getBlock();
		$drops = $ev->getDrops();
        
        $blocks = [
			BlockTypeIds::IRON_ORE => [VanillaItems::IRON_INGOT()],
			BlockTypeIds::GOLD_ORE => [VanillaItems::GOLD_INGOT()]
		];
        
        $xpDropAmounts = [
			BlockTypeIds::GOLD_ORE => mt_rand(2, 4),
			BlockTypeIds::IRON_ORE => mt_rand(0, 3)
		];
        
        $ev->setDrops($blocks[$block->getTypeId()] ?? $drops);
		$ev->setXpDropAmount($xpDropAmounts[$block->getTypeId()] ?? $ev->getXpDropAmount());
	}
}