<?php


namespace yeivwi\ce\enchantments;

use pocketmine\entity\effect\Effect;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\player\Player;
use pocketmine\utils\Limits;

class ArmorEffectEquipmentEnchant extends ArmorEquipmentEnchant {
	/** @var EffectInstance[] */
	private $givenEffects;
	/** @var Effect[][] */
	private $trackedPlayers = [];

	private $forcedLevel; // TODO: REMOVE THIS, THIS IS A BACK BACK BECAUSE WE FORGOT TO SET IT TO SPEED 2 BEFORE SOTW

	/**
	 * ArmorEffectEquipmentEnchant constructor.
	 * @param string $name
	 * @param string $description
	 * @param int $rarity
	 * @param int $primaryItemFlags
	 * @param int $secondaryItemFlags
	 * @param int $maxLevel
	 * @param EffectInstance[] $givenEffects
	 */
	public function __construct(string $name, string $description, int $id, int $rarity, int $primaryItemFlags, int $secondaryItemFlags, int $maxLevel, array $givenEffects, ?int $forcedLevel = null) {
		$this->forcedLevel = $forcedLevel;
		parent::__construct($name, $description, $id, $rarity, $primaryItemFlags, $secondaryItemFlags, $maxLevel);
		$this->givenEffects = $givenEffects;
		foreach($this->givenEffects as $k => $v) {
			$this->givenEffects[$k]->setDuration(Limits::INT32_MAX);
		}
	}

	public function onEquip(Player $p, int $level): void {
		$effMgr = $p->getEffects();
		$k = $p->getId();
		foreach($this->givenEffects as $effect) {
			$added = clone $effect;
			$added->setAmplifier($level - 1);
			$effMgr->add($added);
			$this->trackedPlayers[$k][spl_object_id($added)] = $effect->getType();
		}
	}

	public function onRemove(Player $p, int $level): void {
		$effMgr = $p->getEffects();
		$k = $p->getId();
		foreach(($this->trackedPlayers[$k] ?? []) as $objId => $effect) {
			if(!$effMgr->has($effect)) {
				unset($this->trackedPlayers[$k][$objId]);
				continue;
			}
			if(spl_object_id($effMgr->get($effect)) === $objId) {
				$effMgr->remove($effect);
				unset($this->trackedPlayers[$k][$objId]);
			}
		}
	}
}