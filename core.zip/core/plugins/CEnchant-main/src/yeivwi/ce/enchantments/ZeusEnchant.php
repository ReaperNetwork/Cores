<?php


namespace yeivwi\ce\enchantments;

use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\network\mcpe\protocol\types\LevelSoundEvent;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\world\particle\BlockBreakParticle;
use pocketmine\network\mcpe\protocol\types\entity\PropertySyncData;
use pocketmine\entity\Entity;
use pocketmine\entity\Human;
use pocketmine\world\Position;
use pocketmine\Server;
use hcf\utils\Utils;

class ZeusEnchant extends CustomEnchant implements CustomMeleeEnchantment {
	public function onPostAttack(Entity $attacker, Entity $victim, int $enchantmentLevel, float $finalDamage): void {
		if(!$attacker instanceof Human) return;
        if (!$victim instanceof Human) return;
		if(lcg_value() > (0.25 * $enchantmentLevel)) return;
        $player = $victim;
        Utils::playLight($player->getPosition());
        $player->setHealth($player->getHealth() - 0.8);
	}
}