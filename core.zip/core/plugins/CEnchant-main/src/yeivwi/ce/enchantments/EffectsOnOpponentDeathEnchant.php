<?php


namespace yeivwi\ce\enchantments;

use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\Entity;
use pocketmine\entity\Living;

class EffectsOnOpponentDeathEnchant extends CustomEnchant implements CustomMeleeEnchantment {
	/** @var EffectInstance[] */
	private $givenEffects;

	/**
	 * ArmorEffectEquipmentEnchant constructor.
	 * @param string $name
	 * @param string $description
	 * @param int $rarity
	 * @param int $primaryItemFlags
	 * @param int $secondaryItemFlags
	 * @param int $maxLevel
	 * @param EffectInstance[] $givenEffects
	 */
	public function __construct(string $name, string $description, int $id, int $rarity, int $primaryItemFlags, int $secondaryItemFlags, int $maxLevel, array $givenEffects) {
		parent::__construct($name, $description, $id, $rarity, $primaryItemFlags, $secondaryItemFlags, $maxLevel);
		$this->givenEffects = $givenEffects;
	}

	public function onPostAttack(Entity $attacker, Entity $victim, int $enchantmentLevel, float $finalDamage): void {
        if ($victim->getHealth() > $finalDamage) return;
		if(!$attacker->isOnline()) return;
		$effs = $attacker->getEffects();
		foreach($this->givenEffects as $effect) {
			$effs->add(clone $effect);
		}
	}
}