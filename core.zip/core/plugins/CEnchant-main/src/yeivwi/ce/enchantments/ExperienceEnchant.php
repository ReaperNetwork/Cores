<?php


namespace yeivwi\ce\enchantments;

use pocketmine\block\BlockTypeIds;
use pocketmine\event\block\BlockBreakEvent;

class ExperienceEnchant extends CustomEnchant implements BlockBreakEnchant {

	private const ORES = [
		BlockTypeIds::GOLD_ORE,
		BlockTypeIds::IRON_ORE,
		BlockTypeIds::COAL_ORE,
		BlockTypeIds::LAPIS_LAZULI_ORE,
		BlockTypeIds::DIAMOND_ORE,
		BlockTypeIds::REDSTONE_ORE,
		BlockTypeIds::EMERALD_ORE,
		BlockTypeIds::NETHER_QUARTZ_ORE,
	];

	public function onBreak(BlockBreakEvent $ev, int $level): void {
		if(!in_array($ev->getBlock()->getTypeId(), self::ORES))
			$ev->setXpDropAmount($ev->getXpDropAmount() * ($level + 1));
	}
}