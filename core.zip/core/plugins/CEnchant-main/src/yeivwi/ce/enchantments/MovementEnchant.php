<?php


namespace yeivwi\ce\enchantments;

use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\Item;

interface MovementEnchant {
	public function onMove(PlayerMoveEvent $ev, int $level, Item $item): void;
}