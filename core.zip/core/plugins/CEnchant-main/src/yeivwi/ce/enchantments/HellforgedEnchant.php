<?php


namespace yeivwi\ce\enchantments;

use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\Durable;
use pocketmine\item\Item;

class HellforgedEnchant extends CustomEnchant implements MovementEnchant {
	public function onMove(PlayerMoveEvent $ev, int $level, Item $item): void {
		if(!$item instanceof Durable) return;
		if($item->getDamage() <= 0) return;
		if(mt_rand(0, ($this->getMaxLevel() - $level) * 20) !== 0) return;
		$item->setDamage(max(0, $item->getDamage() - 1));
	}
}