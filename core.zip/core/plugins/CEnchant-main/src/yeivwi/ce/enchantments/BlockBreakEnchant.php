<?php


namespace yeivwi\ce\enchantments;

use pocketmine\event\block\BlockBreakEvent;

interface BlockBreakEnchant {
	public function onBreak(BlockBreakEvent $ev, int $level): void;
}