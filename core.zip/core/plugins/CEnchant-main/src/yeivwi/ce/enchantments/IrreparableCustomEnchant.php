<?php


namespace yeivwi\ce\enchantments;

use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\Item;

class IrreparableCustomEnchant extends CustomEnchant {

}