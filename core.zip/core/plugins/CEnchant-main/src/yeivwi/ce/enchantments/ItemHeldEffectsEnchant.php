<?php


namespace yeivwi\ce\enchantments;

use pocketmine\entity\effect\Effect;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\player\Player;
use pocketmine\utils\Limits;

class ItemHeldEffectsEnchant extends CustomEnchant implements ItemHeldEnchant {
	/** @var EffectInstance[] */
	private $givenEffects;
	/** @var Effect[][] */
	private $trackedPlayers = [];

	/**
	 * ArmorEffectEquipmentEnchant constructor.
	 * @param string $name
	 * @param string $description
	 * @param int $rarity
	 * @param int $primaryItemFlags
	 * @param int $secondaryItemFlags
	 * @param int $maxLevel
	 * @param EffectInstance[] $givenEffects
	 */
	public function __construct(string $name, string $description, int $id, int $rarity, int $primaryItemFlags, int $secondaryItemFlags, int $maxLevel, array $givenEffects) {
		parent::__construct($name, $description, $id, $rarity, $primaryItemFlags, $secondaryItemFlags, $maxLevel);
		$this->givenEffects = $givenEffects;
		foreach($this->givenEffects as $k => $v) {
			$this->givenEffects[$k]->setDuration(Limits::INT32_MAX);
		}
	}

	public function onHeld(Player $p, int $level): void {
		$effMgr = $p->getEffects();
		$k = $p->getId();
		foreach($this->givenEffects as $effect) {
			$added = clone $effect;
			$added->setAmplifier($level - 1);
			$effMgr->add($added);
			$this->trackedPlayers[$k][spl_object_id($added)] = $effect->getType();
		}
	}

	public function onUnHeld(Player $p, int $level): void {
		$effMgr = $p->getEffects();
		$k = $p->getId();
		foreach(($this->trackedPlayers[$k] ?? []) as $objId => $effect) {
			if(spl_object_id($effMgr->get($effect)) === $objId) {
				$effMgr->remove($effect);
				unset($this->trackedPlayers[$k][$objId]);
			}
		}
	}
}