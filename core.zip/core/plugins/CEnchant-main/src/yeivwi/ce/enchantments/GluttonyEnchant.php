<?php


namespace yeivwi\ce\enchantments;

use pocketmine\entity\Entity;
use pocketmine\entity\Human;

class GluttonyEnchant extends CustomEnchant implements CustomMeleeEnchantment {
    
	public function onPostAttack(Entity $attacker, Entity $victim, int $enchantmentLevel, float $finalDamage): void {
		if(!$attacker instanceof Human) return;
		if(lcg_value() > (0.10 * $enchantmentLevel)) return;
		$hMgr = $attacker->getHungerManager();
		if($hMgr->getFood() >= $hMgr->getMaxFood()) return;
		$hMgr->addFood(1);
	}
}