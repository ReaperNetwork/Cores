<?php


namespace yeivwi\ce\enchantments;

use yeivwi\ce\CEnchant;
use pocketmine\block\BlockTypeIds;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\world\World;
use pocketmine\block\Block;
use pocketmine\block\Wood;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;

class ChopperEnchant extends CustomEnchant implements BlockBreakEnchant {

	public function onBreak(BlockBreakEvent $ev, int $level): void {
        $block = $ev->getBlock();
		$player = $ev->getPlayer();

		if ($block instanceof Wood) {
			$this->breakTree($player, $block);
		}       
	}
    
    private function breakTree(Player $player, Block $block) : void {
		foreach ($block->getAllSides() as $side) {
			if ($block->getTypeId() === $side->getTypeId()) {
				$player->getWorld()->useBreakOn($side->getPosition(), $item, null, true);
                CEnchant::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(fn() => $this->breakTree($player, $side)), 1);
			} else {
				foreach ($side->getAllSides() as $secondSide) {
					if ($block->getTypeId() === $secondSide->getTypeId()) {
						$player->getWorld()->useBreakOn($secondSide->getPosition(), $item, null, true);
                        CEnchant::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(fn() => $this->breakTree($player, $secondSide)), 1);
					}
				}
			}
		}
	}
}