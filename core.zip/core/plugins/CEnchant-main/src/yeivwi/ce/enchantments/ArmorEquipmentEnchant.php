<?php


namespace yeivwi\ce\enchantments;

use pocketmine\player\Player;

abstract class ArmorEquipmentEnchant extends CustomEnchant {
	abstract public function onEquip(Player $p, int $level): void;

	abstract public function onRemove(Player $p, int $level): void;
}