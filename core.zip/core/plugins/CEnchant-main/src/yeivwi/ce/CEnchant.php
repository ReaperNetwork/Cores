<?php

namespace yeivwi\ce;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\EventPriority;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\inventory\ArmorInventory;
use pocketmine\inventory\Inventory;
use pocketmine\item\Armor;
use pocketmine\item\Axe;
use pocketmine\item\Bow;
use pocketmine\item\enchantment\ItemFlags;
use pocketmine\item\enchantment\Rarity;
use pocketmine\item\FlintSteel;
use pocketmine\item\Hoe;
use pocketmine\item\Item;
use pocketmine\item\Pickaxe;
use pocketmine\item\Shears;
use pocketmine\item\Shovel;
use pocketmine\item\Sword;
use pocketmine\item\Tool;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\inventory\ItemStack;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\utils\TextFormat;
use yeivwi\ce\enchantments\ArmorEffectEquipmentEnchant;
use yeivwi\ce\enchantments\ArmorEquipmentEnchant;
use yeivwi\ce\enchantments\AutoSmeltEnchant;
use yeivwi\ce\enchantments\BlockBreakEnchant;
use yeivwi\ce\enchantments\ChopperEnchant;
use yeivwi\ce\enchantments\CustomEnchant;
use yeivwi\ce\enchantments\CustomMeleeEnchantment;
use yeivwi\ce\enchantments\EffectsOnOpponentDeathEnchant;
use yeivwi\ce\enchantments\ExperienceEnchant;
use yeivwi\ce\enchantments\GluttonyEnchant;
use yeivwi\ce\enchantments\ZeusEnchant;
use yeivwi\ce\enchantments\HellforgedEnchant;
use yeivwi\ce\enchantments\IrreparableCustomEnchant;
use yeivwi\ce\enchantments\ItemHeldEffectsEnchant;
use yeivwi\ce\enchantments\ItemHeldEnchant;
use yeivwi\ce\enchantments\MovementEnchant;
use yeivwi\ce\utils\LoreLines;
use yeivwi\ce\utils\NetworkItemInterceptor;
use yeivwi\ce\utils\SimpleCallbackInventoryListener;
use pocketmine\utils\SingletonTrait;

class CEnchant extends PluginBase implements Listener
{
    use SingletonTrait;
    
    public const INFRARED = 128;
    public const MERMAID = 129;
    public const INVISIBILITY = 131;
    public const FIRE_RESISTANCE = 132;
    public const RECOVER = 133;
    public const SPEED = 134;
    public const GLUTTONY = 135;
    public const CHOPPER = 136;
    public const OXYGENATE = 137;
    public const AUTOSMELT = 138;
    public const EXPERIENCE = 139;
    public const HELLFORGED = 140;
    public const IRREPARABLE = 141;
    public const ZEUS = 142;

    private const FLAG_HOLDABLE = ItemFlags::SWORD | ItemFlags::BOW | ItemFlags::TOOL | ItemFlags::DIG | ItemFlags::FISHING_ROD | ItemFlags::CARROT_STICK;

    private const ARMOR_SLOT_TO_ITEMFLAG = [
        ArmorInventory::SLOT_HEAD => ItemFlags::HEAD,
        ArmorInventory::SLOT_CHEST => ItemFlags::TORSO,
        ArmorInventory::SLOT_LEGS => ItemFlags::LEGS,
        ArmorInventory::SLOT_FEET => ItemFlags::FEET,
    ];

    private const TOOL_TO_ITEMFLAG = [
        Pickaxe::class => ItemFlags::PICKAXE,
        Sword::class => ItemFlags::SWORD,
        Axe::class => ItemFlags::AXE,
        Hoe::class => ItemFlags::HOE,
        Shovel::class => ItemFlags::SHOVEL,
        Bow::class => ItemFlags::BOW,
        FlintSteel::class => ItemFlags::FLINT_AND_STEEL,
        Shears::class => ItemFlags::SHEARS,
    ];

    /** @var EnchantmentInstance[][][]|int[][][] */
    private $trackedArmorEnchants = [];

    /** @var EnchantmentInstance[][] */
    private $lastHeldEnchants = [];

    public static function generateLoreLines(Item $item): array {
        $lore = [];
        foreach($item->getEnchantments() as $ench) {
            $type = $ench->getType();
            if(!$type instanceof CustomEnchant) continue;
            $lore[] = TextFormat::RESET . $type->getLoreLine($ench->getLevel());
        }
        return array_unique($lore);
    }
    
    public function onLoad() : void {
		self::setInstance($this);
	}

    public function onEnable(): void
    {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getServer()->getCommandMap()->register("ce", new CEnchantCommand());

        $map = EnchantmentIdMap::getInstance();
        $map->register(
            self::INFRARED,
            new ArmorEffectEquipmentEnchant(
                "Infrared", "Gives you night vision when equipped",
                self::INFRARED,
                Rarity::COMMON, ItemFlags::TORSO | ItemFlags::LEGS | ItemFlags::HEAD | ItemFlags::FEET, ItemFlags::NONE, 1,
                [new EffectInstance(VanillaEffects::NIGHT_VISION())]
            )
        );
        $map->register(
            self::MERMAID,
            new ArmorEffectEquipmentEnchant(
                "Mermaid", "Gives the user water breathing while equipped",
                self::MERMAID,
                Rarity::RARE, ItemFlags::TORSO | ItemFlags::LEGS | ItemFlags::HEAD | ItemFlags::FEET, ItemFlags::NONE, 3,
                [new EffectInstance(VanillaEffects::WATER_BREATHING())]
            )
        );
        $map->register(
            self::INVISIBILITY,
            new ArmorEffectEquipmentEnchant(
                "Invisibility", "Just by wearing this helmet you will be invisible to all...",
                self::INVISIBILITY,
                Rarity::MYTHIC, ItemFlags::TORSO | ItemFlags::LEGS | ItemFlags::HEAD | ItemFlags::FEET, ItemFlags::NONE, 1,
                [new EffectInstance(VanillaEffects::INVISIBILITY())]
            )
        );
        $map->register(
            self::FIRE_RESISTANCE,
            new ArmorEffectEquipmentEnchant(
                "Fire Resistance", "Gives fire resistance while equipped",
                self::FIRE_RESISTANCE,
                Rarity::MYTHIC, ItemFlags::TORSO | ItemFlags::LEGS | ItemFlags::HEAD | ItemFlags::FEET, ItemFlags::NONE, 1,
                [new EffectInstance(VanillaEffects::FIRE_RESISTANCE())]
            )
        );
        $map->register(
            self::SPEED,
            new ArmorEffectEquipmentEnchant(
                "Speed", "Gives the user constant speed boost when equipped",
                self::SPEED,
                Rarity::MYTHIC, ItemFlags::TORSO | ItemFlags::LEGS | ItemFlags::HEAD | ItemFlags::FEET, ItemFlags::NONE, 2,
                [new EffectInstance(VanillaEffects::SPEED())], 1
            )
        );
        $map->register(
            self::HELLFORGED,
            new HellforgedEnchant(
                "Hellforged", "Has a chance to repair your items as you walk",
                self::HELLFORGED,
                Rarity::MYTHIC, ItemFlags::ALL, ItemFlags::NONE, 4
            )
        );
        $map->register(
            self::IRREPARABLE,
            new IrreparableCustomEnchant(
                "Irreparable", "When equipped, you can rapir this item",
                self::IRREPARABLE,
                Rarity::COMMON, ItemFlags::ALL, ItemFlags::NONE, 1
            )
        );
        $map->register(
            self::EXPERIENCE,
            new ExperienceEnchant(
                "Experience", "Has a chance to give 2x or more XP from ores",
                self::EXPERIENCE,
                Rarity::MYTHIC, ItemFlags::PICKAXE, ItemFlags::NONE, 3
            )
        );
        $map->register(
            self::AUTOSMELT,
            new AutoSmeltEnchant(
                "Autosmelt", "When equipped, you will have the ability to instantly smelt mined blocks such as sand, cobblestone and ores",
                self::AUTOSMELT,
                Rarity::UNCOMMON, ItemFlags::DIG, ItemFlags::NONE, 1
            )
        );
        $map->register(
            self::CHOPPER,
            new ChopperEnchant(
                "Chopper", "When equipped, you will have the ability to chop trees in one shot while sneaking",
                self::CHOPPER,
                Rarity::UNCOMMON, ItemFlags::AXE | ItemFlags::PICKAXE | ItemFlags::SHOVEL, ItemFlags::NONE, 1
            )
        );
        $map->register(
            self::OXYGENATE,
            new ItemHeldEffectsEnchant(
                "Oxygenate", "Gives you water breathing when holding in your hand",
                self::OXYGENATE,
                Rarity::UNCOMMON, self::FLAG_HOLDABLE, ItemFlags::NONE, 1,
                [new EffectInstance(VanillaEffects::WATER_BREATHING())]
            )
        );
        $map->register(
            self::GLUTTONY,
            new GluttonyEnchant(
                "Gluttony", "Has a 10% chance to feed you while in combat",
                self::GLUTTONY,
                Rarity::UNCOMMON, ItemFlags::SWORD | ItemFlags::AXE, ItemFlags::NONE, 5
            )
        );
        $map->register(
            self::RECOVER,
            new EffectsOnOpponentDeathEnchant(
                "Recover", "When you kill a player you get absorbtion and regen",
                self::RECOVER,
                Rarity::MYTHIC, ItemFlags::SWORD | ItemFlags::AXE, ItemFlags::NONE, 1,
                [
                    new EffectInstance(VanillaEffects::REGENERATION(), 100, 1),
                    new EffectInstance(VanillaEffects::ABSORPTION(), 2400)
                ]
            )
        );
        
        $map->register(
            self::ZEUS,
            new ZeusEnchant(
                "Zeus", "You have a 5% chanddce of hitting your opponent with Lightning",
                self::ZEUS,
                Rarity::UNCOMMON, ItemFlags::SWORD | ItemFlags::AXE, ItemFlags::NONE, 5
            )
        );

    }

    public function onLogin(PlayerLoginEvent $ev): void {
        $callback = function(ArmorInventory $inventory): void {
            $this->checkArmorInventory($inventory);
        };
        ($aInv = $ev->getPlayer()->getArmorInventory())->getListeners()->add(new SimpleCallbackInventoryListener($callback, $callback));
        $this->checkArmorInventory($aInv);
    }

    public function checkArmorInventory(ArmorInventory $inv): void {
        $player = $inv->getHolder();
        if(!$player instanceof Player) throw new \RuntimeException();
        $tracking = [];
        foreach($inv->getContents() as $slot => $item) {
            if(!$item->hasEnchantments()) continue;
            foreach($item->getEnchantments() as $ench) {
                $type = $ench->getType();
                if(!$type->hasPrimaryItemType(self::ARMOR_SLOT_TO_ITEMFLAG[$slot])) continue;
                $tracking[spl_object_id($type)] = [$ench, $slot];
            }
        }
        $k = $player->getId();
        if(!isset($this->trackedArmorEnchants[$k])) {
            $this->trackedArmorEnchants[$k] = [];
        }
        /** @var EnchantmentInstance[]|int[] $added */
        $added = array_diff_key($tracking, $this->trackedArmorEnchants[$k]);
        /** @var EnchantmentInstance[]|int[] $removed */
        $removed = array_diff_key($this->trackedArmorEnchants[$k], $tracking);
        $this->trackedArmorEnchants[$k] = $tracking;

        foreach($added as $tracking) {
            [$enchInstance,] = $tracking;
            $type = $enchInstance->getType();
            if($type instanceof ArmorEquipmentEnchant) {
                $type->onEquip($player, $enchInstance->getLevel());
            }
        }

        foreach($removed as $tracking) {
            [$enchInstance,] = $tracking;
            $type = $enchInstance->getType();
            if($type instanceof ArmorEquipmentEnchant) {
                $type->onRemove($player, $enchInstance->getLevel());
            }
        }
    }

    public function onItemHeld(PlayerItemHeldEvent $ev): void {
        $item = $ev->getItem();
        $player = $ev->getPlayer();
        $k = $player->getId();
        if(!$item->hasEnchantments() || !$item instanceof Tool) {
            if(!isset($this->lastHeldEnchants[$k])) return;
            foreach($this->lastHeldEnchants[$k] as $enchInstance) {
                $type = $enchInstance->getType();
                if($type instanceof ItemHeldEnchant) {
                    $type->onUnHeld($player, $enchInstance->getLevel());
                }
            }
            return;
        }
        foreach(self::TOOL_TO_ITEMFLAG as $class => $itemFlag) {
            if($item instanceof $class) break;
        }
        if(!isset($itemFlag)) return;
        $tracking = [];
        foreach($item->getEnchantments() as $ench) {
            $type = $ench->getType();
            if(!$type->hasPrimaryItemType($itemFlag)) continue;
            $tracking[spl_object_id($type)] = $ench;
        }
        if(!isset($this->lastHeldEnchants[$k])) {
            $this->lastHeldEnchants[$k] = [];
        }
        foreach($this->lastHeldEnchants[$k] as $enchInstance) {
            $type = $enchInstance->getType();
            if($type instanceof ItemHeldEnchant) {
                $type->onUnHeld($player, $enchInstance->getLevel());
            }
        }
        $this->lastHeldEnchants[$k] = $tracking;
        foreach($tracking as $enchInstance) {
            $type = $enchInstance->getType();
            if($type instanceof ItemHeldEnchant) {
                $type->onHeld($player, $enchInstance->getLevel());
            }
        }
    }

    public function onLeave(PlayerQuitEvent $ev): void {
        $k = ($player = $ev->getPlayer())->getId();
        foreach(($this->lastHeldEnchants[$k] ?? []) as $enchInstance) {
            $type = $enchInstance->getType();
            if($type instanceof ItemHeldEnchant) {
                $type->onUnHeld($player, $enchInstance->getLevel());
            }
        }
        foreach(($this->trackedArmorEnchants[$k] ?? []) as $tracking) {
            [$enchInstance,] = $tracking;
            $type = $enchInstance->getType();
            if($type instanceof ArmorEquipmentEnchant) {
                $type->onRemove($player, $enchInstance->getLevel());
            }
        }
        unset($this->trackedArmorEnchants[$k]);
        unset($this->lastHeldEnchants[$k]);
    }

    public function onMove(PlayerMoveEvent $ev): void {
        if($ev->getFrom()->distance($ev->getTo()) < 0.001) return;
        $k = ($p = $ev->getPlayer())->getId();
        if(count($this->trackedArmorEnchants[$k] ?? []) > 0) {
            $aInv = $p->getArmorInventory();
            foreach($this->trackedArmorEnchants[$k] as $tracked) {
                [$enchant, $slot] = $tracked;
                $type = $enchant->getType();
                if(!$type->hasPrimaryItemType(self::ARMOR_SLOT_TO_ITEMFLAG[$slot])) continue;
                if($type instanceof MovementEnchant) {
                    $item = clone($oldItem = $aInv->getItem($slot));
                    $type->onMove($ev, $enchant->getLevel(), $item);
                    if(!$item->equals($oldItem)) {
                        $aInv->setItem($slot, $item);
                    }
                }
            }
        }
        $inHand = $p->getInventory()->getItemInHand();
        if($inHand->hasEnchantments()) {
            foreach($inHand->getEnchantments() as $enchant) {
                $type = $enchant->getType();
                if($type instanceof MovementEnchant && $type->hasPrimaryItemType(self::FLAG_HOLDABLE)) {
                    $item = clone $inHand;
                    $type->onMove($ev, $enchant->getLevel(), $item);
                    if(!$item->equals($inHand)) {
                        $p->getInventory()->setItemInHand($item);
                    }
                }
            }
        }
    }

    public function onBreak(BlockBreakEvent $ev): void {
        $item = $ev->getItem();
        if(!$item->hasEnchantments() || !$item instanceof Tool) return;
        $itemFlag = self::getToolItemFlag($item);
        foreach($item->getEnchantments() as $enchantment) {
            $type = $enchantment->getType();
            if(!$type->hasPrimaryItemType($itemFlag) || !$type instanceof BlockBreakEnchant) continue;
            $type->onBreak($ev, $enchantment->getLevel());
        }
    }

    private static function getToolItemFlag(Tool $item): int {
        foreach(self::TOOL_TO_ITEMFLAG as $class => $itemFlag) {
            if($item instanceof $class) return $itemFlag;
        }
        throw new \UnexpectedValueException("Unknown item type " . get_class($item));
    }

    /**
     * @param EntityDamageByEntityEvent $ev
     *
     * @priority HIGHEST
     */
    public function onAttack(EntityDamageByEntityEvent $ev): void {
        $dmg = $ev->getDamager();
        if(!$dmg instanceof Player) return;
        $item = $dmg->getInventory()->getItemInHand();
        if(!$item->hasEnchantments() || !$item instanceof Tool) return;
        $itemFlag = self::getToolItemFlag($item);
        foreach($item->getEnchantments() as $enchantment) {
            $type = $enchantment->getType();
            if(!$type->hasPrimaryItemType($itemFlag) || !$type instanceof CustomMeleeEnchantment) continue;
            $type->onPostAttack($dmg, $ev->getEntity(), $enchantment->getLevel(), $ev->getFinalDamage());
        }
    }
    
    private static function getArmorItemFlag(Armor $item): int {
        foreach(self::ARMOR_SLOT_TO_ITEMFLAG as $class => $itemFlag) {
            if($item instanceof $class) return $itemFlag;
        }
        throw new \UnexpectedValueException("Unknown item type " . get_class($item));
    }
    
    public function handlerDeath(PlayerDeathEvent $ev): void {
        $entity = $ev->getPlayer();
        $player = $entity->getLastDamageCause();
        if (!$player instanceof Player) return;
        foreach ($player->getInventory()->getContents() as $item) {
        
            if(!$item->hasEnchantments() || !$item instanceof Armor) continue;
        
            $itemFlag = self::getAmorItemFlag($item);
            foreach($item->getEnchantments() as $enchantment) {
                 $type = $enchantment->getType();
                 if(!$type->hasPrimaryItemType($itemFlag) || !$type instanceof CustomMeleeEnchantment) continue;
                 $type->onPostAttack($player, $ev->getEntity(), $enchantment->getLevel(), 0.0);
                }
          }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
        if (!$sender instanceof Player) {
            return true;
        }
        if (count($args) < 1) {
            $sender->sendMessage(TextFormat::colorize("Use /ce name lv"));
            return false;
        }

        if ($args[0] === "test") {
            foreach($sender->getInventory()->getContents() as $slot => $item){
                if($item instanceof Tool||$item instanceof Armor){
                    if($item->getDamage() > 0 and !$item->hasEnchantment(EnchantmentIdMap::getInstance()->fromId(self::IRREPARABLE))){
                        $sender->getInventory()->setItem($slot, $item->setDamage(0));
                    }
                }
            }
            foreach($sender->getArmorInventory()->getContents() as $slot => $item){
                if($item instanceof Tool||$item instanceof Armor){
                    if($item->getDamage() > 0 and !$item->hasEnchantment(EnchantmentIdMap::getInstance()->fromId(self::IRREPARABLE))){
                        $sender->getArmorInventory()->setItem($slot, $item->setDamage(0));
                    }
                }
            }
            $sender->sendMessage(TextFormat::GREEN . "All your inventory was repaired!");
            return true;
        }
        
        if (!is_numeric($args[0]) || !is_numeric($args[1])) {
            $sender->sendMessage(TextFormat::colorize("&cThe enchantment must be of type int and given a string"));
            return false;
        }
        
        $ench = EnchantmentIdMap::getInstance()->fromId($args[0]);
        if(!$ench instanceof CustomEnchant) {
            $sender->sendMessage("Invalid enchant");
            return false;
        }
        $item = $sender->getInventory()->getItemInHand();
        $level = $args[1] ?? 1;
        
        $itemLore = $item->getLore();
        if (count($itemLore) === 0) {
            $itemLore[] = TextFormat::colorize('&r');
        }
        if ($item->hasEnchantment($ench)) {
            $oldEnchant = $item->getEnchantment($ench);
            if ($oldEnchant->getLevel() !== $level) {
                if (in_array(TextFormat::colorize('&r'.$ench->getLoreLine($oldEnchant->getLevel())), $itemLore, true)) {
                    $itemLore[array_search(TextFormat::colorize('&r' . $ench->getLoreLine($oldEnchant->getLevel())), $itemLore, true)] = TextFormat::colorize('&r' . $ench->getLoreLine($level));
                }
            } else {
                $sender->sendMessage(TextFormat::colorize('&cThis item already has ' . $ench->getName() . ' enchant.')); 
                return false;
            }
        } else {
            $itemLore[] = TextFormat::colorize('&r'.$ench->getLoreLine($level));
        }
        $item->addEnchantment(new EnchantmentInstance($ench, $level));
        $item->setLore($itemLore);
        $sender->getInventory()->setItemInHand($item);
        $sender->sendMessage("§aCustom Enchantment placed on the item correctly.");
        return true;

    }

}