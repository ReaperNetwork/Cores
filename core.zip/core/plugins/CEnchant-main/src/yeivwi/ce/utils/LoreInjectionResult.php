<?php


namespace yeivwi\ce\utils;

use pocketmine\network\mcpe\protocol\types\inventory\ItemStackWrapper;

class LoreInjectionResult {
	private $itemStackWrapper;
	private $loreLines;

	public function __construct(ItemStackWrapper $wrapper, array $lines) {
		$this->itemStackWrapper = $wrapper;
		$this->loreLines = $lines;
	}

	/**
	 * @return ItemStackWrapper
	 */
	public function getItemStackWrapper(): ItemStackWrapper {
		return $this->itemStackWrapper;
	}

	/**
	 * @return array
	 */
	public function getLoreLines(): array {
		return $this->loreLines;
	}
}