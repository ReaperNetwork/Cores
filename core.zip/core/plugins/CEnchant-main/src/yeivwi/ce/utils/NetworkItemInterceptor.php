<?php


namespace yeivwi\ce\utils;

use muqsit\simplepackethandler\SimplePacketHandler;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\NetworkSession;
use pocketmine\network\mcpe\protocol\InventoryContentPacket;
use pocketmine\network\mcpe\protocol\InventorySlotPacket;
use pocketmine\network\mcpe\protocol\types\inventory\ItemStack;
use pocketmine\network\mcpe\protocol\types\inventory\ItemStackWrapper;
use pocketmine\player\Player;
use pocketmine\plugin\Plugin;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Utils;

/**
 * This hacky class basically intercepts items on the network side... sets their lore with padding of arbitrary &r prefixes
 * Calculation of arbitrary &r count and when the lore should be updated is upto the plugin developer to decide...
 *
 * @package CortexPE\DynamicLore
 */
class NetworkItemInterceptor {
	/** @var callable */
	private $closure;
	/** @var string */
	private $identifier;
	/** @var bool */
	private $ignoreSend = false;
	/** @var bool */
	private $ignoreHash;

	private function __construct(Plugin $registrant, int $priority, string $identifier, bool $ignoreHash, callable $closure) {
		$this->ignoreHash = $ignoreHash;
		$this->closure = $closure;
		$this->identifier = $identifier;
		// ignore MobArmorEquipmentPacket, MobEquipmentPacket, AddItemActorPacket, AddPlayerPacket
		// we don't wanna change lore when another player sends us items
		SimplePacketHandler::createInterceptor($registrant, $priority)
			->interceptOutgoing(function(InventoryContentPacket $pk, NetworkSession $destination): bool {
				if($this->ignoreSend) return true;
				$p = $destination->getPlayer();
				$w = $destination->getInvManager()->getWindow($pk->windowId);
				foreach($pk->items as $k => $item) {
					$pk->items[$k] = $this->tryInjectLore($p, $w, $k, $pk->items[$k]);
				}
				return true;
			})
			->interceptOutgoing(function(InventorySlotPacket $pk, NetworkSession $destination): bool {
				if($this->ignoreSend) return true;
				$pk->item = $this->tryInjectLore($destination->getPlayer(), $destination->getInvManager()->getWindow($pk->windowId), $pk->inventorySlot, $pk->item);
				return true;
			});
	}

	private function tryInjectLore(?Player $player, ?Inventory $inv, int $slot, ItemStackWrapper $wrapper): ItemStackWrapper {
		if($player === null || $inv === null) return $wrapper;

		/** @var LoreLines $loreLines */
		$loreLines = ($this->closure)($player, $inv, $wrapper->getItemStack());
		if($loreLines === null) return $wrapper;
		if(count($loreLines->getLines()) < 1) return $wrapper;

		// check if it's safe to ignore the item by checking server-side inventory
		$item = $inv->getItem($slot);
		$safelyIgnore = true;
		do {
			$nbt = $item->getNamedTag();

			if($nbt->count() < 1) {
				$safelyIgnore = false;
				break;
			}

			/** @var CompoundTag|null $display */
			if(($display = $nbt->getTag(Item::TAG_DISPLAY)) === null) {
				$safelyIgnore = false;
				break;
			}

			/** @var ListTag|null $loreTag */
			if(($loreTag = $display->getTag(Item::TAG_DISPLAY_LORE)) === null) {
				$safelyIgnore = false;
				break;
			}

			if($loreTag->count() < 1) {
				$safelyIgnore = false;
				break;
			}
			if($this->ignoreHash || $nbt->getLong($this->parityString(), -1) !== $loreLines->getHash()) {
				$safelyIgnore = false;
				break;
			}
		} while(false);

		if($safelyIgnore) return $wrapper;
		$result = $this->injectLore($wrapper, $loreLines);
		$this->ignoreSend = true;
		$inv->setItem(
			$slot, $item
			->setNamedTag(
				$nbt
					->setLong($this->parityString(), $loreLines->getHash())
			)
			->setLore($result->getLoreLines())
		);
		$this->ignoreSend = false;

		return $result->getItemStackWrapper();
	}

	private function parityString(): string {
		return $this->identifier . "_LoreHash";
	}

	private function injectLore(ItemStackWrapper $wrapper, LoreLines $loreLines): LoreInjectionResult {
		$iStack = $wrapper->getItemStack();

		$wasNbtNull = false;
		$nbt = $iStack->getNbt();
		if($nbt === null) {
			$wasNbtNull = true; // we need the flag later
			$nbt = new CompoundTag();
		}
		$display = $nbt->getTag(Item::TAG_DISPLAY) ?? new CompoundTag();
		$loreTag = $display->getListTag(Item::TAG_DISPLAY_LORE);
		$lines = [];
		if($loreTag !== null) $lines = $loreTag->getAllValues();

		if(count($lines) > 0) {
			$padding = str_repeat(TextFormat::RESET, $loreLines->getPadding()) . TextFormat::OBFUSCATED . TextFormat::RESET;
			$padLen = strlen($padding);
			foreach($lines as $k => $v) {
				if(substr($v, 0, $padLen) !== $padding) continue;
				unset($lines[$k]);
			}
		}

		array_unshift($lines, ...$loreLines->getLines());
		usort($lines, static function(string $a, string $b): int {
			$getPrefixCount = static function(string $s): int {
				$count = 0;
				$i = 0;
				$resetLen = strlen(TextFormat::RESET);
				while(substr($s, $i, $resetLen) === TextFormat::RESET) {
					$i += $resetLen;
					$count++;
				}
				return $count;
			};
			return (($getPrefixCount)($a) <=> ($getPrefixCount)($b)) * -1;
		});

		$display->setTag(Item::TAG_DISPLAY_LORE, new ListTag(array_map(function(string $s): StringTag {
			return new StringTag($s);
		}, $lines)));
		$nbt->setTag(Item::TAG_DISPLAY, $display);
		$nbt->setLong($this->parityString(), $loreLines->getHash());

		if($wasNbtNull) {
			$refClass = new \ReflectionClass(ItemStack::class);
			$refProp = $refClass->getProperty("nbt");
			$refProp->setAccessible(true);
			$refProp->setValue($iStack, $nbt);
		}
		return new LoreInjectionResult($wrapper, $lines);
	}

	/** @noinspection PhpInconsistentReturnPointsInspection */
	public static function create(Plugin $registrant, int $priority, string $identifier, bool $ignoreHash, callable $closure): self {
		Utils::validateCallableSignature(function(Player $player, Inventory $inventory, ItemStack $item): ?LoreLines { }, $closure);
		return new self($registrant, $priority, $identifier, $ignoreHash, $closure);
	}
}