<?php


namespace yeivwi\ce\utils;

use pocketmine\utils\TextFormat;

class LoreLines {
	/** @var int */
	private $padding;
	/** @var string[] */
	private $lines;
	/** @var int */
	private $hash;

	/**
	 * LoreLines constructor.
	 * @param int $padding Controls how much padding should be added prefixing the lines, also controls the priority of the lore group... Higher number = Higher priority to be on top
	 * @param array $lines
	 */
	public function __construct(int $padding, array $lines) {
		$this->padding = $padding;
		$pad = str_repeat(TextFormat::RESET, $padding) . TextFormat::OBFUSCATED . TextFormat::RESET;
		foreach($lines as $k => $v) {
			$lines[$k] = $pad . $v;
		}
		$this->lines = $lines;
		$this->hash = crc32(implode("\n", $lines));
	}

	/**
	 * @return string[]
	 */
	public function getLines(): array {
		return $this->lines;
	}

	/**
	 * @return int
	 */
	public function getPadding(): int {
		return $this->padding;
	}

	/**
	 * @return int
	 */
	public function getHash(): int {
		return $this->hash;
	}

	public function prependTo(array $lines): array {
		return array_merge($this->lines, $lines);
	}
}