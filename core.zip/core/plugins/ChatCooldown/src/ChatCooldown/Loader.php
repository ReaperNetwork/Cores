<?php

namespace ChatCooldown;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class Loader extends PluginBase implements Listener
{

    public Config $config;

    private static $instance;
    private $antispam = [];
    private $cooldown = [];

    public function onEnable(): void
    {

        self::$instance = $this;
        $this->saveResource("config.yml");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public static function getInstance(): self{
        return self::$instance;
    }

    public function PlayerChatEvent(PlayerChatEvent $event): void
    {
        $config = new Config($this->getDataFolder() . "config.yml", Config::YAML);

        $player = $event->getPlayer();
        $msg = $event->getMessage();
        $name = $player->getName();

        //Cooldown Manager
        if(isset($this->cooldown[strtolower($player->getName())])){
            $time = $this->cooldown[strtolower($player->getName())];
            if($time > time()){
                $event->cancel();
                $player->sendMessage($config->get("TryTalkMessage"));
            }
        }
        $this->cooldown[strtolower($player->getName())] = time() +1;
        
        //Spam Manager
        /*if(isset($this->antispam[strtolower($player->getName())])){
            $msgsave = $this->antispam[strtolower($player->getName())];
            if($msgsave === $msg){
                $event->cancel();
            }
        }
        $this->antispam[strtolower($player->getName())] = $msg;*/
    }

}