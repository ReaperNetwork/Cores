<?php

namespace itoozh\partnerpackage\command;

use itoozh\partnerpackage\PartnerPackages;
use itoozh\partnerpackage\util\Content;
use pocketmine\block\utils\MobHeadType;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\item\LegacyStringToItemParser;

class PackageCommand extends Command {
    
    public function __construct() {
        parent::__construct('ppackage', 'Use command to partner packages.');
        $this->setPermission('ppackage.command');
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) {
            return;
        }
        
        if (count($args) < 1) {
            $sender->sendMessage(TextFormat::colorize('&aUse /ppackage give | giveall | edit'));
            return;
        }

        switch (strtolower($args[0])) {
            case 'give':
                if (count($args) < 3) {
                    $sender->sendMessage(TextFormat::colorize('&cUse /ppackage give [player] [count]'));
                    return;
                }
                $player = Server::getInstance()->getPlayerByPrefix($args[1]);
                
                if (!$player instanceof Player) {
                    $sender->sendMessage(TextFormat::colorize('&cInvalid player.'));
                    return;
                }
                
                if (!is_numeric($args[2])) {
                    $sender->sendMessage(TextFormat::colorize('&cCant is invalid.'));
                    return;
                }
                $ppackageItem = VanillaBlocks::MOB_HEAD()->setMobHeadType(MobHeadType::CREEPER)->asItem();
                $ppackageItem->setCustomName(TextFormat::colorize('&r&l&6PARTNER PACKAGE'));
                $ppackageItem->setCount((int) $args[2]);

                $lore = [
            '&7---------&8---------&7--------',
            ' &l&aINFORMATION',
            ' &7El package es un item que ',
            ' &7al dar click izquierdo te ',
            ' &7dara, items especiales ',
            ' &7estos solo se podran conseguir ',
            ' &7en packages y crates.',
            ' ',
            ' &l&4WARNING',
            ' &7Si tienes el inventario lleno',
            ' &7no te dejara abrir el package',
            ' &7esto se puso para evitar los',
            ' &7distintos dupeos.',
            '&7---------&8---------&7--------'
        ];                     
              
                $l = [];
                
                foreach ($lore as $line) {
            $l[] = TextFormat::RESET . TextFormat::colorize($line);
        }
                $ppackageItem->setLore($l);
                $ppackageItem->getNamedTag()->setInt('ppackage', 1);
                
                if ($player->getInventory()->canAddItem($ppackageItem)) {
                    $player->getInventory()->addItem($ppackageItem);
                } else {
                    $player->dropItem($ppackageItem);
                }
                break;
                
            case 'giveall':
                if (count($args) < 2) {
                    $sender->sendMessage(TextFormat::colorize('&cUse /ppackage giveall [cant]'));
                    return;
                }

                if (!is_numeric($args[1])) {
                    $sender->sendMessage(TextFormat::colorize('&cCant is invalid.'));
                    return;
                }
                $ppackageItem = VanillaBlocks::MOB_HEAD()->setMobHeadType(MobHeadType::CREEPER)->asItem();
                $ppackageItem->setCustomName(TextFormat::colorize('&r&l&6PARTNER PACKAGE'));
                $ppackageItem->setCount((int) $args[1]);

                $lore = [
            '&7---------&8---------&7--------',
            ' &l&aINFORMATION',
            ' &7El package es un item que ',
            ' &7al dar click izquierdo te ',
            ' &7dara, items especiales ',
            ' &7estos solo se podran conseguir ',
            ' &7en packages y crates.',
            ' ',
            ' &l&4WARNING',
            ' &7Si tienes el inventario lleno',
            ' &7no te dejara abrir el package',
            ' &7esto se puso para evitar los',
            ' &7distintos dupeos.',
            '&7---------&8---------&7--------'
        ];                     
              
                $l = [];
                
                foreach ($lore as $line) {
            $l[] = TextFormat::RESET . TextFormat::colorize($line);
        }

                $ppackageItem->setLore($l);
                $ppackageItem->getNamedTag()->setInt('ppackage', 1);
                
                foreach (Server::getInstance()->getOnlinePlayers() as $player) {
                    if ($player->getInventory()->canAddItem($ppackageItem)) {
                        $player->getInventory()->addItem($ppackageItem);
                    } else {
                        $player->dropItem($ppackageItem);
                    }
                }
                break;
                
            case 'edit':
                if (!$sender instanceof Player) {
                    return;
                }
                Content::getInstance()->sendMenu($sender);
                break;
        }
    }
}