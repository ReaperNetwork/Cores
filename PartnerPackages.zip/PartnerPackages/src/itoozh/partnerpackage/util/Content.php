<?php

declare(strict_types=1);

namespace itoozh\partnerpackage\util;

use hcf\util\Serialize;
use itoozh\partnerpackage\PartnerPackages;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;
use pocketmine\utils\TextFormat;

final class Content {
    use SingletonTrait;

    /** @var Item[] */
    private array $items = [];

    public function getItems(): array {
        return $this->items;
    }

    public function load(): void {
        $config = new Config(PartnerPackages::getInstance()->getDataFolder() . 'content.json', Config::JSON);
        $this->items = array_map(fn($data) => Serialize::deserialize($data), $config->getAll());
    }

    public function save(): void {
        $config = new Config(PartnerPackages::getInstance()->getDataFolder() . 'content.json', Config::JSON);
        $config->setAll(array_map(fn(Item $item) => Serialize::serialize($item), $this->items));
        $config->save();
    }

    public function sendMenu(Player $player): void {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $menu->getInventory()->setContents($this->items);
        $menu->setInventoryCloseListener(function (Player $player, Inventory $inventory): void {
            $this->items = $inventory->getContents();
            $player->sendMessage(TextFormat::colorize('&aYou haven edit the loot.'));
        });
        $menu->send($player, TextFormat::colorize('&ePartner PartnerPackages Loot'));
    }
}