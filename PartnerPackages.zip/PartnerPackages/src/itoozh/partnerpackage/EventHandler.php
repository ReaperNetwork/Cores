<?php

namespace itoozh\partnerpackage;

use BlockHorizons\Fireworks\entity\FireworksRocket;
use BlockHorizons\Fireworks\item\Fireworks;
use BlockHorizons\Fireworks\item\ExtraVanillaItems;
use itoozh\partnerpackage\util\Content;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\utils\TextFormat;
use pocketmine\world\sound\ExplodeSound;
use pocketmine\world\particle\HugeExplodeSeedParticle;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\math\Vector3;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;

class EventHandler implements Listener {

    public function handlePlace(BlockPlaceEvent $event): void {
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();

        if ($item->getNamedTag()->getTag('ppackage') !== null) {
            $event->cancel();
        }
    }

    public function handleItemUse(PlayerItemUseEvent $event): void {
        $item = $event->getItem();
        $player = $event->getPlayer();

        if ($item->getNamedTag()->getTag('ppackage') !== null) {
            $content = Content::getInstance()->getItems();
            $reward = $content[array_rand($content)];
            $reward1 = $content[array_rand($content)];
            $reward2 = $content[array_rand($content)];

            if (!$player->getInventory()->canAddItem($item)) {
                $player->sendMessage(TextFormat::colorize('&cInventory full.'));
                return;
            }
            $item->pop();

            $player->getInventory()->setItemInHand($item);
            $player->getWorld()->addSound($player->getPosition(), new ExplodeSound());
            $player->getWorld()->addParticle($player->getPosition(), new HugeExplodeSeedParticle());
            
            
            $fw = ExtraVanillaItems::FIREWORKS();
            $fw->addExplosion(Fireworks::TYPE_BURST, Fireworks::COLOR_GOLD, "", false, false);
            $vector3 = $player->getPosition()->add(0.5, 1, 0.5); //0.5 1 0.5
            $pos = $player->getLocation();
            $pos->x = $vector3->x;
            $pos->y = $vector3->y;
            $pos->z = $vector3->z;
             $pos->yaw = lcg_value() * 360;
             $pos->pitch = 90;
             $entity = new FireworksRocket($pos, $fw);
             $entity->setMotion(new Vector3(0.001, 0.05, 0.001));            

             if ($entity instanceof FireworksRocket) {
                 $entity->spawnToAll();
            }
            
            $player->getInventory()->addItem($reward);
            $player->getInventory()->addItem($reward1);
            $player->getInventory()->addItem($reward2);
            $player->sendMessage(TextFormat::colorize('&r&b------------&9------------&b------------'));
            $player->sendMessage(TextFormat::colorize('    &l&d  &r    &7     &d Partner &fPackage'));
            $player->sendMessage(TextFormat::colorize('&r&7'));
            $player->sendMessage(TextFormat::colorize(' &7» &fYou have won &b' . ($reward->hasCustomName() ? $reward->getCustomName() : $reward->getName())));
            $player->sendMessage(TextFormat::colorize(' &7» &fYou have won &b' . ($reward1->hasCustomName() ? $reward1->getCustomName() : $reward1->getName()))); 
            $player->sendMessage(TextFormat::colorize(' &7» &fYou have won &b' . ($reward2->hasCustomName() ? $reward2->getCustomName() : $reward2->getName())));
            $player->sendMessage(TextFormat::colorize('&r&r&b------------&9------------&b------------'));
        }
    }

}