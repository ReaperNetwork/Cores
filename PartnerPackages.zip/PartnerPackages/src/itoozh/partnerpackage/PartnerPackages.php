<?php

namespace itoozh\partnerpackage;

use itoozh\partnerpackage\command\PackageCommand;
use itoozh\partnerpackage\util\Content;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;

class PartnerPackages extends PluginBase {
    use SingletonTrait;

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents(new EventHandler(), $this);
        $this->getServer()->getCommandMap()->register('PartnerPackages', new PackageCommand());

        Content::getInstance()->load();
    }

    protected function onDisable(): void {
        Content::getInstance()->save();
    }
}